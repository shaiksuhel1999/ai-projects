-- Cluster-safe id source for transaction references.
-- Runs after Hibernate DDL (spring.jpa.defer-datasource-initialization=true).
CREATE SEQUENCE IF NOT EXISTS reference_seq START WITH 100000 INCREMENT BY 1;
