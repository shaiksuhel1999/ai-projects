package com.creditcard.lifecycle.model.enums;

/** Card-network-style dispute reason codes (why the cardholder is disputing). */
public enum DisputeReasonCode {
    FRAUD("10.4", "Fraudulent / card-not-present transaction"),
    GOODS_NOT_RECEIVED("13.1", "Merchandise or services not received"),
    NOT_AS_DESCRIBED("13.3", "Not as described or defective"),
    DUPLICATE("12.6", "Duplicate processing"),
    INCORRECT_AMOUNT("12.5", "Incorrect amount charged"),
    CANCELLED_RECURRING("13.2", "Cancelled recurring transaction"),
    CREDIT_NOT_PROCESSED("13.6", "Credit / refund not processed");

    private final String networkCode;
    private final String description;

    DisputeReasonCode(String networkCode, String description) {
        this.networkCode = networkCode;
        this.description = description;
    }

    public String networkCode() {
        return networkCode;
    }

    public String description() {
        return description;
    }
}
