package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.dto.LoanDtos.EmiConversionRequest;
import com.creditcard.lifecycle.dto.LoanDtos.LoanApplicationRequest;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Installment;
import com.creditcard.lifecycle.model.Loan;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.InstallmentStatus;
import com.creditcard.lifecycle.model.enums.LoanStatus;
import com.creditcard.lifecycle.model.enums.LoanType;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.repository.LoanRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.EmiCalculator;
import com.creditcard.lifecycle.support.Money;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * The lending engine. Handles personal-loan applications (with simple
 * underwriting), converting a card purchase into an EMI plan, generating the
 * amortization schedule, and recording monthly instalment repayments.
 */
@Service
@Transactional
public class LoanService {

    private final LoanRepository loanRepository;
    private final CreditAccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final BankProperties bank;
    private final LifecycleEvents events;

    public LoanService(LoanRepository loanRepository,
                       CreditAccountRepository accountRepository,
                       TransactionRepository transactionRepository,
                       BankProperties bank,
                       LifecycleEvents events) {
        this.loanRepository = loanRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.bank = bank;
        this.events = events;
    }

    /** Submit and underwrite a personal-loan application. Approval price is risk-based. */
    public Loan applyPersonalLoan(LoanApplicationRequest req) {
        CreditAccount account = accountRepository.findById(req.accountId())
                .orElseThrow(() -> new ResourceNotFoundException("Account", req.accountId()));
        Customer customer = account.getCustomer();

        Loan loan = new Loan();
        loan.setAccount(account);
        loan.setType(LoanType.PERSONAL_LOAN);
        loan.setPrincipal(Money.of(req.principal()));
        loan.setTenureMonths(req.tenureMonths());
        loan.setPurpose(req.purpose());
        loan.setStatus(LoanStatus.APPLIED);

        Underwriting decision = underwrite(customer, Money.of(req.principal()));
        loan.setDecisionReason(decision.reason());
        if (decision.approved()) {
            loan.setStatus(LoanStatus.APPROVED);
            loan.setAnnualRate(decision.annualRate());
            loan.setEmiAmount(EmiCalculator.emi(loan.getPrincipal(), decision.annualRate(), req.tenureMonths()));
            loan.setOutstandingPrincipal(loan.getPrincipal());
        } else {
            loan.setStatus(LoanStatus.REJECTED);
            loan.setAnnualRate(BigDecimal.ZERO.setScale(2));
        }
        loanRepository.save(loan);
        events.publish(decision.approved() ? EventType.LOAN_APPROVED : EventType.LOAN_REJECTED,
                "Personal loan " + loan.getStatus() + ": " + loan.getDecisionReason(),
                account.getId(), null, null, loan.getPrincipal());
        return loan;
    }

    /** Disburse an approved loan and generate its amortization schedule. */
    public Loan disburse(Long loanId) {
        Loan loan = get(loanId);
        if (loan.getStatus() != LoanStatus.APPROVED) {
            throw new BusinessException("Only an APPROVED loan can be disbursed; status = " + loan.getStatus());
        }
        loan.setStatus(LoanStatus.DISBURSED);
        loan.setDisbursedAt(LocalDateTime.now());
        buildSchedule(loan, LocalDate.now().plusMonths(1));
        // Personal-loan funds are paid to the customer's external bank account (out of scope here).
        loanRepository.save(loan);
        events.publish(EventType.LOAN_DISBURSED,
                "Loan #" + loan.getId() + " disbursed: EMI " + loan.getEmiAmount() + " x" + loan.getTenureMonths(),
                loan.getAccount().getId(), null, null, loan.getPrincipal());
        return loan;
    }

    /**
     * Convert a settled/captured card purchase into an EMI plan. The purchase amount
     * moves off the revolving balance onto a fixed monthly schedule.
     */
    public Loan convertToEmi(EmiConversionRequest req) {
        Transaction source = transactionRepository.findById(req.transactionId())
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", req.transactionId()));
        if (source.getType() != TransactionType.PURCHASE) {
            throw new BusinessException("Only a purchase can be converted to EMI");
        }
        if (source.getStatus() != TransactionStatus.CAPTURED && source.getStatus() != TransactionStatus.SETTLED) {
            throw new BusinessException("Purchase must be CAPTURED or SETTLED before EMI conversion; status = "
                    + source.getStatus());
        }
        if (loanRepository.findByAccountIdOrderByCreatedAtDesc(source.getAccount().getId()).stream()
                .anyMatch(l -> req.transactionId().equals(l.getSourceTransactionId()))) {
            throw new BusinessException("This purchase has already been converted to EMI");
        }

        CreditAccount account = source.getAccount();
        BigDecimal principal = Money.of(source.getCapturedAmount());
        BigDecimal rate = bank.getLoan().getBaseRate().add(new BigDecimal("2.00"));

        // Move the purchase from revolving credit onto the loan.
        account.setCurrentBalance(Money.of(account.getCurrentBalance().subtract(principal)));

        Loan loan = new Loan();
        loan.setAccount(account);
        loan.setType(LoanType.EMI_CONVERSION);
        loan.setStatus(LoanStatus.DISBURSED);
        loan.setPrincipal(principal);
        loan.setAnnualRate(rate);
        loan.setTenureMonths(req.tenureMonths());
        loan.setOutstandingPrincipal(principal);
        loan.setSourceTransactionId(source.getId());
        loan.setPurpose("EMI conversion of purchase " + source.getReference());
        loan.setEmiAmount(EmiCalculator.emi(principal, rate, req.tenureMonths()));
        loan.setDisbursedAt(LocalDateTime.now());
        loan.setDecisionReason("Auto-approved EMI conversion");
        buildSchedule(loan, LocalDate.now().plusMonths(1));
        loanRepository.save(loan);
        events.publish(EventType.EMI_CONVERTED,
                "Purchase " + source.getReference() + " converted to " + req.tenureMonths()
                        + "-month EMI of " + loan.getEmiAmount(),
                account.getId(), null, source.getReference(), principal);
        return loan;
    }

    /** Pay the next due instalment; closes the loan when the final one is paid. */
    public Loan payInstallment(Long loanId) {
        Loan loan = get(loanId);
        if (loan.getStatus() == LoanStatus.CLOSED) {
            throw new BusinessException("Loan is already fully repaid");
        }
        if (loan.getStatus() != LoanStatus.DISBURSED && loan.getStatus() != LoanStatus.ACTIVE) {
            throw new BusinessException("Loan is not in a repayable state; status = " + loan.getStatus());
        }

        Installment next = loan.getInstallments().stream()
                .filter(i -> i.getStatus() != InstallmentStatus.PAID)
                .findFirst()
                .orElseThrow(() -> new BusinessException("No pending instalments remain on this loan"));

        next.setStatus(InstallmentStatus.PAID);
        next.setPaidAt(LocalDateTime.now());
        loan.setOutstandingPrincipal(
                Money.max(BigDecimal.ZERO.setScale(2), loan.getOutstandingPrincipal().subtract(next.getPrincipalComponent())));
        loan.setStatus(LoanStatus.ACTIVE);

        boolean allPaid = loan.getInstallments().stream()
                .allMatch(i -> i.getStatus() == InstallmentStatus.PAID);
        if (allPaid) {
            loan.setStatus(LoanStatus.CLOSED);
            loan.setOutstandingPrincipal(BigDecimal.ZERO.setScale(2));
        }
        events.publish(EventType.EMI_PAID,
                "EMI " + next.getSequence() + " paid on loan #" + loan.getId()
                        + (allPaid ? " (loan CLOSED)" : "; outstanding " + loan.getOutstandingPrincipal()),
                loan.getAccount().getId(), null, null, next.getEmiAmount());
        return loan;
    }

    @Transactional(readOnly = true)
    public Loan get(Long loanId) {
        return loanRepository.findById(loanId)
                .orElseThrow(() -> new ResourceNotFoundException("Loan", loanId));
    }

    @Transactional(readOnly = true)
    public List<Loan> listByAccount(Long accountId) {
        return loanRepository.findByAccountIdOrderByCreatedAtDesc(accountId);
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private record Underwriting(boolean approved, BigDecimal annualRate, String reason) {
    }

    private Underwriting underwrite(Customer customer, BigDecimal principal) {
        int score = customer.getCreditScore();
        if (score < bank.getLoan().getMinCreditScore()) {
            return new Underwriting(false, null,
                    "Rejected: credit score " + score + " is below the minimum of " + bank.getLoan().getMinCreditScore());
        }
        BigDecimal maxPrincipal = customer.getAnnualIncome().multiply(bank.getLoan().getMaxIncomeMultiple());
        if (principal.compareTo(maxPrincipal) > 0) {
            return new Underwriting(false, null,
                    "Rejected: requested " + principal + " exceeds the eligible limit of " + Money.of(maxPrincipal));
        }
        BigDecimal rate = bank.getLoan().getBaseRate().add(riskPremium(score));
        return new Underwriting(true, Money.of(rate),
                "Approved at " + Money.of(rate) + "% p.a. based on a credit score of " + score);
    }

    /** Better scores get a smaller premium over the base rate. */
    private BigDecimal riskPremium(int score) {
        if (score >= 780) {
            return new BigDecimal("0.00");
        } else if (score >= 740) {
            return new BigDecimal("1.50");
        } else if (score >= 700) {
            return new BigDecimal("3.00");
        }
        return new BigDecimal("4.50");
    }

    /** Build the reducing-balance amortization schedule for a loan. */
    private void buildSchedule(Loan loan, LocalDate firstDueDate) {
        BigDecimal principal = loan.getPrincipal();
        BigDecimal rate = loan.getAnnualRate();
        int tenure = loan.getTenureMonths();
        BigDecimal emi = EmiCalculator.emi(principal, rate, tenure);
        loan.setEmiAmount(emi);

        BigDecimal monthlyRate = EmiCalculator.monthlyRate(rate);
        BigDecimal outstanding = principal;

        loan.getInstallments().clear();
        for (int seq = 1; seq <= tenure; seq++) {
            BigDecimal interestComponent = Money.of(outstanding.multiply(monthlyRate));
            BigDecimal principalComponent;
            BigDecimal emiThisMonth;
            if (seq == tenure) {
                // Final instalment clears any rounding drift by paying the exact remainder.
                principalComponent = outstanding;
                emiThisMonth = Money.of(principalComponent.add(interestComponent));
            } else {
                principalComponent = Money.of(emi.subtract(interestComponent));
                emiThisMonth = emi;
            }
            outstanding = Money.of(outstanding.subtract(principalComponent));
            if (outstanding.signum() < 0) {
                outstanding = BigDecimal.ZERO.setScale(2);
            }

            Installment inst = new Installment();
            inst.setLoan(loan);
            inst.setSequence(seq);
            inst.setDueDate(firstDueDate.plusMonths((long) seq - 1));
            inst.setEmiAmount(emiThisMonth);
            inst.setPrincipalComponent(principalComponent);
            inst.setInterestComponent(interestComponent);
            inst.setBalanceAfter(outstanding);
            inst.setStatus(InstallmentStatus.PENDING);
            loan.getInstallments().add(inst);
        }
    }
}
