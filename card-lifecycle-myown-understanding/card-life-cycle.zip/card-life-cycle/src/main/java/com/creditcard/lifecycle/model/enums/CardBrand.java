package com.creditcard.lifecycle.model.enums;

/** Card network / brand, inferred from the BIN (first digits of the PAN). */
public enum CardBrand {
    VISA,
    MASTERCARD,
    RUPAY,
    AMEX,
    UNKNOWN
}
