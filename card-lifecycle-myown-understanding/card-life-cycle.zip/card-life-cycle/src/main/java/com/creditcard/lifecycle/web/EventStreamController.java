package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.event.EventBroadcaster;
import com.creditcard.lifecycle.event.LifecycleEvent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

/**
 * Real-time event feed. Subscribe once and receive every authorization,
 * capture, settlement, payment, statement, fraud alert and loan event as it
 * happens &mdash; exactly what a live operations dashboard would consume.
 */
@RestController
@RequestMapping("/api")
@Tag(name = "9. Real-time events", description = "Live Server-Sent Events stream + recent-events feed")
public class EventStreamController {

    private final EventBroadcaster broadcaster;

    public EventStreamController(EventBroadcaster broadcaster) {
        this.broadcaster = broadcaster;
    }

    @GetMapping(value = "/stream/events", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @Operation(summary = "Subscribe to the live event stream (Server-Sent Events)")
    public SseEmitter stream() {
        return broadcaster.subscribe();
    }

    @GetMapping("/events/recent")
    @Operation(summary = "Fetch the most recent lifecycle events (newest first)")
    public List<LifecycleEvent> recent() {
        return broadcaster.recent();
    }
}
