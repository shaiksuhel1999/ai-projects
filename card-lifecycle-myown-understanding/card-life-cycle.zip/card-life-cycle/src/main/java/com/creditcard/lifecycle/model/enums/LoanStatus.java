package com.creditcard.lifecycle.model.enums;

/** Lifecycle of a loan / EMI application. */
public enum LoanStatus {
    /** Application submitted, awaiting underwriting. */
    APPLIED,
    /** Underwriting approved; awaiting disbursement. */
    APPROVED,
    /** Underwriting rejected; terminal state. */
    REJECTED,
    /** Funds disbursed and amortization schedule generated. */
    DISBURSED,
    /** Repayment in progress. */
    ACTIVE,
    /** Fully repaid; terminal state. */
    CLOSED
}
