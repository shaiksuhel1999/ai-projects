package com.creditcard.lifecycle;

import com.creditcard.lifecycle.config.BankProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Entry point for the end-to-end credit card lifecycle simulation.
 *
 * <p>The application models the full journey of a card:
 * <ol>
 *   <li>Issuance &amp; activation of a card backed by a revolving credit account.</li>
 *   <li>A purchase at a POS terminal flowing Acquirer &rarr; Card Network &rarr; Issuer for authorization.</li>
 *   <li>Clearing (capture) and settlement of the authorized transaction.</li>
 *   <li>Billing cycle: statement generation, interest and fees.</li>
 *   <li>Monthly payments (minimum / total / custom).</li>
 *   <li>Loan &amp; EMI applications with underwriting and amortization schedules.</li>
 * </ol>
 */
@SpringBootApplication
@EnableConfigurationProperties(BankProperties.class)
@EnableScheduling
public class CreditCardLifecycleApplication {

    public static void main(String[] args) {
        SpringApplication.run(CreditCardLifecycleApplication.class, args);
    }
}
