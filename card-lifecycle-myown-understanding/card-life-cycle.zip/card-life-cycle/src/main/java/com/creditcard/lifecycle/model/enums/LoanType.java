package com.creditcard.lifecycle.model.enums;

/** Kinds of credit facilities the customer can apply for. */
public enum LoanType {
    /** Stand-alone personal loan disbursed to the customer's bank account. */
    PERSONAL_LOAN,
    /** Convert an existing large purchase on the card into monthly instalments. */
    EMI_CONVERSION,
    /** Move an outstanding revolving balance onto a fixed EMI plan. */
    BALANCE_TRANSFER
}
