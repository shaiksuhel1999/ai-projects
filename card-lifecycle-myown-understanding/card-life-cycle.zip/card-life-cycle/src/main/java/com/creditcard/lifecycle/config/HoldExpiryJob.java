package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.service.TransactionService;
import com.creditcard.lifecycle.support.BatchExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Releases authorization holds that were never captured. Real issuers drop an
 * auth hold after a few days; this job reverses stale AUTHORIZED transactions so
 * the held credit is freed. Each hold is expired in its own transaction.
 *
 * <p>Only registered when {@code bank.auth.expiry-enabled=true}.
 */
@Component
@ConditionalOnProperty(prefix = "bank.auth", name = "expiry-enabled", havingValue = "true")
public class HoldExpiryJob {

    private static final Logger log = LoggerFactory.getLogger(HoldExpiryJob.class);

    private final TransactionService transactionService;
    private final BatchExecutor batch;
    private final com.creditcard.lifecycle.config.BankProperties bank;

    public HoldExpiryJob(TransactionService transactionService, BatchExecutor batch,
                         com.creditcard.lifecycle.config.BankProperties bank) {
        this.transactionService = transactionService;
        this.batch = batch;
        this.bank = bank;
    }

    @Scheduled(fixedDelayString = "${bank.auth.check-interval-ms:45000}",
            initialDelayString = "${bank.auth.check-interval-ms:45000}")
    public void expireStaleHolds() {
        LocalDateTime cutoff = LocalDateTime.now().minusDays(bank.getAuth().getHoldExpiryDays());
        List<Long> ids = transactionService.staleHoldIds(cutoff);
        int expired = 0;
        for (Long id : ids) {
            if (batch.call(() -> transactionService.expireHold(id)).orElse(false)) {
                expired++;
            }
        }
        if (expired > 0) {
            log.info("[auto-hold-expiry] released {} stale hold(s)", expired);
        }
    }
}
