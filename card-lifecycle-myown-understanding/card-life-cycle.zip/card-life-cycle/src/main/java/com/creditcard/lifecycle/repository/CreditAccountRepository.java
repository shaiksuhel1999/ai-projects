package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.CreditAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CreditAccountRepository extends JpaRepository<CreditAccount, Long> {
    List<CreditAccount> findByCustomerId(Long customerId);

    /** Accounts enrolled in autopay whose payment due date has arrived. */
    List<CreditAccount> findByAutopayEnabledTrueAndPaymentDueDateLessThanEqual(LocalDate date);
}
