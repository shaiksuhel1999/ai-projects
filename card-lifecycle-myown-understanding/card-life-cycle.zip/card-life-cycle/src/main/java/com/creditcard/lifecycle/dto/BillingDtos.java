package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Statement;

import java.math.BigDecimal;
import java.time.LocalDate;

public final class BillingDtos {

    private BillingDtos() {
    }

    public record StatementResponse(
            Long statementId,
            Long accountId,
            LocalDate statementDate,
            LocalDate dueDate,
            BigDecimal openingBalance,
            BigDecimal purchases,
            BigDecimal cashAdvances,
            BigDecimal emiCharges,
            BigDecimal fees,
            BigDecimal interest,
            BigDecimal paymentsAndCredits,
            BigDecimal closingBalance,
            BigDecimal minimumDue,
            String status) {

        public static StatementResponse from(Statement s) {
            return new StatementResponse(
                    s.getId(),
                    s.getAccount().getId(),
                    s.getStatementDate(),
                    s.getDueDate(),
                    s.getOpeningBalance(),
                    s.getPurchases(),
                    s.getCashAdvances(),
                    s.getEmiCharges(),
                    s.getFees(),
                    s.getInterest(),
                    s.getPaymentsAndCredits(),
                    s.getClosingBalance(),
                    s.getMinimumDue(),
                    s.getStatus().name());
        }
    }
}
