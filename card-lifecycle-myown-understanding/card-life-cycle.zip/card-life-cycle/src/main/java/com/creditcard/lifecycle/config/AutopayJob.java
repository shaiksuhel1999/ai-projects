package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.service.AutopayService;
import com.creditcard.lifecycle.support.BatchExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Runs the autopay batch periodically, auto-debiting each enrolled account whose
 * due date has arrived &mdash; each account in its own transaction.
 *
 * <p>Only registered when {@code bank.autopay.auto-enabled=true}.
 */
@Component
@ConditionalOnProperty(prefix = "bank.autopay", name = "auto-enabled", havingValue = "true")
public class AutopayJob {

    private static final Logger log = LoggerFactory.getLogger(AutopayJob.class);

    private final AutopayService autopayService;
    private final BatchExecutor batch;

    public AutopayJob(AutopayService autopayService, BatchExecutor batch) {
        this.autopayService = autopayService;
        this.batch = batch;
    }

    @Scheduled(fixedDelayString = "${bank.autopay.interval-ms:60000}",
            initialDelayString = "${bank.autopay.interval-ms:60000}")
    public void runAutopay() {
        List<Long> ids = autopayService.autopayDueIds();
        int paid = 0;
        for (Long id : ids) {
            if (batch.call(() -> autopayService.payAccount(id)).orElse(false)) {
                paid++;
            }
        }
        if (paid > 0) {
            log.info("[auto-autopay] executed on {} account(s)", paid);
        }
    }
}
