package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.PaymentDtos.PaymentRequest;
import com.creditcard.lifecycle.dto.PaymentDtos.PaymentResponse;
import com.creditcard.lifecycle.model.Payment;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Monthly payments against a credit account. */
@RestController
@RequestMapping("/api/accounts/{accountId}/payments")
@Tag(name = "7. Payments", description = "Make monthly payments: minimum due / total due / custom")
public class PaymentController {

    private final PaymentService paymentService;
    private final CardService cardService;

    public PaymentController(PaymentService paymentService, CardService cardService) {
        this.paymentService = paymentService;
        this.cardService = cardService;
    }

    @PostMapping
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "Pay the minimum due, total due, or a custom amount")
    public PaymentResponse pay(@PathVariable Long accountId, @Valid @RequestBody PaymentRequest req) {
        Payment payment = paymentService.pay(accountId, req);
        var account = cardService.getAccount(accountId);
        return PaymentResponse.from(payment, account.getCurrentBalance(),
                account.getAvailableCredit(), account.getStatementRemaining());
    }

    @GetMapping
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "List all payments on the account (newest first)")
    public List<PaymentResponse> list(@PathVariable Long accountId) {
        var account = cardService.getAccount(accountId);
        return paymentService.listByAccount(accountId).stream()
                .map(p -> PaymentResponse.from(p, account.getCurrentBalance(),
                        account.getAvailableCredit(), account.getStatementRemaining()))
                .toList();
    }
}
