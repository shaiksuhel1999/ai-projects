package com.creditcard.lifecycle.model.enums;

/** How much of the statement the cardholder chooses to pay. */
public enum PaymentType {
    /** Pay exactly the minimum amount due to stay current (interest still accrues). */
    MINIMUM_DUE,
    /** Pay the full statement balance (avoids interest on purchases). */
    TOTAL_DUE,
    /** Pay a caller-specified amount. */
    CUSTOM
}
