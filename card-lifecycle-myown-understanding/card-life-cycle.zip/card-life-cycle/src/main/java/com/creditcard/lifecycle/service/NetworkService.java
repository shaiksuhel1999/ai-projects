package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.service.IssuerService.AuthResult;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * The card network / scheme (Visa, Mastercard, RuPay ...). It receives the
 * authorization request from the acquirer, routes it to the correct issuer
 * based on the card brand (derived from the BIN), and relays the response back.
 *
 * <p>In this simulation there is a single issuer host, so routing is a thin
 * pass-through &mdash; but keeping it as its own hop mirrors the real four-party model.
 */
@Service
public class NetworkService {

    private final IssuerService issuerService;

    public NetworkService(IssuerService issuerService) {
        this.issuerService = issuerService;
    }

    public AuthResult route(Card card, Merchant merchant, BigDecimal amount, String currency) {
        // Brand-based routing would select an issuer host here; we have one issuer.
        return issuerService.authorize(card, merchant, amount, currency);
    }

    public String brandLabel(Card card) {
        return card.getBrand().name();
    }
}
