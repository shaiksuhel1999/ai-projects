package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Customer;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public final class CustomerDtos {

    private CustomerDtos() {
    }

    public record CreateCustomerRequest(
            @NotBlank String fullName,
            @NotBlank @Email String email,
            String phone,
            @NotNull @PositiveOrZero BigDecimal annualIncome,
            @Min(300) int creditScore) {
    }

    public record CustomerResponse(
            Long id,
            String fullName,
            String email,
            String phone,
            BigDecimal annualIncome,
            int creditScore,
            boolean kycVerified) {

        public static CustomerResponse from(Customer c) {
            return new CustomerResponse(c.getId(), c.getFullName(), c.getEmail(), c.getPhone(),
                    c.getAnnualIncome(), c.getCreditScore(), c.isKycVerified());
        }
    }
}
