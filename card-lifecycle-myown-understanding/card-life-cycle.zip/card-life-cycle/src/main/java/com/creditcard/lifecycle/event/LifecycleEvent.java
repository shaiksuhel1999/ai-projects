package com.creditcard.lifecycle.event;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * An immutable real-time event describing something that just happened in the
 * card lifecycle. Published via Spring's ApplicationEventPublisher and fanned
 * out to SSE subscribers by {@code EventBroadcaster}.
 */
public record LifecycleEvent(
        long seq,
        EventType type,
        LocalDateTime timestamp,
        String message,
        Long accountId,
        Long cardId,
        String transactionReference,
        BigDecimal amount,
        Map<String, Object> details) {

    private static final AtomicLong SEQUENCE = new AtomicLong();

    public static LifecycleEvent of(EventType type, String message, Long accountId, Long cardId,
                                    String transactionReference, BigDecimal amount, Map<String, Object> details) {
        return new LifecycleEvent(SEQUENCE.incrementAndGet(), type, LocalDateTime.now(), message,
                accountId, cardId, transactionReference, amount, details == null ? Map.of() : details);
    }
}
