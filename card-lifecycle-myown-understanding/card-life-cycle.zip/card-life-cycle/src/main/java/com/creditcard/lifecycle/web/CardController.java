package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.AccountDtos.AccountResponse;
import com.creditcard.lifecycle.dto.CardDtos.CashAdvanceRequest;
import com.creditcard.lifecycle.dto.CardDtos.CardResponse;
import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.TransactionResponse;
import com.creditcard.lifecycle.service.CardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cards")
@Tag(name = "3. Card lifecycle", description = "Issue, activate, block/unblock, close a card; view the credit account")
public class CardController {

    private final CardService cardService;

    public CardController(CardService cardService) {
        this.cardService = cardService;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Issue a card and its backing credit account")
    public ResponseEntity<CardResponse> issue(@Valid @RequestBody IssueCardRequest req) {
        CardResponse body = CardResponse.from(cardService.issueCard(req));
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    @GetMapping("/{cardId}")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Fetch a card")
    public CardResponse get(@PathVariable Long cardId) {
        return CardResponse.from(cardService.get(cardId));
    }

    @PostMapping("/{cardId}/activate")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Activate an issued card")
    public CardResponse activate(@PathVariable Long cardId) {
        return CardResponse.from(cardService.activate(cardId));
    }

    @PostMapping("/{cardId}/block")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Block a card (lost/stolen/fraud)")
    public CardResponse block(@PathVariable Long cardId) {
        return CardResponse.from(cardService.block(cardId));
    }

    @PostMapping("/{cardId}/unblock")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Unblock a previously blocked card")
    public CardResponse unblock(@PathVariable Long cardId) {
        return CardResponse.from(cardService.unblock(cardId));
    }

    @PostMapping("/{cardId}/close")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Permanently close a card")
    public CardResponse close(@PathVariable Long cardId) {
        return CardResponse.from(cardService.close(cardId));
    }

    @PostMapping("/{cardId}/cash-advance")
    @PreAuthorize("@access.ownsCard(authentication, #cardId)")
    @Operation(summary = "Draw a cash advance against the card")
    public TransactionResponse cashAdvance(@PathVariable Long cardId,
                                           @Valid @RequestBody CashAdvanceRequest req) {
        return TransactionResponse.from(cardService.cashAdvance(cardId, req.amount()));
    }

    @GetMapping("/accounts/{accountId}")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "View the credit account snapshot (limits, balance, available credit, dues)")
    public AccountResponse account(@PathVariable Long accountId) {
        return AccountResponse.from(cardService.getAccount(accountId));
    }
}
