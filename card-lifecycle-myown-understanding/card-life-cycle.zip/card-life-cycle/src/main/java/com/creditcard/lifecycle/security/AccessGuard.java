package com.creditcard.lifecycle.security;

import com.creditcard.lifecycle.repository.CardRepository;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Ownership checks used from {@code @PreAuthorize} SpEL (bean name {@code access}).
 * ADMINs pass everything; a CUSTOMER passes only for accounts/cards belonging to
 * their linked customer.
 */
@Component("access")
public class AccessGuard {

    private final CreditAccountRepository accounts;
    private final CardRepository cards;

    public AccessGuard(CreditAccountRepository accounts, CardRepository cards) {
        this.accounts = accounts;
        this.cards = cards;
    }

    @Transactional(readOnly = true)
    public boolean ownsAccount(Authentication auth, Long accountId) {
        if (isAdmin(auth)) {
            return true;
        }
        Long customerId = customerId(auth);
        return customerId != null && accounts.findById(accountId)
                .map(a -> customerId.equals(a.getCustomer().getId()))
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public boolean ownsCard(Authentication auth, Long cardId) {
        if (isAdmin(auth)) {
            return true;
        }
        Long customerId = customerId(auth);
        return customerId != null && cards.findById(cardId)
                .map(c -> customerId.equals(c.getAccount().getCustomer().getId()))
                .orElse(false);
    }

    private boolean isAdmin(Authentication auth) {
        return auth != null && auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
    }

    private Long customerId(Authentication auth) {
        if (auth != null && auth.getPrincipal() instanceof AppUserPrincipal principal) {
            return principal.getCustomerId();
        }
        return null;
    }
}
