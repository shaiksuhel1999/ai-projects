package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer create(CreateCustomerRequest req) {
        customerRepository.findByEmail(req.email()).ifPresent(c -> {
            throw new IllegalArgumentException("A customer already exists with email " + req.email());
        });
        Customer customer = new Customer(req.fullName(), req.email(), req.phone(),
                req.annualIncome(), req.creditScore());
        // KYC is assumed completed as part of onboarding in this simulation.
        customer.setKycVerified(true);
        return customerRepository.save(customer);
    }

    @Transactional(readOnly = true)
    public Customer get(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer", id));
    }
}
