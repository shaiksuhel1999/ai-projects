package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.CreditAccount;

import java.math.BigDecimal;
import java.time.LocalDate;

public final class AccountDtos {

    private AccountDtos() {
    }

    /** Full financial snapshot of a revolving credit account. */
    public record AccountResponse(
            Long accountId,
            Long customerId,
            String customerName,
            BigDecimal creditLimit,
            BigDecimal currentBalance,
            BigDecimal postedBalance,
            BigDecimal memoBalance,
            BigDecimal holdAmount,
            BigDecimal availableCredit,
            BigDecimal apr,
            String status,
            BigDecimal currentStatementBalance,
            BigDecimal statementRemaining,
            BigDecimal minimumDue,
            LocalDate paymentDueDate,
            long rewardPoints,
            boolean autopayEnabled,
            String autopayType) {

        public static AccountResponse from(CreditAccount a) {
            return new AccountResponse(
                    a.getId(),
                    a.getCustomer().getId(),
                    a.getCustomer().getFullName(),
                    a.getCreditLimit(),
                    a.getCurrentBalance(),
                    a.getPostedBalance(),
                    a.getMemoBalance(),
                    a.getHoldAmount(),
                    a.getAvailableCredit(),
                    a.getApr(),
                    a.getStatus().name(),
                    a.getCurrentStatementBalance(),
                    a.getStatementRemaining(),
                    a.getMinimumDue(),
                    a.getPaymentDueDate(),
                    a.getRewardPoints(),
                    a.isAutopayEnabled(),
                    a.getAutopayType() == null ? null : a.getAutopayType().name());
        }
    }
}
