package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Card;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public final class CardDtos {

    private CardDtos() {
    }

    /**
     * Apply for / issue a card. If {@code creditLimit} is omitted the issuer
     * derives a limit from the customer's income and credit score.
     */
    public record IssueCardRequest(
            @NotNull Long customerId,
            @Positive BigDecimal creditLimit,
            String brand,
            @Min(1) Integer statementDay) {
    }

    public record CardResponse(
            Long cardId,
            Long accountId,
            String maskedPan,
            String token,
            String brand,
            int expiryMonth,
            int expiryYear,
            String status) {

        public static CardResponse from(Card card) {
            return new CardResponse(
                    card.getId(),
                    card.getAccount().getId(),
                    card.getMaskedPan(),
                    card.getToken(),
                    card.getBrand().name(),
                    card.getExpiryMonth(),
                    card.getExpiryYear(),
                    card.getStatus().name());
        }
    }

    /** Cash advance drawn against the card (higher APR, counts to cash limit). */
    public record CashAdvanceRequest(
            @NotNull Long cardId,
            @NotNull @Positive BigDecimal amount) {
    }
}
