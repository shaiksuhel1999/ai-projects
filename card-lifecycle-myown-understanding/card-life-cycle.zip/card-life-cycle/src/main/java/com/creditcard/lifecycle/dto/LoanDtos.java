package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Installment;
import com.creditcard.lifecycle.model.Loan;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public final class LoanDtos {

    private LoanDtos() {
    }

    /** Apply for a stand-alone personal loan against a credit account. */
    public record LoanApplicationRequest(
            @NotNull Long accountId,
            @NotNull @Positive BigDecimal principal,
            @Min(3) int tenureMonths,
            String purpose) {
    }

    /** Convert an existing card purchase into an EMI plan. */
    public record EmiConversionRequest(
            @NotNull Long transactionId,
            @Min(3) int tenureMonths) {
    }

    public record InstallmentResponse(
            int sequence,
            LocalDate dueDate,
            BigDecimal emiAmount,
            BigDecimal principalComponent,
            BigDecimal interestComponent,
            BigDecimal balanceAfter,
            String status,
            LocalDateTime paidAt) {

        public static InstallmentResponse from(Installment i) {
            return new InstallmentResponse(
                    i.getSequence(),
                    i.getDueDate(),
                    i.getEmiAmount(),
                    i.getPrincipalComponent(),
                    i.getInterestComponent(),
                    i.getBalanceAfter(),
                    i.getStatus().name(),
                    i.getPaidAt());
        }
    }

    public record LoanResponse(
            Long loanId,
            Long accountId,
            String type,
            String status,
            BigDecimal principal,
            BigDecimal annualRate,
            int tenureMonths,
            BigDecimal emiAmount,
            BigDecimal outstandingPrincipal,
            String purpose,
            String decisionReason,
            Long sourceTransactionId,
            List<InstallmentResponse> schedule) {

        public static LoanResponse summary(Loan loan) {
            return build(loan, List.of());
        }

        public static LoanResponse withSchedule(Loan loan, List<Installment> installments) {
            return build(loan, installments.stream().map(InstallmentResponse::from).toList());
        }

        private static LoanResponse build(Loan loan, List<InstallmentResponse> schedule) {
            return new LoanResponse(
                    loan.getId(),
                    loan.getAccount().getId(),
                    loan.getType().name(),
                    loan.getStatus().name(),
                    loan.getPrincipal(),
                    loan.getAnnualRate(),
                    loan.getTenureMonths(),
                    loan.getEmiAmount(),
                    loan.getOutstandingPrincipal(),
                    loan.getPurpose(),
                    loan.getDecisionReason(),
                    loan.getSourceTransactionId(),
                    schedule);
        }
    }
}
