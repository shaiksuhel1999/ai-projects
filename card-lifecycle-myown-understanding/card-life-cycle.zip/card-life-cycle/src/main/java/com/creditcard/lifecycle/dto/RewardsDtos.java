package com.creditcard.lifecycle.dto;

import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public final class RewardsDtos {

    private RewardsDtos() {
    }

    public record RedeemRequest(
            @Positive long points) {
    }

    public record RewardsResponse(
            Long accountId,
            long rewardPoints,
            BigDecimal pointValue,
            BigDecimal redeemableCash) {
    }

    public record RedemptionResponse(
            Long accountId,
            long pointsRedeemed,
            BigDecimal cashCredited,
            long remainingPoints) {
    }
}
