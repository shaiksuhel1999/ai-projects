package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AuthDecision;
import com.creditcard.lifecycle.model.enums.AuthResponseCode;
import com.creditcard.lifecycle.repository.CardRepository;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.service.IssuerService.AuthResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.ThreadLocalRandom;

/**
 * The acquiring bank / payment gateway. This is the entry point the POS terminal
 * talks to. It validates the merchant, resolves the card from its network token,
 * and forwards the request to the card network, then formats the ISO 8583-style
 * response the POS prints.
 *
 * <p>Flow: {@code POS terminal -> Acquirer -> Card Network -> Issuer} and back.
 */
@Service
@Transactional
public class AcquirerService {

    private final CardRepository cardRepository;
    private final MerchantRepository merchantRepository;
    private final NetworkService networkService;
    private final LifecycleEvents events;

    public AcquirerService(CardRepository cardRepository,
                           MerchantRepository merchantRepository,
                           NetworkService networkService,
                           LifecycleEvents events) {
        this.cardRepository = cardRepository;
        this.merchantRepository = merchantRepository;
        this.networkService = networkService;
        this.events = events;
    }

    public AuthorizeResponse authorize(AuthorizeRequest req) {
        Merchant merchant = merchantRepository.findById(req.merchantId())
                .orElseThrow(() -> new ResourceNotFoundException("Merchant", req.merchantId()));

        Card card = cardRepository.findByToken(req.cardToken()).orElse(null);
        if (card == null) {
            // An unknown token gets a plain decline at the acquirer, never reaching an issuer.
            AuthResponseCode code = AuthResponseCode.INVALID_CARD;
            events.publish(EventType.AUTH_DECLINED,
                    "Declined " + req.amount() + " [" + code.code() + " " + code.description() + "]",
                    null, null, null, req.amount());
            String trace = "POS[" + merchant.getTerminalId() + "] -> Acquirer[" + merchant.getAcquirerName()
                    + "] -> DECLINE(" + code.code() + " " + code.description() + ")";
            return new AuthorizeResponse(AuthDecision.DECLINED.name(), code.code(), code.description(),
                    null, null, newStan(), newRrn(), "0110", req.amount(), null, code.name(), trace);
        }

        AuthResult result = networkService.route(card, merchant, req.amount(), req.currency());
        Transaction txn = result.transaction();

        String trace = "POS[" + merchant.getTerminalId() + "] -> Acquirer[" + merchant.getAcquirerName()
                + "] -> Network[" + networkService.brandLabel(card) + "] -> Issuer => "
                + result.decision() + "(" + result.responseCode().code() + ")";

        return new AuthorizeResponse(
                result.decision().name(),
                txn.getResponseCode(),
                txn.getResponseText(),
                txn.getReference(),
                txn.getAuthCode(),
                txn.getStan(),
                txn.getRrn(),
                txn.getMti(),
                req.amount(),
                card.getAccount().getAvailableCredit(),
                txn.getReason(),
                trace);
    }

    private String newStan() {
        return String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }

    private String newRrn() {
        long tail = Math.abs(System.nanoTime() % 1_000_000L);
        return String.format("%06d%06d", ThreadLocalRandom.current().nextInt(1_000_000), tail);
    }
}
