package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Dispute;
import com.creditcard.lifecycle.model.enums.DisputeReasonCode;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public final class DisputeDtos {

    private DisputeDtos() {
    }

    public record OpenDisputeRequest(
            @NotNull Long transactionId,
            @NotNull DisputeReasonCode reasonCode,
            String note) {
    }

    public record RepresentRequest(String note) {
    }

    public record ResolveRequest(
            @NotNull Boolean won,
            String note) {
    }

    public record ReportFraudRequest(String note) {
    }

    public record DisputeResponse(
            Long disputeId,
            Long accountId,
            Long transactionId,
            String transactionReference,
            String reasonCode,
            String reasonNetworkCode,
            String reasonDescription,
            BigDecimal amount,
            String status,
            boolean provisionalCreditIssued,
            String note,
            String resolutionNote,
            LocalDateTime createdAt,
            LocalDateTime resolvedAt) {

        public static DisputeResponse from(Dispute d) {
            DisputeReasonCode rc = d.getReasonCode();
            return new DisputeResponse(
                    d.getId(),
                    d.getAccount().getId(),
                    d.getTransaction().getId(),
                    d.getTransaction().getReference(),
                    rc.name(),
                    rc.networkCode(),
                    rc.description(),
                    d.getAmount(),
                    d.getStatus().name(),
                    d.isProvisionalCreditIssued(),
                    d.getNote(),
                    d.getResolutionNote(),
                    d.getCreatedAt(),
                    d.getResolvedAt());
        }
    }
}
