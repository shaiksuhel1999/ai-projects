package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.support.Money;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Rewards / cashback engine. Points are earned on purchases (with per-category
 * multipliers) and can be redeemed for a statement credit.
 */
@Service
@Transactional
public class RewardsService {

    private final CreditAccountRepository accountRepository;
    private final PostingService postingService;
    private final BankProperties bank;
    private final LifecycleEvents events;

    public RewardsService(CreditAccountRepository accountRepository,
                          PostingService postingService,
                          BankProperties bank,
                          LifecycleEvents events) {
        this.accountRepository = accountRepository;
        this.postingService = postingService;
        this.bank = bank;
        this.events = events;
    }

    /** Accrue points for a captured purchase. Called inline when a purchase clears. */
    public long accrue(Transaction purchase) {
        if (purchase.getType() != TransactionType.PURCHASE) {
            return 0;
        }
        BigDecimal amount = purchase.getCapturedAmount() == null ? purchase.getAmount() : purchase.getCapturedAmount();
        long points = pointsFor(amount, purchase.getMerchant());
        if (points <= 0) {
            return 0;
        }
        CreditAccount account = purchase.getAccount();
        account.setRewardPoints(account.getRewardPoints() + points);

        events.publish(EventType.REWARDS_EARNED,
                "Earned " + points + " points on " + amount
                        + "; balance " + account.getRewardPoints() + " pts",
                account.getId(), purchase.getCard() == null ? null : purchase.getCard().getId(),
                purchase.getReference(), amount);
        return points;
    }

    /**
     * Claw back points proportional to a refunded amount, so a buy-then-refund
     * cycle cannot inflate the points balance. Never drives the balance negative.
     */
    public long reverseAccrual(Transaction purchase, BigDecimal refundedAmount) {
        if (purchase.getType() != TransactionType.PURCHASE) {
            return 0;
        }
        long points = pointsFor(Money.of(refundedAmount), purchase.getMerchant());
        if (points <= 0) {
            return 0;
        }
        CreditAccount account = purchase.getAccount();
        long clawback = Math.min(points, account.getRewardPoints());
        account.setRewardPoints(account.getRewardPoints() - clawback);
        return clawback;
    }

    private long pointsFor(BigDecimal amount, Merchant merchant) {
        BankProperties.Rewards cfg = bank.getRewards();
        BigDecimal multiplier = categoryMultiplier(merchant, cfg);
        return amount.multiply(cfg.getBasePointsPerUnit()).multiply(multiplier)
                .setScale(0, RoundingMode.DOWN).longValueExact();
    }

    /** Redeem points for a statement credit (posted directly to the ledger). */
    public Redemption redeem(Long accountId, long points) {
        CreditAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
        if (points <= 0) {
            throw new BusinessException("Points to redeem must be positive");
        }
        if (points > account.getRewardPoints()) {
            throw new BusinessException("Insufficient points: have " + account.getRewardPoints()
                    + ", requested " + points);
        }
        BigDecimal cash = Money.of(BigDecimal.valueOf(points).multiply(bank.getRewards().getPointsToCash()));
        account.setRewardPoints(account.getRewardPoints() - points);
        postingService.directPost(account, TransactionType.REWARD_REDEMPTION, cash,
                "Redeemed " + points + " reward points", null);

        events.publish(EventType.REWARDS_REDEEMED,
                "Redeemed " + points + " points for " + cash + " statement credit",
                accountId, null, null, cash);
        return new Redemption(points, cash, account.getRewardPoints());
    }

    @Transactional(readOnly = true)
    public CreditAccount getAccount(Long accountId) {
        return accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
    }

    private BigDecimal categoryMultiplier(Merchant merchant, BankProperties.Rewards cfg) {
        if (merchant == null || merchant.getMcc() == null) {
            return BigDecimal.ONE;
        }
        return cfg.getCategoryMultipliers().getOrDefault(merchant.getMcc(), BigDecimal.ONE);
    }

    /** Result of a redemption. */
    public record Redemption(long pointsRedeemed, BigDecimal cashCredited, long remainingPoints) {
    }
}
