package com.creditcard.lifecycle.model.enums;

/**
 * ISO 8583-style authorization response codes (field 39). These are the exact
 * two-digit codes a real issuer returns to the network and POS terminal.
 */
public enum AuthResponseCode {

    APPROVED("00", "Approved", AuthDecision.APPROVED),
    REFER_TO_ISSUER("01", "Refer to card issuer", AuthDecision.DECLINED),
    DO_NOT_HONOR("05", "Do not honor", AuthDecision.DECLINED),
    INVALID_CARD("14", "Invalid card number", AuthDecision.DECLINED),
    LOST_OR_STOLEN("43", "Stolen / blocked card", AuthDecision.DECLINED),
    INSUFFICIENT_FUNDS("51", "Insufficient funds / over credit limit", AuthDecision.DECLINED),
    EXPIRED_CARD("54", "Expired card", AuthDecision.DECLINED),
    TRANSACTION_NOT_PERMITTED("57", "Transaction not permitted to cardholder", AuthDecision.DECLINED),
    SUSPECTED_FRAUD("59", "Suspected fraud", AuthDecision.DECLINED),
    EXCEEDS_AMOUNT_LIMIT("61", "Exceeds amount limit", AuthDecision.DECLINED),
    RESTRICTED_CARD("62", "Restricted card (blocked merchant or region)", AuthDecision.DECLINED),
    EXCEEDS_VELOCITY("65", "Exceeds withdrawal frequency limit", AuthDecision.DECLINED),
    ACCOUNT_ISSUE("78", "Account frozen or delinquent", AuthDecision.DECLINED),
    SYSTEM_ERROR("96", "System malfunction", AuthDecision.DECLINED);

    private final String code;
    private final String description;
    private final AuthDecision decision;

    AuthResponseCode(String code, String description, AuthDecision decision) {
        this.code = code;
        this.description = description;
        this.decision = decision;
    }

    public String code() {
        return code;
    }

    public String description() {
        return description;
    }

    public AuthDecision decision() {
        return decision;
    }

    public boolean approved() {
        return decision == AuthDecision.APPROVED;
    }
}
