package com.creditcard.lifecycle.model.enums;

/** Payment status of a generated billing statement. */
public enum StatementStatus {
    GENERATED,
    PARTIALLY_PAID,
    PAID,
    OVERDUE
}
