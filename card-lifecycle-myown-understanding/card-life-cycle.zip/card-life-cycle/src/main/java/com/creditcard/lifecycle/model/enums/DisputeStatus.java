package com.creditcard.lifecycle.model.enums;

/** Lifecycle of a cardholder dispute / chargeback case. */
public enum DisputeStatus {
    /** Raised by the cardholder, awaiting review. */
    OPEN,
    /** Issuer is investigating. */
    UNDER_REVIEW,
    /** Temporary credit granted to the cardholder pending the outcome. */
    PROVISIONAL_CREDIT_ISSUED,
    /** Merchant has re-presented the transaction with evidence. */
    REPRESENTMENT,
    /** Resolved in the cardholder's favour (chargeback stands). Terminal. */
    WON,
    /** Resolved in the merchant's favour (provisional credit reversed). Terminal. */
    LOST,
    /** Case closed. */
    CLOSED
}
