package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.dto.PaymentDtos.PaymentRequest;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Payment;
import com.creditcard.lifecycle.model.Statement;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AccountStatus;
import com.creditcard.lifecycle.model.enums.PaymentStatus;
import com.creditcard.lifecycle.model.enums.PaymentType;
import com.creditcard.lifecycle.model.enums.StatementStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.repository.PaymentRepository;
import com.creditcard.lifecycle.repository.StatementRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * The monthly-payment engine. Applies a payment (minimum / total / custom) to the
 * account, reduces the owed balance, updates the current statement's paid status,
 * and clears delinquency once the minimum is met.
 */
@Service
@Transactional
public class PaymentService {

    private final CreditAccountRepository accountRepository;
    private final PaymentRepository paymentRepository;
    private final StatementRepository statementRepository;
    private final TransactionRepository transactionRepository;
    private final LifecycleEvents events;
    private final ReferenceGenerator references;

    public PaymentService(CreditAccountRepository accountRepository,
                          PaymentRepository paymentRepository,
                          StatementRepository statementRepository,
                          TransactionRepository transactionRepository,
                          LifecycleEvents events,
                          ReferenceGenerator references) {
        this.accountRepository = accountRepository;
        this.paymentRepository = paymentRepository;
        this.statementRepository = statementRepository;
        this.transactionRepository = transactionRepository;
        this.events = events;
        this.references = references;
    }

    public Payment pay(Long accountId, PaymentRequest req) {
        CreditAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));

        BigDecimal amount = resolveAmount(account, req);
        if (!Money.isPositive(amount)) {
            throw new BusinessException("Nothing to pay: the resolved payment amount is zero");
        }
        if (amount.compareTo(account.getCurrentBalance()) > 0) {
            throw new BusinessException("Payment " + amount + " exceeds the outstanding balance "
                    + account.getCurrentBalance());
        }

        // Apply the payment: reduce what is owed and track it against the cycle.
        account.setCurrentBalance(Money.of(account.getCurrentBalance().subtract(amount)));
        account.setPaidThisCycle(Money.of(account.getPaidThisCycle().add(amount)));
        account.setStatementRemaining(
                Money.max(BigDecimal.ZERO.setScale(2), account.getStatementRemaining().subtract(amount)));

        // Clear delinquency once the minimum due has been met this cycle.
        if (account.getStatus() == AccountStatus.DELINQUENT
                && account.getPaidThisCycle().compareTo(account.getMinimumDue()) >= 0) {
            account.setStatus(AccountStatus.ACTIVE);
        }

        updateStatementStatus(account);

        Payment payment = new Payment(account, amount, req.type(),
                req.method() == null || req.method().isBlank() ? "NETBANKING" : req.method());
        payment.setStatus(PaymentStatus.SUCCESS);
        paymentRepository.save(payment);

        // Record a PAYMENT posting so it shows up on the statement and ledger.
        Transaction txn = new Transaction();
        txn.setReference(references.next("PAY"));
        txn.setAccount(account);
        txn.setType(TransactionType.PAYMENT);
        txn.setStatus(TransactionStatus.POSTED);
        txn.setAmount(amount);
        txn.setReason("PAYMENT_" + req.type());
        transactionRepository.save(txn);

        events.publish(EventType.PAYMENT,
                "Payment " + amount + " (" + req.type() + "); balance now " + account.getCurrentBalance(),
                account.getId(), null, txn.getReference(), amount);
        return payment;
    }

    private BigDecimal resolveAmount(CreditAccount account, PaymentRequest req) {
        return switch (req.type()) {
            case MINIMUM_DUE -> account.getMinimumDue();
            case TOTAL_DUE -> account.getCurrentStatementBalance();
            case CUSTOM -> {
                if (req.amount() == null) {
                    throw new BusinessException("A custom payment requires an 'amount'");
                }
                yield Money.of(req.amount());
            }
        };
    }

    private void updateStatementStatus(CreditAccount account) {
        Statement latest = statementRepository
                .findFirstByAccountIdOrderByStatementDateDesc(account.getId()).orElse(null);
        if (latest == null) {
            return;
        }
        if (account.getStatementRemaining().signum() == 0) {
            latest.setStatus(StatementStatus.PAID);
        } else if (account.getPaidThisCycle().compareTo(account.getMinimumDue()) >= 0) {
            latest.setStatus(StatementStatus.PARTIALLY_PAID);
        } else {
            latest.setStatus(StatementStatus.GENERATED);
        }
    }

    @Transactional(readOnly = true)
    public List<Payment> listByAccount(Long accountId) {
        return paymentRepository.findByAccountIdOrderByCreatedAtDesc(accountId);
    }

    /** Convenience: the current payable amount for a given payment type. */
    @Transactional(readOnly = true)
    public BigDecimal previewAmount(Long accountId, PaymentType type) {
        CreditAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
        return switch (type) {
            case MINIMUM_DUE -> account.getMinimumDue();
            case TOTAL_DUE -> account.getCurrentStatementBalance();
            case CUSTOM -> BigDecimal.ZERO.setScale(2);
        };
    }
}
