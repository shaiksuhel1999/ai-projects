package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.DisputeDtos.DisputeResponse;
import com.creditcard.lifecycle.dto.DisputeDtos.ReportFraudRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.CaptureRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.RefundRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.SettlementResponse;
import com.creditcard.lifecycle.dto.TransactionDtos.TransactionResponse;
import com.creditcard.lifecycle.service.DisputeService;
import com.creditcard.lifecycle.service.TransactionService;
import com.creditcard.lifecycle.service.TransactionService.SettlementSummary;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Clearing & settlement: capture, reverse, settle, refund, and inspect transactions. */
@RestController
@RequestMapping("/api/transactions")
@Tag(name = "5. Clearing & settlement", description = "Capture, reverse, settle and refund authorized transactions")
public class TransactionController {

    private final TransactionService transactionService;
    private final DisputeService disputeService;

    public TransactionController(TransactionService transactionService, DisputeService disputeService) {
        this.transactionService = transactionService;
        this.disputeService = disputeService;
    }

    @PostMapping("/{id}/capture")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Merchant captures an authorized transaction (clearing); supports partial capture")
    public TransactionResponse capture(@PathVariable Long id,
                                       @RequestBody(required = false) CaptureRequest req) {
        return TransactionResponse.from(
                transactionService.capture(id, req == null ? null : req.amount()));
    }

    @PostMapping("/{id}/reverse")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Reverse an authorization before capture (releases the hold)")
    public TransactionResponse reverse(@PathVariable Long id) {
        return TransactionResponse.from(transactionService.reverse(id));
    }

    @PostMapping("/settle")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Run the settlement batch over all captured transactions")
    public SettlementResponse settle() {
        SettlementSummary s = transactionService.settleBatch();
        return new SettlementResponse(s.settledCount(), s.settledAmount(),
                s.settledCount() + " transaction(s) settled for " + s.settledAmount());
    }

    @PostMapping("/{id}/refund")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Refund a captured/settled purchase (full or partial)")
    public TransactionResponse refund(@PathVariable Long id, @Valid @RequestBody RefundRequest req) {
        return TransactionResponse.from(transactionService.refund(id, req.amount(), req.note()));
    }

    @PostMapping("/{id}/report-fraud")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Tag a transaction as fraud: blocks the card and auto-opens a FRAUD dispute")
    public DisputeResponse reportFraud(@PathVariable Long id,
                                       @RequestBody(required = false) ReportFraudRequest req) {
        return DisputeResponse.from(disputeService.reportFraud(id, req == null ? null : req.note()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Fetch a transaction")
    public TransactionResponse get(@PathVariable Long id) {
        return TransactionResponse.from(transactionService.get(id));
    }

    @GetMapping("/accounts/{accountId}")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "List all transactions on an account (newest first)")
    public List<TransactionResponse> byAccount(@PathVariable Long accountId) {
        return transactionService.listByAccount(accountId).stream()
                .map(TransactionResponse::from).toList();
    }
}
