package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.dto.RewardsDtos.RedeemRequest;
import com.creditcard.lifecycle.dto.RewardsDtos.RedemptionResponse;
import com.creditcard.lifecycle.dto.RewardsDtos.RewardsResponse;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.service.RewardsService;
import com.creditcard.lifecycle.service.RewardsService.Redemption;
import com.creditcard.lifecycle.support.Money;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

/** Rewards / cashback: view the balance and redeem points for statement credit. */
@RestController
@RequestMapping("/api/accounts/{accountId}/rewards")
@Tag(name = "12. Rewards", description = "Earn points on spend; redeem for statement credit")
public class RewardsController {

    private final RewardsService rewardsService;
    private final BankProperties bank;

    public RewardsController(RewardsService rewardsService, BankProperties bank) {
        this.rewardsService = rewardsService;
        this.bank = bank;
    }

    @GetMapping
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "View the reward-points balance and its redeemable cash value")
    public RewardsResponse balance(@PathVariable Long accountId) {
        CreditAccount account = rewardsService.getAccount(accountId);
        BigDecimal pointValue = bank.getRewards().getPointsToCash();
        BigDecimal cash = Money.of(BigDecimal.valueOf(account.getRewardPoints()).multiply(pointValue));
        return new RewardsResponse(accountId, account.getRewardPoints(), pointValue, cash);
    }

    @PostMapping("/redeem")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "Redeem points for a statement credit")
    public RedemptionResponse redeem(@PathVariable Long accountId, @Valid @RequestBody RedeemRequest req) {
        Redemption r = rewardsService.redeem(accountId, req.points());
        return new RedemptionResponse(accountId, r.pointsRedeemed(), r.cashCredited(), r.remainingPoints());
    }
}
