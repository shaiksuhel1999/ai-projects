package com.creditcard.lifecycle.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** A cardholder / borrower. Owns credit accounts and loan applications. */
@Entity
@Table(name = "customers")
@Getter
@Setter
@NoArgsConstructor
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true)
    private String email;

    private String phone;

    /** Declared gross annual income; drives credit-limit and loan underwriting. */
    @Column(precision = 19, scale = 2)
    private BigDecimal annualIncome = BigDecimal.ZERO;

    /** Bureau-style score (300-900). Drives approve/decline and pricing. */
    private int creditScore = 700;

    private boolean kycVerified = false;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Customer(String fullName, String email, String phone, BigDecimal annualIncome, int creditScore) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.annualIncome = annualIncome;
        this.creditScore = creditScore;
    }
}
