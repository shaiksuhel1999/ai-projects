package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Statement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StatementRepository extends JpaRepository<Statement, Long> {

    List<Statement> findByAccountIdOrderByStatementDateDesc(Long accountId);

    Optional<Statement> findFirstByAccountIdOrderByStatementDateDesc(Long accountId);
}
