package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Payment;
import com.creditcard.lifecycle.model.enums.PaymentType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public final class PaymentDtos {

    private PaymentDtos() {
    }

    /**
     * Make a monthly payment. For {@code MINIMUM_DUE} / {@code TOTAL_DUE} the amount is
     * derived from the account and {@code amount} is ignored; for {@code CUSTOM} it is required.
     */
    public record PaymentRequest(
            @NotNull PaymentType type,
            @Positive BigDecimal amount,
            String method) {
    }

    public record PaymentResponse(
            Long paymentId,
            Long accountId,
            BigDecimal amountPaid,
            String type,
            String status,
            String method,
            BigDecimal newBalance,
            BigDecimal availableCredit,
            BigDecimal statementRemaining,
            LocalDateTime createdAt) {

        public static PaymentResponse from(Payment p, BigDecimal newBalance,
                                           BigDecimal availableCredit, BigDecimal statementRemaining) {
            return new PaymentResponse(
                    p.getId(),
                    p.getAccount().getId(),
                    p.getAmount(),
                    p.getType().name(),
                    p.getStatus().name(),
                    p.getMethod(),
                    newBalance,
                    availableCredit,
                    statementRemaining,
                    p.getCreatedAt());
        }
    }
}
