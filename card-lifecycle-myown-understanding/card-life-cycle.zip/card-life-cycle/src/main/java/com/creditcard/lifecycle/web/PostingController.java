package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.PostingDtos.AdjustmentRequest;
import com.creditcard.lifecycle.dto.PostingDtos.Mode;
import com.creditcard.lifecycle.dto.PostingDtos.PostingCycleResponse;
import com.creditcard.lifecycle.dto.TransactionDtos.TransactionResponse;
import com.creditcard.lifecycle.service.PostingService;
import com.creditcard.lifecycle.service.PostingService.PostingSummary;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.creditcard.lifecycle.dto.PostingDtos.Direction;

/** Auxiliary adjustments and the memo-post → posted ledger cycle. */
@RestController
@RequestMapping("/api")
@Tag(name = "11. Ledger & adjustments", description = "Auxiliary adjustments (memo/posted) and the posting cycle")
public class PostingController {

    private final PostingService postingService;

    public PostingController(PostingService postingService) {
        this.postingService = postingService;
    }

    @PostMapping("/accounts/{accountId}/adjustments")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Post an auxiliary manual adjustment (goodwill credit, fee reversal, correction)")
    public TransactionResponse adjust(@PathVariable Long accountId, @Valid @RequestBody AdjustmentRequest req) {
        boolean memo = req.mode() == null || req.mode() == Mode.MEMO;
        boolean credit = req.direction() == Direction.CREDIT;
        return TransactionResponse.from(
                postingService.adjust(accountId, credit, req.amount(), req.reason(), memo));
    }

    @PostMapping("/posting/run")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Run the posting cycle: hard-post all pending memo entries to the ledger")
    public PostingCycleResponse runPostingCycle() {
        PostingSummary s = postingService.runPostingCycle();
        return new PostingCycleResponse(s.postedCount(), s.postedAmount(),
                s.postedCount() + " memo entr(y/ies) hard-posted for " + s.postedAmount());
    }
}
