package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Dispute;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.CardStatus;
import com.creditcard.lifecycle.model.enums.DisputeReasonCode;
import com.creditcard.lifecycle.model.enums.DisputeStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.DisputeRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;

/**
 * The dispute / chargeback engine. Drives the full case lifecycle:
 * open &rarr; (provisional credit) &rarr; representment &rarr; resolve (won/lost),
 * using {@link PostingService} so the provisional credit is a real memo post that
 * is either hard-posted (won) or reversed (lost).
 */
@Service
@Transactional
public class DisputeService {

    private static final EnumSet<DisputeStatus> TERMINAL =
            EnumSet.of(DisputeStatus.WON, DisputeStatus.LOST, DisputeStatus.CLOSED);

    private final DisputeRepository disputeRepository;
    private final TransactionRepository transactionRepository;
    private final PostingService postingService;
    private final CardService cardService;
    private final LifecycleEvents events;

    public DisputeService(DisputeRepository disputeRepository,
                          TransactionRepository transactionRepository,
                          PostingService postingService,
                          CardService cardService,
                          LifecycleEvents events) {
        this.disputeRepository = disputeRepository;
        this.transactionRepository = transactionRepository;
        this.postingService = postingService;
        this.cardService = cardService;
        this.events = events;
    }

    /** Raise a dispute / chargeback against a posted purchase. */
    public Dispute open(Long transactionId, DisputeReasonCode reasonCode, String note) {
        Transaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", transactionId));
        if (txn.getType() != TransactionType.PURCHASE) {
            throw new BusinessException("Only a purchase can be disputed");
        }
        if (txn.getStatus() != TransactionStatus.CAPTURED && txn.getStatus() != TransactionStatus.SETTLED) {
            throw new BusinessException("Only a captured/settled purchase can be disputed; status = " + txn.getStatus());
        }
        boolean alreadyActive = disputeRepository.findByTransactionId(transactionId).stream()
                .anyMatch(d -> !TERMINAL.contains(d.getStatus()));
        if (alreadyActive) {
            throw new BusinessException("An active dispute already exists for this transaction");
        }

        Dispute dispute = new Dispute();
        dispute.setAccount(txn.getAccount());
        dispute.setTransaction(txn);
        dispute.setReasonCode(reasonCode);
        dispute.setAmount(Money.of(txn.getCapturedAmount()));
        dispute.setStatus(DisputeStatus.OPEN);
        dispute.setNote(note);
        disputeRepository.save(dispute);

        events.publish(EventType.DISPUTE_OPENED,
                "Dispute #" + dispute.getId() + " opened [" + reasonCode.networkCode() + " " + reasonCode + "] on "
                        + txn.getReference() + " for " + dispute.getAmount(),
                txn.getAccount().getId(), null, txn.getReference(), dispute.getAmount());
        events.publish(EventType.CHARGEBACK,
                "Chargeback raised against merchant for " + dispute.getAmount(),
                txn.getAccount().getId(), null, txn.getReference(), dispute.getAmount());
        return dispute;
    }

    /** Grant the cardholder a temporary credit (a memo post) while the case is investigated. */
    public Dispute issueProvisionalCredit(Long disputeId) {
        Dispute dispute = get(disputeId);
        if (TERMINAL.contains(dispute.getStatus())) {
            throw new BusinessException("Dispute is already resolved");
        }
        if (dispute.isProvisionalCreditIssued()) {
            throw new BusinessException("Provisional credit already issued");
        }
        Transaction credit = postingService.memoPost(dispute.getAccount(), TransactionType.PROVISIONAL_CREDIT,
                dispute.getAmount(), "Provisional credit for dispute #" + dispute.getId(), false, dispute.getId());
        dispute.setProvisionalCreditIssued(true);
        dispute.setProvisionalCreditTxnId(credit.getId());
        dispute.setStatus(DisputeStatus.PROVISIONAL_CREDIT_ISSUED);

        events.publish(EventType.PROVISIONAL_CREDIT,
                "Provisional credit " + dispute.getAmount() + " issued for dispute #" + dispute.getId()
                        + " (memo post)",
                dispute.getAccount().getId(), null, credit.getReference(), dispute.getAmount());
        return dispute;
    }

    /** Merchant re-presents the transaction with evidence. */
    public Dispute represent(Long disputeId, String note) {
        Dispute dispute = get(disputeId);
        if (TERMINAL.contains(dispute.getStatus())) {
            throw new BusinessException("Dispute is already resolved");
        }
        dispute.setStatus(DisputeStatus.REPRESENTMENT);
        dispute.setResolutionNote(note);
        events.publish(EventType.REPRESENTMENT,
                "Merchant representment on dispute #" + dispute.getId(),
                dispute.getAccount().getId(), null, null, dispute.getAmount());
        return dispute;
    }

    /** Resolve the case. Won &rarr; the credit is hard-posted; lost &rarr; any provisional credit is reversed. */
    public Dispute resolve(Long disputeId, boolean won, String note) {
        Dispute dispute = get(disputeId);
        if (TERMINAL.contains(dispute.getStatus())) {
            throw new BusinessException("Dispute is already resolved");
        }

        if (dispute.isProvisionalCreditIssued()) {
            Transaction prov = transactionRepository.findById(dispute.getProvisionalCreditTxnId())
                    .orElseThrow(() -> new ResourceNotFoundException("Transaction", dispute.getProvisionalCreditTxnId()));
            if (won) {
                postingService.hardPost(prov); // provisional credit becomes permanent
            } else {
                postingService.reverseMemo(prov); // cardholder still owes
            }
        } else if (won) {
            // No provisional credit was given: credit the cardholder now.
            postingService.directPost(dispute.getAccount(), TransactionType.PROVISIONAL_CREDIT,
                    dispute.getAmount(), "Dispute #" + dispute.getId() + " won", dispute.getId());
        }

        dispute.setStatus(won ? DisputeStatus.WON : DisputeStatus.LOST);
        dispute.setResolvedAt(LocalDateTime.now());
        dispute.setResolutionNote(note);

        if (won) {
            events.publish(EventType.CHARGEBACK,
                    "Chargeback upheld: " + dispute.getAmount() + " debited from merchant for dispute #" + dispute.getId(),
                    dispute.getAccount().getId(), null, null, dispute.getAmount());
        }
        events.publish(EventType.DISPUTE_RESOLVED,
                "Dispute #" + dispute.getId() + " resolved: " + dispute.getStatus(),
                dispute.getAccount().getId(), null, null, dispute.getAmount());
        return dispute;
    }

    /**
     * Report a transaction as fraud: tag it, block the card, and auto-open a
     * FRAUD dispute so the chargeback process starts immediately.
     */
    public Dispute reportFraud(Long transactionId, String note) {
        Transaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", transactionId));
        txn.setFraudReported(true);
        txn.setFraudReportedAt(LocalDateTime.now());

        Card card = txn.getCard();
        boolean blocked = false;
        if (card != null && card.getStatus() != CardStatus.CLOSED && card.getStatus() != CardStatus.EXPIRED) {
            cardService.block(card.getId());
            blocked = true;
        }

        events.publish(EventType.FRAUD_TAGGED,
                "Fraud reported on " + txn.getReference() + (blocked ? "; card blocked" : ""),
                txn.getAccount().getId(), card == null ? null : card.getId(), txn.getReference(), txn.getAmount());

        return open(transactionId, DisputeReasonCode.FRAUD,
                "Auto-opened from fraud report" + (note == null ? "" : ": " + note));
    }

    @Transactional(readOnly = true)
    public Dispute get(Long disputeId) {
        return disputeRepository.findById(disputeId)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute", disputeId));
    }

    @Transactional(readOnly = true)
    public List<Dispute> listByAccount(Long accountId) {
        return disputeRepository.findByAccountIdOrderByCreatedAtDesc(accountId);
    }
}
