package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AccountStatus;
import com.creditcard.lifecycle.model.enums.AuthDecision;
import com.creditcard.lifecycle.model.enums.AuthResponseCode;
import com.creditcard.lifecycle.model.enums.CardStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.EnumSet;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The issuing bank's authorization host &mdash; the brain of the auth flow.
 *
 * <p>On each request it runs, in order: card/account eligibility, the real-time
 * {@link FraudService} risk checks, then the funds check. It assigns an ISO 8583
 * response code, stamps message metadata (MTI / STAN / RRN), persists the
 * transaction (approvals and declines alike, for audit), places a hold on
 * approval, and emits real-time lifecycle events.
 */
@Service
@Transactional
public class IssuerService {

    /** Response codes that indicate the risk engine (not funds/eligibility) declined. */
    private static final EnumSet<AuthResponseCode> FRAUD_CODES = EnumSet.of(
            AuthResponseCode.SUSPECTED_FRAUD, AuthResponseCode.EXCEEDS_AMOUNT_LIMIT,
            AuthResponseCode.RESTRICTED_CARD, AuthResponseCode.EXCEEDS_VELOCITY);

    private final TransactionRepository transactionRepository;
    private final FraudService fraudService;
    private final LifecycleEvents events;
    private final ReferenceGenerator references;

    public IssuerService(TransactionRepository transactionRepository,
                         FraudService fraudService,
                         LifecycleEvents events,
                         ReferenceGenerator references) {
        this.transactionRepository = transactionRepository;
        this.fraudService = fraudService;
        this.events = events;
        this.references = references;
    }

    /** Outcome of an authorization decision, including the persisted transaction. */
    public record AuthResult(AuthDecision decision, Transaction transaction, AuthResponseCode responseCode) {
        public boolean approved() {
            return decision == AuthDecision.APPROVED;
        }
    }

    public AuthResult authorize(Card card, Merchant merchant, BigDecimal rawAmount, String currency) {
        BigDecimal amount = Money.of(rawAmount);
        CreditAccount account = card.getAccount();

        AuthResponseCode code = evaluate(card, account, merchant, amount);
        boolean approved = code.approved();

        Transaction txn = new Transaction();
        txn.setReference(newReference());
        txn.setAccount(account);
        txn.setCard(card);
        txn.setMerchant(merchant);
        txn.setType(TransactionType.PURCHASE);
        txn.setAmount(amount);
        txn.setCurrency(currency == null || currency.isBlank() ? "INR" : currency);
        txn.setMti("0110");
        txn.setStan(newStan());
        txn.setRrn(newRrn());
        txn.setResponseCode(code.code());
        txn.setResponseText(code.description());
        txn.setReason(code.name());

        if (approved) {
            account.setHoldAmount(Money.of(account.getHoldAmount().add(amount)));
            txn.setStatus(TransactionStatus.AUTHORIZED);
            txn.setAuthorizedAmount(amount);
            txn.setAuthCode(newAuthCode());
        } else {
            txn.setStatus(TransactionStatus.DECLINED);
        }
        transactionRepository.save(txn);

        emitEvents(txn, merchant, amount, code, approved);
        return new AuthResult(code.decision(), txn, code);
    }

    /** @return the response code for this request; {@code APPROVED} means proceed. */
    private AuthResponseCode evaluate(Card card, CreditAccount account, Merchant merchant, BigDecimal amount) {
        if (card.getStatus() == CardStatus.BLOCKED) {
            return AuthResponseCode.LOST_OR_STOLEN;
        }
        if (card.getStatus() == CardStatus.EXPIRED || card.isExpired()) {
            return AuthResponseCode.EXPIRED_CARD;
        }
        if (card.getStatus() != CardStatus.ACTIVE) {
            return AuthResponseCode.TRANSACTION_NOT_PERMITTED;
        }
        if (account.getStatus() != AccountStatus.ACTIVE) {
            return AuthResponseCode.ACCOUNT_ISSUE;
        }
        if (!Money.isPositive(amount)) {
            return AuthResponseCode.DO_NOT_HONOR;
        }
        Optional<AuthResponseCode> risk = fraudService.screen(card, merchant, amount);
        if (risk.isPresent()) {
            return risk.get();
        }
        if (amount.compareTo(account.getAvailableCredit()) > 0) {
            return AuthResponseCode.INSUFFICIENT_FUNDS;
        }
        return AuthResponseCode.APPROVED;
    }

    private void emitEvents(Transaction txn, Merchant merchant, BigDecimal amount,
                            AuthResponseCode code, boolean approved) {
        Long accountId = txn.getAccount().getId();
        Long cardId = txn.getCard() == null ? null : txn.getCard().getId();
        Map<String, Object> details = Map.of(
                "responseCode", code.code(),
                "responseText", code.description(),
                "merchant", merchant == null ? "?" : merchant.getName(),
                "stan", txn.getStan(),
                "rrn", txn.getRrn());

        if (approved) {
            events.publish(EventType.AUTH_APPROVED,
                    "Approved " + amount + " at " + (merchant == null ? "?" : merchant.getName())
                            + " (auth " + txn.getAuthCode() + ")",
                    accountId, cardId, txn.getReference(), amount, details);
        } else {
            if (FRAUD_CODES.contains(code)) {
                events.publish(EventType.FRAUD_ALERT,
                        "Risk decline [" + code.code() + " " + code.description() + "] on " + amount,
                        accountId, cardId, txn.getReference(), amount, details);
            }
            events.publish(EventType.AUTH_DECLINED,
                    "Declined " + amount + " [" + code.code() + " " + code.description() + "]",
                    accountId, cardId, txn.getReference(), amount, details);
        }
    }

    private String newAuthCode() {
        return String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }

    private String newStan() {
        return String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }

    private String newRrn() {
        // 12-digit numeric retrieval reference number.
        long tail = Math.abs(System.nanoTime() % 1_000_000L);
        return String.format("%06d%06d", ThreadLocalRandom.current().nextInt(1_000_000), tail);
    }

    private String newReference() {
        return references.next("TXN");
    }
}
