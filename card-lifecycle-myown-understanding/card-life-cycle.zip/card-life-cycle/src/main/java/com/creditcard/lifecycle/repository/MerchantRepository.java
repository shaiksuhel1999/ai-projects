package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Merchant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantRepository extends JpaRepository<Merchant, Long> {
}
