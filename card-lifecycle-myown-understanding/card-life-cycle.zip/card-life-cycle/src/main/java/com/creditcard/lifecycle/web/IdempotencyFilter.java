package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.model.IdempotencyRecord;
import com.creditcard.lifecycle.repository.IdempotencyRecordRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Idempotency for mutating requests. A POST to {@code /api/**} carrying an
 * {@code Idempotency-Key} header executes at most once: the first call's response
 * is stored and every retry with the same key replays it verbatim, so a
 * double-submitted authorization or payment is not processed twice.
 *
 * <p>Runs after Spring Security (default filter order), so only authenticated
 * requests are recorded. Concurrent duplicates are serialized by the unique key.
 */
@Component
public class IdempotencyFilter extends OncePerRequestFilter {

    private static final String HEADER = "Idempotency-Key";

    private final IdempotencyRecordRepository repository;
    private final TransactionTemplate tx;

    public IdempotencyFilter(IdempotencyRecordRepository repository, PlatformTransactionManager txManager) {
        this.repository = repository;
        this.tx = new TransactionTemplate(txManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String key = request.getHeader(HEADER);
        if (!"POST".equalsIgnoreCase(request.getMethod()) || key == null || key.isBlank()
                || !request.getRequestURI().startsWith("/api/")) {
            chain.doFilter(request, response);
            return;
        }

        IdempotencyRecord existing = tx.execute(s -> repository.findByIdKey(key).orElse(null));
        if (existing != null) {
            if (existing.isCompleted()) {
                replay(response, existing);
            } else {
                inProgress(response);
            }
            return;
        }

        // Claim the key with a placeholder; the unique constraint serializes concurrent duplicates.
        try {
            tx.executeWithoutResult(s -> repository.save(
                    new IdempotencyRecord(key, request.getMethod(), request.getRequestURI())));
        } catch (DataIntegrityViolationException race) {
            IdempotencyRecord rec = tx.execute(s -> repository.findByIdKey(key).orElse(null));
            if (rec != null && rec.isCompleted()) {
                replay(response, rec);
            } else {
                inProgress(response);
            }
            return;
        }

        ContentCachingResponseWrapper wrapper = new ContentCachingResponseWrapper(response);
        try {
            chain.doFilter(request, wrapper);
            int status = wrapper.getStatus();
            byte[] body = wrapper.getContentAsByteArray();
            String contentType = wrapper.getContentType();
            wrapper.copyBodyToResponse();

            if (status < 500) {
                String bodyText = new String(body, StandardCharsets.UTF_8);
                tx.executeWithoutResult(s -> repository.findByIdKey(key).ifPresent(rec -> {
                    rec.setHttpStatus(status);
                    rec.setContentType(contentType);
                    rec.setResponseBody(bodyText);
                    rec.setCompleted(true);
                    repository.save(rec);
                }));
            } else {
                // Transient server error: drop the claim so the client can retry.
                tx.executeWithoutResult(s -> repository.findByIdKey(key).ifPresent(repository::delete));
            }
        } catch (RuntimeException | ServletException | IOException ex) {
            tx.executeWithoutResult(s -> repository.findByIdKey(key).ifPresent(repository::delete));
            throw ex;
        }
    }

    private void replay(HttpServletResponse response, IdempotencyRecord rec) throws IOException {
        response.setStatus(rec.getHttpStatus() == null ? 200 : rec.getHttpStatus());
        if (rec.getContentType() != null) {
            response.setContentType(rec.getContentType());
        }
        response.setHeader("Idempotency-Replay", "true");
        if (rec.getResponseBody() != null) {
            response.getWriter().write(rec.getResponseBody());
        }
    }

    private void inProgress(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_CONFLICT);
        response.setContentType("application/json");
        response.getWriter().write(
                "{\"status\":409,\"error\":\"Conflict\",\"message\":\"A request with this Idempotency-Key is already in progress\"}");
    }
}
