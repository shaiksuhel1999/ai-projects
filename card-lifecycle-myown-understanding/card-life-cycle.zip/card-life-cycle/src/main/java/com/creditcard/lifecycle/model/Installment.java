package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.InstallmentStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** One row of a loan's amortization schedule (a single monthly EMI). */
@Entity
@Table(name = "installments")
@Getter
@Setter
@NoArgsConstructor
public class Installment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "loan_id")
    private Loan loan;

    /** 1-based position in the schedule. */
    private int sequence;

    private LocalDate dueDate;

    @Column(precision = 19, scale = 2)
    private BigDecimal emiAmount = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal principalComponent = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal interestComponent = BigDecimal.ZERO;

    /** Outstanding principal remaining after this instalment is paid. */
    @Column(precision = 19, scale = 2)
    private BigDecimal balanceAfter = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private InstallmentStatus status = InstallmentStatus.PENDING;

    private LocalDateTime paidAt;
}
