package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.CardBrand;
import com.creditcard.lifecycle.model.enums.CardStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CardRepository;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Card issuance and instrument lifecycle: issue (with a backing credit account),
 * activate, block/unblock, close, plus cash advances.
 */
@Service
@Transactional
public class CardService {

    private final CardRepository cardRepository;
    private final CreditAccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final CustomerService customerService;
    private final BankProperties bank;
    private final LifecycleEvents events;
    private final ReferenceGenerator references;

    public CardService(CardRepository cardRepository,
                       CreditAccountRepository accountRepository,
                       TransactionRepository transactionRepository,
                       CustomerService customerService,
                       BankProperties bank,
                       LifecycleEvents events,
                       ReferenceGenerator references) {
        this.cardRepository = cardRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.customerService = customerService;
        this.bank = bank;
        this.events = events;
        this.references = references;
    }

    /** Issue a brand-new card and the revolving credit account behind it. */
    public Card issueCard(IssueCardRequest req) {
        Customer customer = customerService.get(req.customerId());
        if (!customer.isKycVerified()) {
            throw new BusinessException("KYC must be completed before a card can be issued");
        }

        CardBrand brand = parseBrand(req.brand());
        BigDecimal limit = req.creditLimit() != null
                ? Money.of(req.creditLimit())
                : deriveCreditLimit(customer);
        int statementDay = req.statementDay() != null ? clampStatementDay(req.statementDay()) : 1;

        CreditAccount account = new CreditAccount(customer, limit, bank.getDefaultApr(), statementDay);
        accountRepository.save(account);

        Card card = buildCard(account, brand);
        cardRepository.save(card);
        events.publish(EventType.CARD_ISSUED,
                "Issued " + brand + " card " + card.getMaskedPan() + " with limit " + limit,
                account.getId(), card.getId());
        return card;
    }

    /** Cardholder activates the card; only ISSUED cards can be activated. */
    public Card activate(Long cardId) {
        Card card = get(cardId);
        if (card.getStatus() != CardStatus.ISSUED) {
            throw new BusinessException("Only an ISSUED card can be activated; current status = " + card.getStatus());
        }
        card.setStatus(CardStatus.ACTIVE);
        card.setActivatedAt(LocalDateTime.now());
        events.publish(EventType.CARD_ACTIVATED, "Card " + card.getMaskedPan() + " activated",
                card.getAccount().getId(), card.getId());
        return card;
    }

    /** Block a card (lost/stolen/fraud). Reversible via {@link #unblock}. */
    public Card block(Long cardId) {
        Card card = get(cardId);
        if (card.getStatus() == CardStatus.CLOSED || card.getStatus() == CardStatus.EXPIRED) {
            throw new BusinessException("Cannot block a " + card.getStatus() + " card");
        }
        card.setStatus(CardStatus.BLOCKED);
        events.publish(EventType.CARD_BLOCKED, "Card " + card.getMaskedPan() + " blocked",
                card.getAccount().getId(), card.getId());
        return card;
    }

    public Card unblock(Long cardId) {
        Card card = get(cardId);
        if (card.getStatus() != CardStatus.BLOCKED) {
            throw new BusinessException("Only a BLOCKED card can be unblocked; current status = " + card.getStatus());
        }
        card.setStatus(CardStatus.ACTIVE);
        events.publish(EventType.CARD_UNBLOCKED, "Card " + card.getMaskedPan() + " unblocked",
                card.getAccount().getId(), card.getId());
        return card;
    }

    /** Permanently close the card (terminal). */
    public Card close(Long cardId) {
        Card card = get(cardId);
        card.setStatus(CardStatus.CLOSED);
        events.publish(EventType.CARD_CLOSED, "Card " + card.getMaskedPan() + " closed",
                card.getAccount().getId(), card.getId());
        return card;
    }

    /**
     * Draw cash against the card. Cash advances post immediately (no merchant capture),
     * count against the cash sub-limit, and later attract a higher APR at billing time.
     */
    public Transaction cashAdvance(Long cardId, BigDecimal rawAmount) {
        Card card = get(cardId);
        BigDecimal amount = Money.of(rawAmount);
        if (!Money.isPositive(amount)) {
            throw new BusinessException("Cash advance amount must be positive");
        }
        if (card.getStatus() != CardStatus.ACTIVE) {
            throw new BusinessException("Card is not ACTIVE (status = " + card.getStatus() + ")");
        }
        CreditAccount account = card.getAccount();
        if (amount.compareTo(account.getCashLimit()) > 0) {
            throw new BusinessException("Amount exceeds the cash limit of " + account.getCashLimit());
        }
        if (amount.compareTo(account.getAvailableCredit()) > 0) {
            throw new BusinessException("Insufficient available credit for this cash advance");
        }

        account.setCurrentBalance(Money.of(account.getCurrentBalance().add(amount)));

        Transaction txn = new Transaction();
        txn.setReference(newReference());
        txn.setAccount(account);
        txn.setCard(card);
        txn.setType(TransactionType.CASH_ADVANCE);
        txn.setStatus(TransactionStatus.SETTLED);
        txn.setAmount(amount);
        txn.setAuthorizedAmount(amount);
        txn.setCapturedAmount(amount);
        txn.setAuthCode(newAuthCode());
        txn.setSettledAt(LocalDateTime.now());
        transactionRepository.save(txn);
        events.publish(EventType.CASH_ADVANCE, "Cash advance " + amount,
                account.getId(), card.getId(), txn.getReference(), amount);
        return txn;
    }

    @Transactional(readOnly = true)
    public Card get(Long cardId) {
        return cardRepository.findById(cardId)
                .orElseThrow(() -> new ResourceNotFoundException("Card", cardId));
    }

    @Transactional(readOnly = true)
    public CreditAccount getAccount(Long accountId) {
        return accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    /** Simple income + score based credit-limit engine, rounded to the nearest 1,000. */
    private BigDecimal deriveCreditLimit(Customer customer) {
        BigDecimal factor;
        int score = customer.getCreditScore();
        if (score >= 750) {
            factor = new BigDecimal("0.50");
        } else if (score >= 700) {
            factor = new BigDecimal("0.40");
        } else if (score >= 650) {
            factor = new BigDecimal("0.30");
        } else {
            factor = new BigDecimal("0.20");
        }
        BigDecimal raw = customer.getAnnualIncome().multiply(factor);
        BigDecimal rounded = raw.divide(new BigDecimal("1000"), 0, RoundingMode.HALF_UP)
                .multiply(new BigDecimal("1000"));
        BigDecimal min = new BigDecimal("10000");
        return Money.of(Money.max(rounded, min));
    }

    private Card buildCard(CreditAccount account, CardBrand brand) {
        String prefix = binPrefix(brand);
        String bin6 = (prefix + randomDigits(6)).substring(0, 6);
        String last4 = randomDigits(4);
        String maskedPan = bin6 + "******" + last4;

        LocalDate expiry = LocalDate.now().plusYears(4);
        Card card = new Card();
        card.setAccount(account);
        card.setBrand(brand);
        card.setMaskedPan(maskedPan);
        card.setPanLast4(last4);
        card.setToken("tok_" + java.util.UUID.randomUUID().toString().replace("-", ""));
        card.setExpiryMonth(expiry.getMonthValue());
        card.setExpiryYear(expiry.getYear());
        card.setCvvHash(Integer.toHexString((maskedPan + "cvv").hashCode()));
        card.setStatus(CardStatus.ISSUED);
        return card;
    }

    private CardBrand parseBrand(String brand) {
        if (brand == null || brand.isBlank()) {
            return CardBrand.VISA;
        }
        try {
            return CardBrand.valueOf(brand.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new BusinessException("Unknown card brand: " + brand);
        }
    }

    private String binPrefix(CardBrand brand) {
        return switch (brand) {
            case VISA -> "4";
            case MASTERCARD -> "5";
            case RUPAY -> "6";
            case AMEX -> "3";
            case UNKNOWN -> "9";
        };
    }

    private int clampStatementDay(int day) {
        if (day < 1) {
            return 1;
        }
        return Math.min(day, 28);
    }

    private String randomDigits(int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            sb.append(ThreadLocalRandom.current().nextInt(10));
        }
        return sb.toString();
    }

    private String newAuthCode() {
        return String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }

    private String newReference() {
        return references.next("TXN");
    }
}
