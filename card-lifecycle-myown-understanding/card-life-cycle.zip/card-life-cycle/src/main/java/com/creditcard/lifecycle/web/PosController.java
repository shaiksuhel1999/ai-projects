package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.service.AcquirerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The POS entry point. A swipe/tap at a terminal posts here; the request then
 * flows Acquirer &rarr; Card Network &rarr; Issuer and the decision comes back.
 */
@RestController
@RequestMapping("/api/pos")
@Tag(name = "4. POS authorization", description = "POS -> Acquirer -> Network -> Issuer authorization")
public class PosController {

    private final AcquirerService acquirerService;

    public PosController(AcquirerService acquirerService) {
        this.acquirerService = acquirerService;
    }

    @PostMapping("/authorize")
    @Operation(summary = "Authorize a purchase at a POS terminal (returns approval + auth code + flow trace)")
    public AuthorizeResponse authorize(@Valid @RequestBody AuthorizeRequest req) {
        return acquirerService.authorize(req);
    }
}
