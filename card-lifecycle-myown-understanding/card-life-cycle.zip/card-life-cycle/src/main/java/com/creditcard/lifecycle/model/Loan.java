package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.LoanStatus;
import com.creditcard.lifecycle.model.enums.LoanType;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * A credit facility: a personal loan, an EMI conversion of a purchase, or a
 * balance transfer. Carries the amortization schedule ({@link Installment}s).
 */
@Entity
@Table(name = "loans")
@Getter
@Setter
@NoArgsConstructor
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "account_id")
    private CreditAccount account;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LoanType type;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LoanStatus status = LoanStatus.APPLIED;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal principal = BigDecimal.ZERO;

    /** Annual interest rate offered / applied (%). */
    @Column(precision = 6, scale = 2, nullable = false)
    private BigDecimal annualRate = BigDecimal.ZERO;

    private int tenureMonths;

    /** Equated Monthly Instalment computed from principal, rate and tenure. */
    @Column(precision = 19, scale = 2)
    private BigDecimal emiAmount = BigDecimal.ZERO;

    /** Principal still to be repaid. */
    @Column(precision = 19, scale = 2)
    private BigDecimal outstandingPrincipal = BigDecimal.ZERO;

    private String purpose;

    /** Underwriting narrative (approve/decline reason). */
    private String decisionReason;

    /** For EMI conversions: the purchase transaction being converted. */
    private Long sourceTransactionId;

    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime disbursedAt;

    @OneToMany(mappedBy = "loan", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @OrderBy("sequence ASC")
    private List<Installment> installments = new ArrayList<>();
}
