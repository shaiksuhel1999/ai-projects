package com.creditcard.lifecycle.event;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Thin façade the services call to emit real-time lifecycle events without
 * depending directly on Spring's publisher plumbing.
 */
@Component
public class LifecycleEvents {

    private final ApplicationEventPublisher publisher;

    public LifecycleEvents(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    public void publish(EventType type, String message, Long accountId, Long cardId,
                        String transactionReference, BigDecimal amount, Map<String, Object> details) {
        publisher.publishEvent(LifecycleEvent.of(type, message, accountId, cardId,
                transactionReference, amount, details));
    }

    public void publish(EventType type, String message, Long accountId, Long cardId) {
        publish(type, message, accountId, cardId, null, null, null);
    }

    public void publish(EventType type, String message, Long accountId, Long cardId,
                        String transactionReference, BigDecimal amount) {
        publish(type, message, accountId, cardId, transactionReference, amount, null);
    }
}
