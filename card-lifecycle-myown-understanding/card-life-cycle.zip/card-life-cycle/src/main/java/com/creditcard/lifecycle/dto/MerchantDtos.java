package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Merchant;
import jakarta.validation.constraints.NotBlank;

public final class MerchantDtos {

    private MerchantDtos() {
    }

    public record CreateMerchantRequest(
            @NotBlank String name,
            String mcc,
            String acquirerName,
            String terminalId,
            String country) {
    }

    public record MerchantResponse(
            Long id,
            String name,
            String mcc,
            String acquirerName,
            String terminalId,
            String country) {

        public static MerchantResponse from(Merchant m) {
            return new MerchantResponse(m.getId(), m.getName(), m.getMcc(),
                    m.getAcquirerName(), m.getTerminalId(), m.getCountry());
        }
    }
}
