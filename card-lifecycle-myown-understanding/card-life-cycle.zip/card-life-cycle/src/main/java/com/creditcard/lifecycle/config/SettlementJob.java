package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.service.TransactionService;
import com.creditcard.lifecycle.support.BatchExecutor;
import com.creditcard.lifecycle.support.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/**
 * Automatic settlement batch. Settles each captured transaction in its own
 * transaction (via {@link BatchExecutor}) so one failure or a lock conflict with
 * a concurrent capture never rolls back the rest of the batch.
 *
 * <p>Only registered when {@code bank.settlement.auto-enabled=true}.
 */
@Component
@ConditionalOnProperty(prefix = "bank.settlement", name = "auto-enabled", havingValue = "true")
public class SettlementJob {

    private static final Logger log = LoggerFactory.getLogger(SettlementJob.class);

    private final TransactionService transactionService;
    private final BatchExecutor batch;
    private final LifecycleEvents events;

    public SettlementJob(TransactionService transactionService, BatchExecutor batch, LifecycleEvents events) {
        this.transactionService = transactionService;
        this.batch = batch;
        this.events = events;
    }

    @Scheduled(fixedDelayString = "${bank.settlement.interval-ms:20000}",
            initialDelayString = "${bank.settlement.interval-ms:20000}")
    public void settleDueBatch() {
        List<Long> ids = transactionService.capturedTransactionIds();
        int count = 0;
        BigDecimal total = BigDecimal.ZERO;
        for (Long id : ids) {
            BigDecimal amount = batch.call(() -> transactionService.settleOne(id)).orElse(null);
            if (amount != null) {
                count++;
                total = total.add(amount);
            }
        }
        if (count > 0) {
            events.publish(EventType.SETTLEMENT,
                    "Settlement batch: " + count + " txn(s) for " + Money.of(total),
                    null, null, null, Money.of(total));
            log.info("[auto-settlement] settled {} transaction(s) for {}", count, Money.of(total));
        }
    }
}
