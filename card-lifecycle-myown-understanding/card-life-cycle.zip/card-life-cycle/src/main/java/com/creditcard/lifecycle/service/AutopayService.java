package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.dto.PaymentDtos.PaymentRequest;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.enums.PaymentType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.support.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Autopay standing instruction: enroll an account to auto-debit its minimum or
 * total due on the due date. A scheduled job (or a manual run) processes all
 * enrolled accounts whose due date has arrived and that still owe this cycle.
 */
@Service
@Transactional
public class AutopayService {

    private static final Logger log = LoggerFactory.getLogger(AutopayService.class);

    private final CreditAccountRepository accountRepository;
    private final PaymentService paymentService;
    private final LifecycleEvents events;

    public AutopayService(CreditAccountRepository accountRepository,
                          PaymentService paymentService,
                          LifecycleEvents events) {
        this.accountRepository = accountRepository;
        this.paymentService = paymentService;
        this.events = events;
    }

    /** Enroll an account in autopay for the minimum or total due. */
    public CreditAccount enroll(Long accountId, PaymentType type) {
        if (type != PaymentType.MINIMUM_DUE && type != PaymentType.TOTAL_DUE) {
            throw new BusinessException("Autopay type must be MINIMUM_DUE or TOTAL_DUE");
        }
        CreditAccount account = get(accountId);
        account.setAutopayEnabled(true);
        account.setAutopayType(type);
        events.publish(EventType.AUTOPAY_ENROLLED, "Autopay enrolled for " + type, accountId, null);
        return account;
    }

    public CreditAccount disable(Long accountId) {
        CreditAccount account = get(accountId);
        account.setAutopayEnabled(false);
        return account;
    }

    /**
     * Process every enrolled account whose due date has arrived (interactive / API
     * path — one transaction). The scheduled job processes per-account for resilience.
     */
    public int runAutopay() {
        int paid = 0;
        for (CreditAccount account : accountRepository
                .findByAutopayEnabledTrueAndPaymentDueDateLessThanEqual(LocalDate.now())) {
            if (doAutopay(account)) {
                paid++;
            }
        }
        if (paid > 0) {
            log.info("[autopay] executed on {} account(s)", paid);
        }
        return paid;
    }

    /** Ids of accounts due for autopay, for the resilient per-account batch job. */
    @Transactional(readOnly = true)
    public List<Long> autopayDueIds() {
        return accountRepository.findByAutopayEnabledTrueAndPaymentDueDateLessThanEqual(LocalDate.now())
                .stream().map(CreditAccount::getId).toList();
    }

    /** Autopay one account (each call is its own tx when driven by the batch job). */
    public boolean payAccount(Long accountId) {
        CreditAccount account = accountRepository.findById(accountId).orElse(null);
        return account != null && doAutopay(account);
    }

    private boolean doAutopay(CreditAccount account) {
        if (!account.isAutopayEnabled() || Money.isPositive(account.getPaidThisCycle())) {
            return false; // already paid something this cycle
        }
        BigDecimal required = account.getAutopayType() == PaymentType.TOTAL_DUE
                ? account.getCurrentStatementBalance()
                : account.getMinimumDue();
        if (!Money.isPositive(required) || required.compareTo(account.getCurrentBalance()) > 0) {
            return false;
        }
        paymentService.pay(account.getId(), new PaymentRequest(account.getAutopayType(), null, "AUTOPAY"));
        events.publish(EventType.AUTOPAY_EXECUTED,
                "Autopay debited " + required + " (" + account.getAutopayType() + ")",
                account.getId(), null, null, required);
        return true;
    }

    @Transactional(readOnly = true)
    public CreditAccount get(Long accountId) {
        return accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
    }
}
