package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.AccountStatus;
import com.creditcard.lifecycle.model.enums.PaymentType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * The revolving credit line behind a card. Holds the money state that the
 * issuer, billing engine and payment engine all read and mutate.
 *
 * <p>Key invariant: {@code availableCredit = creditLimit - currentBalance - holdAmount}.
 * <ul>
 *   <li>{@code currentBalance} &ndash; amount actually owed (posted purchases, fees, interest minus payments).</li>
 *   <li>{@code holdAmount} &ndash; authorized-but-not-yet-captured amounts (temporary blocks).</li>
 * </ul>
 */
@Entity
@Table(name = "credit_accounts")
@Getter
@Setter
@NoArgsConstructor
public class CreditAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Optimistic-lock guard. Concurrent authorizations, payments, posting and
     * autopay all mutate this row; the version prevents a lost update (double-spend)
     * &mdash; a stale write fails with an optimistic-locking exception instead of
     * silently overwriting a fresher balance.
     */
    @Version
    private long version;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal creditLimit = BigDecimal.ZERO;

    /** Sub-limit for cash advances (usually a fraction of the total limit). */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal cashLimit = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal currentBalance = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal holdAmount = BigDecimal.ZERO;

    /**
     * Net of memo posts not yet hard-posted to the ledger. A memo debit (e.g. a
     * pending fee) is positive and reduces available credit; a memo credit (e.g. a
     * dispute provisional credit) is negative and frees up available credit.
     */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal memoBalance = BigDecimal.ZERO;

    /** Annual percentage rate for revolving purchases (%). */
    @Column(precision = 6, scale = 2, nullable = false)
    private BigDecimal apr = new BigDecimal("36.00");

    /** Day of month (1-28) on which the statement is cut. */
    private int statementDay = 1;

    private LocalDate lastStatementDate;

    /** Precise timestamp of the last statement cut; used as the billing-window boundary. */
    private LocalDateTime lastStatementAt;

    // ----- Snapshot of the most recent statement, used by the payment engine -----

    /** Balance owed as of the last statement cut. */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal currentStatementBalance = BigDecimal.ZERO;

    /** Unpaid portion of the current statement balance. */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal statementRemaining = BigDecimal.ZERO;

    /** Minimum amount the cardholder must pay by the due date to stay current. */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal minimumDue = BigDecimal.ZERO;

    private LocalDate paymentDueDate;

    /** Total paid since the last statement cut; compared against {@code minimumDue}. */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal paidThisCycle = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountStatus status = AccountStatus.ACTIVE;

    // ----- Rewards -----

    /** Accrued reward points, earned on purchases and redeemable for statement credit. */
    private long rewardPoints = 0;

    // ----- Autopay standing instruction -----

    private boolean autopayEnabled = false;

    /** What autopay pays on the due date: MINIMUM_DUE or TOTAL_DUE. */
    @Enumerated(EnumType.STRING)
    private PaymentType autopayType;

    private LocalDateTime createdAt = LocalDateTime.now();

    public CreditAccount(Customer customer, BigDecimal creditLimit, BigDecimal apr, int statementDay) {
        this.customer = customer;
        this.creditLimit = creditLimit;
        this.cashLimit = creditLimit.multiply(new BigDecimal("0.30"));
        this.apr = apr;
        this.statementDay = statementDay;
    }

    /**
     * Credit still spendable = limit minus the posted (ledger) balance, minus
     * authorization holds, minus the net of memo posts.
     */
    public BigDecimal getAvailableCredit() {
        return creditLimit.subtract(currentBalance).subtract(holdAmount).subtract(memoBalance);
    }

    /** Alias: {@code currentBalance} is the hard-posted ledger balance. */
    public BigDecimal getPostedBalance() {
        return currentBalance;
    }
}
