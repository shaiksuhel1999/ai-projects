package com.creditcard.lifecycle.support;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Reducing-balance EMI math.
 *
 * <p>EMI = P &middot; r &middot; (1+r)^n / ((1+r)^n &minus; 1), where
 * {@code P} = principal, {@code r} = monthly rate (annualRate/12/100), {@code n} = tenure in months.
 */
public final class EmiCalculator {

    private static final MathContext MC = new MathContext(20, RoundingMode.HALF_EVEN);

    private EmiCalculator() {
    }

    /** Monthly interest rate as a fraction, e.g. 14% p.a. -> 0.011666... */
    public static BigDecimal monthlyRate(BigDecimal annualRatePercent) {
        return annualRatePercent
                .divide(BigDecimal.valueOf(1200), MC); // /100 for percent, /12 for months
    }

    /** Equated monthly instalment, rounded to 2 dp. */
    public static BigDecimal emi(BigDecimal principal, BigDecimal annualRatePercent, int tenureMonths) {
        if (tenureMonths <= 0) {
            throw new IllegalArgumentException("tenureMonths must be positive");
        }
        BigDecimal r = monthlyRate(annualRatePercent);
        if (r.signum() == 0) { // zero-interest plan
            return principal.divide(BigDecimal.valueOf(tenureMonths), Money.SCALE, Money.ROUNDING);
        }
        BigDecimal onePlusR = BigDecimal.ONE.add(r);
        BigDecimal pow = onePlusR.pow(tenureMonths, MC);
        BigDecimal numerator = principal.multiply(r, MC).multiply(pow, MC);
        BigDecimal denominator = pow.subtract(BigDecimal.ONE, MC);
        return numerator.divide(denominator, Money.SCALE, Money.ROUNDING);
    }
}
