package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.service.PostingService;
import com.creditcard.lifecycle.support.BatchExecutor;
import com.creditcard.lifecycle.support.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/**
 * Automatic posting cycle. Hard-posts each pending memo entry in its own
 * transaction so one conflict doesn't roll back the run.
 *
 * <p>Only registered when {@code bank.posting.auto-enabled=true}.
 */
@Component
@ConditionalOnProperty(prefix = "bank.posting", name = "auto-enabled", havingValue = "true")
public class PostingJob {

    private static final Logger log = LoggerFactory.getLogger(PostingJob.class);

    private final PostingService postingService;
    private final BatchExecutor batch;
    private final LifecycleEvents events;

    public PostingJob(PostingService postingService, BatchExecutor batch, LifecycleEvents events) {
        this.postingService = postingService;
        this.batch = batch;
        this.events = events;
    }

    @Scheduled(fixedDelayString = "${bank.posting.interval-ms:30000}",
            initialDelayString = "${bank.posting.interval-ms:30000}")
    public void runPostingCycle() {
        List<Long> ids = postingService.pendingMemoIds();
        int posted = 0;
        BigDecimal total = BigDecimal.ZERO;
        for (Long id : ids) {
            BigDecimal amount = batch.call(() -> postingService.hardPostOne(id)).orElse(null);
            if (amount != null) {
                posted++;
                total = total.add(amount);
            }
        }
        if (posted > 0) {
            events.publish(EventType.HARD_POST,
                    "Posting cycle: hard-posted " + posted + " memo entr(y/ies) for " + Money.of(total),
                    null, null, null, Money.of(total));
            log.info("[auto-posting] hard-posted {} memo entr(y/ies) for {}", posted, Money.of(total));
        }
    }
}
