package com.creditcard.lifecycle.model.enums;

/** The nature of a money movement recorded against a credit account. */
public enum TransactionType {
    /** Retail purchase at a merchant. Increases the balance owed. */
    PURCHASE,
    /** Cash withdrawn against the card. Increases the balance owed (higher APR). */
    CASH_ADVANCE,
    /** Money returned by a merchant. Decreases the balance owed. */
    REFUND,
    /** Cardholder payment towards the outstanding balance. Decreases the balance owed. */
    PAYMENT,
    /** Interest charged by the issuer. Increases the balance owed. */
    INTEREST,
    /** A fee (late fee, annual fee, etc.). Increases the balance owed. */
    FEE,
    /** A single monthly instalment billed for a loan / EMI conversion. Increases the balance owed. */
    EMI_INSTALLMENT,
    /** Auxiliary manual credit (goodwill, fee reversal). Decreases the balance owed. */
    ADJUSTMENT_CREDIT,
    /** Auxiliary manual debit (manual fee, correction). Increases the balance owed. */
    ADJUSTMENT_DEBIT,
    /** Temporary credit given to the cardholder while a dispute is investigated. Decreases the balance owed. */
    PROVISIONAL_CREDIT,
    /** Chargeback booked against the merchant/acquirer when a dispute is won. Audit entry. */
    CHARGEBACK,
    /** Reward points redeemed as a statement credit. Decreases the balance owed. */
    REWARD_REDEMPTION;

    /** True for entries that reduce the balance owed (credits to the cardholder). */
    public boolean isCredit() {
        return this == PAYMENT || this == REFUND || this == ADJUSTMENT_CREDIT
                || this == PROVISIONAL_CREDIT || this == REWARD_REDEMPTION;
    }

    /** Signed effect on the balance owed: debits add, credits subtract. */
    public int sign() {
        return isCredit() ? -1 : +1;
    }
}
