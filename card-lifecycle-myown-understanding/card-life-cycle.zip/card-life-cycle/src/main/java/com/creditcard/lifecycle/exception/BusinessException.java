package com.creditcard.lifecycle.exception;

/** Thrown when a request is well-formed but violates a business rule (HTTP 422). */
public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
