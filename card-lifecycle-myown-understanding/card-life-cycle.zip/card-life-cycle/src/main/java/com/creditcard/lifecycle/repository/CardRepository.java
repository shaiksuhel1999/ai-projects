package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Card;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CardRepository extends JpaRepository<Card, Long> {
    Optional<Card> findByToken(String token);
}
