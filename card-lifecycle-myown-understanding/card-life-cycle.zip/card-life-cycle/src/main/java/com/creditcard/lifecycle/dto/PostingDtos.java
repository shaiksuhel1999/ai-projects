package com.creditcard.lifecycle.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public final class PostingDtos {

    private PostingDtos() {
    }

    public enum Direction { CREDIT, DEBIT }

    public enum Mode { MEMO, POSTED }

    /**
     * An auxiliary manual adjustment. {@code MEMO} hits available credit now and is
     * hard-posted by the posting cycle; {@code POSTED} books straight to the ledger.
     */
    public record AdjustmentRequest(
            @NotNull Direction direction,
            @NotNull @Positive BigDecimal amount,
            String reason,
            Mode mode) {
    }

    public record PostingCycleResponse(
            int postedCount,
            BigDecimal postedAmount,
            String message) {
    }
}
