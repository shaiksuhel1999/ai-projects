package com.creditcard.lifecycle.model.enums;

/** Outcome of a payment attempt. */
public enum PaymentStatus {
    SUCCESS,
    FAILED
}
