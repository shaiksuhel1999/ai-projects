package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.LoanDtos.EmiConversionRequest;
import com.creditcard.lifecycle.dto.LoanDtos.LoanApplicationRequest;
import com.creditcard.lifecycle.dto.LoanDtos.LoanResponse;
import com.creditcard.lifecycle.model.Loan;
import com.creditcard.lifecycle.service.LoanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Loan & EMI applications, disbursement, amortization schedules and repayments. */
@RestController
@RequestMapping("/api/loans")
@Tag(name = "8. Loans & EMI", description = "Apply for loans, convert purchases to EMI, repay instalments")
public class LoanController {

    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PostMapping("/apply")
    @PreAuthorize("@access.ownsAccount(authentication, #req.accountId())")
    @Operation(summary = "Apply for a personal loan (underwritten instantly)")
    public ResponseEntity<LoanResponse> apply(@Valid @RequestBody LoanApplicationRequest req) {
        Loan loan = loanService.applyPersonalLoan(req);
        return ResponseEntity.status(HttpStatus.CREATED).body(LoanResponse.summary(loan));
    }

    @PostMapping("/{loanId}/disburse")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Disburse an approved loan and generate its EMI schedule")
    public LoanResponse disburse(@PathVariable Long loanId) {
        Loan loan = loanService.disburse(loanId);
        return LoanResponse.withSchedule(loan, loan.getInstallments());
    }

    @PostMapping("/convert-emi")
    @Operation(summary = "Convert a captured/settled card purchase into an EMI plan")
    public ResponseEntity<LoanResponse> convert(@Valid @RequestBody EmiConversionRequest req) {
        Loan loan = loanService.convertToEmi(req);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(LoanResponse.withSchedule(loan, loan.getInstallments()));
    }

    @PostMapping("/{loanId}/pay-installment")
    @Operation(summary = "Pay the next due EMI instalment")
    public LoanResponse payInstallment(@PathVariable Long loanId) {
        Loan loan = loanService.payInstallment(loanId);
        return LoanResponse.withSchedule(loan, loan.getInstallments());
    }

    @GetMapping("/{loanId}")
    @Operation(summary = "Fetch a loan with its full amortization schedule")
    public LoanResponse get(@PathVariable Long loanId) {
        Loan loan = loanService.get(loanId);
        return LoanResponse.withSchedule(loan, loan.getInstallments());
    }

    @GetMapping("/accounts/{accountId}")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "List all loans on an account")
    public List<LoanResponse> byAccount(@PathVariable Long accountId) {
        return loanService.listByAccount(accountId).stream()
                .map(LoanResponse::summary).toList();
    }
}
