package com.creditcard.lifecycle.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Runs each item of a batch in its own {@code REQUIRES_NEW} transaction, so one
 * item's failure — or an optimistic-lock conflict with a concurrent API call —
 * doesn't roll back the whole batch. Optimistic-lock conflicts are retried a few
 * times before the item is skipped.
 */
@Component
public class BatchExecutor {

    private static final Logger log = LoggerFactory.getLogger(BatchExecutor.class);
    private static final int MAX_ATTEMPTS = 3;

    private final TransactionTemplate requiresNew;

    public BatchExecutor(PlatformTransactionManager txManager) {
        this.requiresNew = new TransactionTemplate(txManager);
        this.requiresNew.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }

    /**
     * Execute one unit of work in its own transaction.
     *
     * @return the work's result, or empty if it was skipped after exhausting retries / on error.
     */
    public <T> Optional<T> call(Supplier<T> work) {
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try {
                return Optional.ofNullable(requiresNew.execute(status -> work.get()));
            } catch (OptimisticLockingFailureException ex) {
                if (attempt == MAX_ATTEMPTS) {
                    log.warn("batch item skipped after {} optimistic-lock retries", attempt);
                    return Optional.empty();
                }
            } catch (RuntimeException ex) {
                log.warn("batch item skipped due to error: {}", ex.toString());
                return Optional.empty();
            }
        }
        return Optional.empty();
    }
}
