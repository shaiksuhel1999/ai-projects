package com.creditcard.lifecycle.model.enums;

/** Application roles. ADMIN is back-office/ops; CUSTOMER is a cardholder scoped to their own accounts. */
public enum Role {
    ADMIN,
    CUSTOMER
}
