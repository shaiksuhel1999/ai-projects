package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * The core ledger engine implementing the real memo-post / hard-post distinction.
 *
 * <ul>
 *   <li><b>Memo post</b> &mdash; hits the account's memo balance (and therefore
 *       available credit) immediately, but is <em>not</em> yet on the ledger.</li>
 *   <li><b>Hard post</b> &mdash; the posting cycle moves a memo entry onto the
 *       ledger (posted) balance and clears it from the memo balance.</li>
 *   <li><b>Direct post</b> &mdash; a booking that goes straight to the ledger.</li>
 * </ul>
 *
 * The signed effect on the balance owed follows {@link TransactionType#sign()}:
 * debits add, credits subtract.
 */
@Service
@Transactional
public class PostingService {

    private final TransactionRepository transactionRepository;
    private final CreditAccountRepository accountRepository;
    private final LifecycleEvents events;
    private final ReferenceGenerator references;

    public PostingService(TransactionRepository transactionRepository,
                          CreditAccountRepository accountRepository,
                          LifecycleEvents events,
                          ReferenceGenerator references) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.events = events;
        this.references = references;
    }

    /** Create a memo post: affects available credit now, ledger later. */
    public Transaction memoPost(CreditAccount account, TransactionType type, BigDecimal rawAmount,
                                String reason, boolean autoPost, Long disputeId) {
        BigDecimal amount = Money.of(rawAmount);
        BigDecimal signed = signed(type, amount);
        account.setMemoBalance(Money.of(account.getMemoBalance().add(signed)));

        Transaction txn = base(account, type, amount, reason);
        txn.setStatus(TransactionStatus.MEMO);
        txn.setAutoPost(autoPost);
        txn.setDisputeId(disputeId);
        transactionRepository.save(txn);
        return txn;
    }

    /** Book an entry straight onto the ledger (posted) balance. */
    public Transaction directPost(CreditAccount account, TransactionType type, BigDecimal rawAmount,
                                  String reason, Long disputeId) {
        BigDecimal amount = Money.of(rawAmount);
        account.setCurrentBalance(Money.of(account.getCurrentBalance().add(signed(type, amount))));

        Transaction txn = base(account, type, amount, reason);
        txn.setStatus(TransactionStatus.POSTED);
        txn.setDisputeId(disputeId);
        transactionRepository.save(txn);
        return txn;
    }

    /** Move a single memo entry onto the ledger. */
    public void hardPost(Transaction memoTxn) {
        if (memoTxn.getStatus() != TransactionStatus.MEMO) {
            throw new BusinessException("Only a MEMO transaction can be hard-posted; status = " + memoTxn.getStatus());
        }
        CreditAccount account = memoTxn.getAccount();
        BigDecimal signed = signed(memoTxn.getType(), memoTxn.getAmount());
        account.setMemoBalance(Money.of(account.getMemoBalance().subtract(signed)));
        account.setCurrentBalance(Money.of(account.getCurrentBalance().add(signed)));
        memoTxn.setStatus(TransactionStatus.POSTED);
    }

    /** Reverse a memo entry that will never post (e.g. a dispute lost on representment). */
    public void reverseMemo(Transaction memoTxn) {
        if (memoTxn.getStatus() != TransactionStatus.MEMO) {
            throw new BusinessException("Only a MEMO transaction can be reversed; status = " + memoTxn.getStatus());
        }
        CreditAccount account = memoTxn.getAccount();
        BigDecimal signed = signed(memoTxn.getType(), memoTxn.getAmount());
        account.setMemoBalance(Money.of(account.getMemoBalance().subtract(signed)));
        memoTxn.setStatus(TransactionStatus.REVERSED);
    }

    /**
     * Hard-post every auto-post memo entry (interactive / API path — one
     * transaction). The scheduled job hard-posts per-item for resilience.
     */
    public PostingSummary runPostingCycle() {
        List<Transaction> pending = transactionRepository.findByStatusAndAutoPost(TransactionStatus.MEMO, true);
        int posted = 0;
        BigDecimal total = BigDecimal.ZERO;
        for (Transaction txn : pending) {
            hardPost(txn);
            posted++;
            total = total.add(txn.getAmount());
        }
        if (posted > 0) {
            events.publish(EventType.HARD_POST,
                    "Posting cycle: hard-posted " + posted + " memo entr(y/ies) for " + Money.of(total),
                    null, null, null, Money.of(total));
        }
        return new PostingSummary(posted, Money.of(total));
    }

    /** Ids of memo entries awaiting hard-posting, for the resilient per-item batch job. */
    @Transactional(readOnly = true)
    public List<Long> pendingMemoIds() {
        return transactionRepository.findByStatusAndAutoPost(TransactionStatus.MEMO, true)
                .stream().map(Transaction::getId).toList();
    }

    /** Hard-post one memo entry (each call is its own tx when driven by the batch job). */
    public BigDecimal hardPostOne(Long id) {
        Transaction txn = transactionRepository.findById(id).orElse(null);
        if (txn == null || txn.getStatus() != TransactionStatus.MEMO) {
            return null;
        }
        hardPost(txn);
        return txn.getAmount();
    }

    /** Create an auxiliary manual adjustment (goodwill credit, fee reversal, correction). */
    public Transaction adjust(Long accountId, boolean credit, BigDecimal amount, String reason, boolean memo) {
        CreditAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));
        if (!Money.isPositive(Money.of(amount))) {
            throw new BusinessException("Adjustment amount must be positive");
        }
        TransactionType type = credit ? TransactionType.ADJUSTMENT_CREDIT : TransactionType.ADJUSTMENT_DEBIT;
        String note = reason == null || reason.isBlank() ? "MANUAL_ADJUSTMENT" : reason;

        Transaction txn = memo
                ? memoPost(account, type, amount, note, true, null)
                : directPost(account, type, amount, note, null);

        events.publish(EventType.ADJUSTMENT,
                (credit ? "Credit" : "Debit") + " adjustment " + Money.of(amount)
                        + " (" + (memo ? "memo" : "posted") + "): " + note,
                accountId, null, txn.getReference(), Money.of(amount));
        return txn;
    }

    private BigDecimal signed(TransactionType type, BigDecimal amount) {
        return type.sign() < 0 ? amount.negate() : amount;
    }

    private Transaction base(CreditAccount account, TransactionType type, BigDecimal amount, String reason) {
        Transaction txn = new Transaction();
        txn.setReference(references.next("LGR"));
        txn.setAccount(account);
        txn.setType(type);
        txn.setAmount(amount);
        txn.setReason(reason);
        return txn;
    }

    /** Result of a posting-cycle run. */
    public record PostingSummary(int postedCount, BigDecimal postedAmount) {
    }
}
