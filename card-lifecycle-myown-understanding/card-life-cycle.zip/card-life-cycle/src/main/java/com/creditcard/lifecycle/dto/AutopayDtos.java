package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.enums.PaymentType;
import jakarta.validation.constraints.NotNull;

public final class AutopayDtos {

    private AutopayDtos() {
    }

    /** Enroll in autopay. Only MINIMUM_DUE or TOTAL_DUE are valid. */
    public record EnrollRequest(
            @NotNull PaymentType type) {
    }

    public record AutopayResponse(
            Long accountId,
            boolean autopayEnabled,
            String autopayType) {
    }
}
