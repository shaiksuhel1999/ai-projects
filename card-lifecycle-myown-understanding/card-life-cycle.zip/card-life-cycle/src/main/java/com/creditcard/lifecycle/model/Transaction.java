package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * A single money movement against a credit account. Covers the full clearing
 * lifecycle for card purchases (AUTHORIZED &rarr; CAPTURED &rarr; SETTLED) as well as
 * bookkeeping entries (PAYMENT, FEE, INTEREST, EMI_INSTALLMENT) that are POSTED directly.
 */
@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** External reference exposed to POS/network, independent of the DB id. */
    @Column(nullable = false, unique = true)
    private String reference;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "account_id")
    private CreditAccount account;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "card_id")
    private Card card;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "merchant_id")
    private Merchant merchant;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status;

    /** Requested / booked amount. */
    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal amount = BigDecimal.ZERO;

    /** Amount the issuer approved & held (may differ from requested). */
    @Column(precision = 19, scale = 2)
    private BigDecimal authorizedAmount = BigDecimal.ZERO;

    /** Amount actually captured by the merchant (supports partial capture). */
    @Column(precision = 19, scale = 2)
    private BigDecimal capturedAmount = BigDecimal.ZERO;

    /** Cumulative amount refunded against this transaction (supports multiple partial refunds). */
    @Column(precision = 19, scale = 2)
    private BigDecimal refundedAmount = BigDecimal.ZERO;

    private String currency = "INR";

    /** Six-digit approval code returned to the POS on approval. */
    private String authCode;

    /** ISO 8583 message type indicator, e.g. 0110 (authorization response). */
    private String mti;

    /** System Trace Audit Number (ISO field 11): 6-digit per-message trace id. */
    private String stan;

    /** Retrieval Reference Number (ISO field 37): 12-char network reference. */
    private String rrn;

    /** ISO 8583 response code (field 39), e.g. 00 approved, 51 insufficient funds. */
    private String responseCode;

    /** Human-readable meaning of {@link #responseCode}. */
    private String responseText;

    /** Decline/annotation reason. */
    private String reason;

    /** For refunds/reversals: the id of the original transaction. */
    private Long parentTransactionId;

    /** For EMI instalments: the loan that generated this entry. */
    private Long loanId;

    /** For dispute-related entries (provisional credit, chargeback): the dispute id. */
    private Long disputeId;

    /** MEMO entries with this flag are hard-posted by the scheduled posting cycle. */
    private boolean autoPost = false;

    /** True once this transaction has been reported/tagged as fraudulent. */
    private boolean fraudReported = false;

    private LocalDateTime fraudReportedAt;

    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime capturedAt;

    private LocalDateTime settledAt;
}
