package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.DisputeDtos.DisputeResponse;
import com.creditcard.lifecycle.dto.DisputeDtos.OpenDisputeRequest;
import com.creditcard.lifecycle.dto.DisputeDtos.RepresentRequest;
import com.creditcard.lifecycle.dto.DisputeDtos.ResolveRequest;
import com.creditcard.lifecycle.service.DisputeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Dispute & chargeback lifecycle. */
@RestController
@RequestMapping("/api/disputes")
@Tag(name = "10. Disputes & chargebacks", description = "Open a dispute, issue provisional credit, represent, resolve")
public class DisputeController {

    private final DisputeService disputeService;

    public DisputeController(DisputeService disputeService) {
        this.disputeService = disputeService;
    }

    @PostMapping("/open")
    @Operation(summary = "Open a dispute / raise a chargeback against a posted purchase")
    public ResponseEntity<DisputeResponse> open(@Valid @RequestBody OpenDisputeRequest req) {
        DisputeResponse body = DisputeResponse.from(
                disputeService.open(req.transactionId(), req.reasonCode(), req.note()));
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    @PostMapping("/{disputeId}/provisional-credit")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Issue provisional credit to the cardholder (a memo post)")
    public DisputeResponse provisionalCredit(@PathVariable Long disputeId) {
        return DisputeResponse.from(disputeService.issueProvisionalCredit(disputeId));
    }

    @PostMapping("/{disputeId}/represent")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Record a merchant representment with evidence")
    public DisputeResponse represent(@PathVariable Long disputeId,
                                     @RequestBody(required = false) RepresentRequest req) {
        return DisputeResponse.from(disputeService.represent(disputeId, req == null ? null : req.note()));
    }

    @PostMapping("/{disputeId}/resolve")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Resolve the dispute: won hard-posts the credit, lost reverses it")
    public DisputeResponse resolve(@PathVariable Long disputeId, @Valid @RequestBody ResolveRequest req) {
        return DisputeResponse.from(disputeService.resolve(disputeId, req.won(), req.note()));
    }

    @GetMapping("/{disputeId}")
    @Operation(summary = "Fetch a dispute")
    public DisputeResponse get(@PathVariable Long disputeId) {
        return DisputeResponse.from(disputeService.get(disputeId));
    }

    @GetMapping("/accounts/{accountId}")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "List all disputes on an account")
    public List<DisputeResponse> byAccount(@PathVariable Long accountId) {
        return disputeService.listByAccount(accountId).stream().map(DisputeResponse::from).toList();
    }
}
