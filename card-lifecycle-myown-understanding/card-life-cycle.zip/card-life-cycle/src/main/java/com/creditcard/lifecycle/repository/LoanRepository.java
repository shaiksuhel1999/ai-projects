package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Loan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {
    List<Loan> findByAccountIdOrderByCreatedAtDesc(Long accountId);
}
