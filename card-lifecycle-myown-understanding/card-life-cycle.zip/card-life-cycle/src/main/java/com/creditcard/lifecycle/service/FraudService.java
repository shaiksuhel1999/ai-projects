package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AuthResponseCode;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Real-time risk engine consulted by the issuer on every authorization, before
 * funds are checked. Mirrors the rules a real card processor evaluates inline:
 * per-transaction ceiling, merchant/region block-lists, and spend velocity.
 */
@Service
public class FraudService {

    private final TransactionRepository transactionRepository;
    private final BankProperties bank;

    public FraudService(TransactionRepository transactionRepository, BankProperties bank) {
        this.transactionRepository = transactionRepository;
        this.bank = bank;
    }

    /**
     * Screen an authorization request.
     *
     * @return the decline {@link AuthResponseCode} if a rule fires, otherwise empty (pass).
     */
    public Optional<AuthResponseCode> screen(Card card, Merchant merchant, BigDecimal amount) {
        BankProperties.Fraud rules = bank.getFraud();

        // 1) Absolute per-transaction ceiling.
        if (amount.compareTo(rules.getMaxSingleAmount()) > 0) {
            return Optional.of(AuthResponseCode.EXCEEDS_AMOUNT_LIMIT);
        }

        // 2) Blocked merchant category or country.
        if (merchant != null) {
            if (merchant.getMcc() != null && rules.getBlockedMccs().contains(merchant.getMcc())) {
                return Optional.of(AuthResponseCode.RESTRICTED_CARD);
            }
            if (merchant.getCountry() != null && rules.getBlockedCountries().contains(merchant.getCountry())) {
                return Optional.of(AuthResponseCode.RESTRICTED_CARD);
            }
        }

        // 3) Velocity: too many approved authorizations inside the rolling window.
        LocalDateTime windowStart = LocalDateTime.now().minusSeconds(rules.getVelocityWindowSeconds());
        List<Transaction> recent = transactionRepository
                .findByAccountIdAndCreatedAtAfter(card.getAccount().getId(), windowStart);
        long approvedRecently = recent.stream()
                .filter(t -> t.getType() == TransactionType.PURCHASE || t.getType() == TransactionType.CASH_ADVANCE)
                .filter(t -> t.getStatus() != TransactionStatus.DECLINED)
                .count();
        if (approvedRecently >= rules.getVelocityMaxCount()) {
            return Optional.of(AuthResponseCode.EXCEEDS_VELOCITY);
        }

        return Optional.empty();
    }
}
