package com.creditcard.lifecycle.exception;

/** Thrown when a referenced entity does not exist (HTTP 404). */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String type, Object id) {
        super(type + " not found: " + id);
    }
}
