package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.BillingDtos.StatementResponse;
import com.creditcard.lifecycle.service.BillingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Billing cycle: cut statements and read them back. */
@RestController
@RequestMapping("/api/accounts/{accountId}/statements")
@Tag(name = "6. Billing & statements", description = "Cut billing statements, apply interest & late fees")
public class BillingController {

    private final BillingService billingService;

    public BillingController(BillingService billingService) {
        this.billingService = billingService;
    }

    @PostMapping("/generate")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Cut a statement, closing the current billing cycle (charges interest & late fee if due)")
    public StatementResponse generate(@PathVariable Long accountId) {
        return StatementResponse.from(billingService.generateStatement(accountId));
    }

    @GetMapping
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "List all statements for the account (newest first)")
    public List<StatementResponse> list(@PathVariable Long accountId) {
        return billingService.listStatements(accountId).stream().map(StatementResponse::from).toList();
    }

    @GetMapping("/latest")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "Fetch the most recent statement")
    public StatementResponse latest(@PathVariable Long accountId) {
        return StatementResponse.from(billingService.latestStatement(accountId));
    }
}
