package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.model.AppUser;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.enums.Role;
import com.creditcard.lifecycle.repository.AppUserRepository;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Seeds reference merchants and one ready-to-use ACTIVE demo card so the REST API
 * can be exercised immediately from Swagger UI without any setup.
 */
@Component
@Order(1)
public class DataSeeder {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final MerchantRepository merchantRepository;
    private final CustomerService customerService;
    private final CardService cardService;
    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(MerchantRepository merchantRepository,
                      CustomerService customerService,
                      CardService cardService,
                      AppUserRepository appUserRepository,
                      PasswordEncoder passwordEncoder) {
        this.merchantRepository = merchantRepository;
        this.customerService = customerService;
        this.cardService = cardService;
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Order(1)
    public void seed() {
        Merchant grocery = merchantRepository.save(
                new Merchant("BigBazaar Retail", "5411", "HDFC Acquiring", "POS-0001"));
        merchantRepository.save(new Merchant("Cafe Coffee Day", "5812", "ICICI Acquiring", "POS-0002"));
        merchantRepository.save(new Merchant("Amazon India", "5999", "Axis Acquiring", "POS-0003"));

        Customer customer = customerService.create(new CreateCustomerRequest(
                "Aarav Sharma", "aarav.sharma@example.com", "+91-9000000001",
                new BigDecimal("1200000"), 760));

        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("150000"), "VISA", 1));
        cardService.activate(card.getId());

        // Logins: an ops ADMIN and a CUSTOMER scoped to the seeded customer.
        appUserRepository.save(new AppUser("admin", passwordEncoder.encode("admin123"), Role.ADMIN, null));
        appUserRepository.save(new AppUser("aarav", passwordEncoder.encode("password"), Role.CUSTOMER, customer.getId()));

        log.info("======================================================================");
        log.info(" Seeded demo data (ready to use in Swagger UI / curl):");
        log.info("   Merchant id .......... {}  ({})", grocery.getId(), grocery.getName());
        log.info("   Customer id .......... {}  ({})", customer.getId(), customer.getFullName());
        log.info("   Card id .............. {}  (ACTIVE, {})", card.getId(), card.getMaskedPan());
        log.info("   Account id ........... {}", card.getAccount().getId());
        log.info("   Card token ........... {}", card.getToken());
        log.info(" Logins:  admin/admin123 (ADMIN)   aarav/password (CUSTOMER, owns account above)");
        log.info(" Open Swagger UI:  http://localhost:8080/swagger-ui.html");
        log.info(" Open H2 console:  http://localhost:8080/h2-console  (JDBC URL jdbc:h2:mem:cardlifecycle)");
        log.info("======================================================================");
    }
}
