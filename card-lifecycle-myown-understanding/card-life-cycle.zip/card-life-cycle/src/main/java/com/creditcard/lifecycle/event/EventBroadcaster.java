package com.creditcard.lifecycle.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Fans real-time {@link LifecycleEvent}s out to every subscribed SSE client and
 * keeps a bounded buffer of the most recent events for late joiners / polling.
 *
 * <p>Events are delivered {@code AFTER_COMMIT} so only real, persisted state
 * changes are broadcast (with {@code fallbackExecution} so events published
 * outside a transaction are still delivered).
 */
@Component
public class EventBroadcaster {

    private static final Logger log = LoggerFactory.getLogger(EventBroadcaster.class);
    private static final int MAX_RECENT = 200;

    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();
    private final Deque<LifecycleEvent> recent = new ConcurrentLinkedDeque<>();

    /** Register a new SSE subscriber. */
    public SseEmitter subscribe() {
        SseEmitter emitter = new SseEmitter(0L); // no server-side timeout
        emitters.add(emitter);
        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        emitter.onError(ex -> emitters.remove(emitter));
        try {
            emitter.send(SseEmitter.event().name("connected")
                    .data("subscribed to card lifecycle events"));
        } catch (IOException ex) {
            emitters.remove(emitter);
        }
        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onEvent(LifecycleEvent event) {
        addRecent(event);
        for (SseEmitter emitter : emitters) {
            try {
                emitter.send(SseEmitter.event()
                        .id(String.valueOf(event.seq()))
                        .name(event.type().name())
                        .data(event));
            } catch (Exception ex) {
                emitters.remove(emitter);
            }
        }
        log.info("event #{} {} - {}", event.seq(), event.type(), event.message());
    }

    private void addRecent(LifecycleEvent event) {
        recent.addFirst(event);
        while (recent.size() > MAX_RECENT) {
            recent.removeLast();
        }
    }

    /** Most recent events, newest first. */
    public List<LifecycleEvent> recent() {
        return new ArrayList<>(recent);
    }

    public int subscriberCount() {
        return emitters.size();
    }
}
