package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.CardBrand;
import com.creditcard.lifecycle.model.enums.CardStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;

/**
 * The card instrument. The full PAN is never stored in clear text &mdash; we keep a
 * masked PAN plus a network token, which is what the acquirer/network would carry.
 */
@Entity
@Table(name = "cards")
@Getter
@Setter
@NoArgsConstructor
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "account_id")
    private CreditAccount account;

    /** Masked PAN shown to humans, e.g. {@code 411111******1111}. */
    @Column(nullable = false)
    private String maskedPan;

    /** Last four digits, used for display and matching. */
    @Column(nullable = false, length = 4)
    private String panLast4;

    /** Network token that stands in for the PAN in the auth flow. */
    @Column(nullable = false, unique = true)
    private String token;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CardBrand brand;

    private int expiryMonth;

    private int expiryYear;

    /** Hash of the CVV (never the raw value). */
    private String cvvHash;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CardStatus status = CardStatus.ISSUED;

    private LocalDateTime issuedAt = LocalDateTime.now();

    private LocalDateTime activatedAt;

    public boolean isExpired() {
        return YearMonth.of(expiryYear, expiryMonth).isBefore(YearMonth.from(LocalDate.now()));
    }
}
