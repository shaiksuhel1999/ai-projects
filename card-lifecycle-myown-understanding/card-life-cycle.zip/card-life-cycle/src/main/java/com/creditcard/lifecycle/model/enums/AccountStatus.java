package com.creditcard.lifecycle.model.enums;

/** Status of the revolving credit account that backs one or more cards. */
public enum AccountStatus {
    ACTIVE,
    /** Over-limit or otherwise frozen; new authorizations are declined. */
    FROZEN,
    /** Missed payments beyond the allowed window. */
    DELINQUENT,
    CLOSED
}
