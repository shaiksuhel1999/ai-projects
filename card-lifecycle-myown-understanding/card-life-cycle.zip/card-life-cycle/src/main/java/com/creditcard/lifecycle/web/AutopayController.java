package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.AutopayDtos.AutopayResponse;
import com.creditcard.lifecycle.dto.AutopayDtos.EnrollRequest;
import com.creditcard.lifecycle.dto.CommonDtos.MessageResponse;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.service.AutopayService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Autopay standing instruction: enroll, disable, and run the autopay batch. */
@RestController
@RequestMapping("/api")
@Tag(name = "13. Autopay", description = "Auto-debit the minimum or total due on the due date")
public class AutopayController {

    private final AutopayService autopayService;

    public AutopayController(AutopayService autopayService) {
        this.autopayService = autopayService;
    }

    @PostMapping("/accounts/{accountId}/autopay")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "Enroll an account in autopay (MINIMUM_DUE or TOTAL_DUE)")
    public AutopayResponse enroll(@PathVariable Long accountId, @Valid @RequestBody EnrollRequest req) {
        CreditAccount a = autopayService.enroll(accountId, req.type());
        return new AutopayResponse(a.getId(), a.isAutopayEnabled(),
                a.getAutopayType() == null ? null : a.getAutopayType().name());
    }

    @DeleteMapping("/accounts/{accountId}/autopay")
    @PreAuthorize("@access.ownsAccount(authentication, #accountId)")
    @Operation(summary = "Disable autopay for an account")
    public AutopayResponse disable(@PathVariable Long accountId) {
        CreditAccount a = autopayService.disable(accountId);
        return new AutopayResponse(a.getId(), a.isAutopayEnabled(),
                a.getAutopayType() == null ? null : a.getAutopayType().name());
    }

    @PostMapping("/autopay/run")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Run the autopay batch now (pays all enrolled accounts whose due date has arrived)")
    public MessageResponse run() {
        int count = autopayService.runAutopay();
        return new MessageResponse("Autopay executed on " + count + " account(s)");
    }
}
