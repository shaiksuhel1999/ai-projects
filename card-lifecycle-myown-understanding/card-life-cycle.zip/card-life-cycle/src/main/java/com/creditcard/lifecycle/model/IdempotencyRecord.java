package com.creditcard.lifecycle.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Stores the outcome of a mutating request keyed by its client-supplied
 * {@code Idempotency-Key}, so a retried POST replays the original response
 * instead of executing the operation twice.
 */
@Entity
@Table(name = "idempotency_records")
@Getter
@Setter
@NoArgsConstructor
public class IdempotencyRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_key", nullable = false, unique = true)
    private String idKey;

    private String method;

    private String path;

    /** false while the first request is in flight; true once its response is stored. */
    private boolean completed = false;

    private Integer httpStatus;

    private String contentType;

    @Lob
    private String responseBody;

    private LocalDateTime createdAt = LocalDateTime.now();

    public IdempotencyRecord(String idKey, String method, String path) {
        this.idKey = idKey;
        this.method = method;
        this.path = path;
    }
}
