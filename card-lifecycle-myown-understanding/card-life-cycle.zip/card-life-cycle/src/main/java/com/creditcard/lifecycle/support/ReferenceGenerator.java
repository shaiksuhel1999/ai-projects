package com.creditcard.lifecycle.support;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Component;

/**
 * Cluster-safe transaction-reference generator backed by a database sequence
 * ({@code reference_seq}, created in schema.sql). Every node draws from the same
 * sequence, so references stay unique across a horizontally scaled deployment —
 * unlike a per-JVM counter.
 *
 * <p>Called only from within an active transaction (every service method that
 * mints a reference is {@code @Transactional}), so the shared EntityManager
 * resolves to the caller's persistence context.
 */
@Component
public class ReferenceGenerator {

    @PersistenceContext
    private EntityManager em;

    public String next(String prefix) {
        Number value = (Number) em.createNativeQuery("SELECT NEXT VALUE FOR reference_seq").getSingleResult();
        return prefix + Long.toString(value.longValue(), 36).toUpperCase();
    }
}
