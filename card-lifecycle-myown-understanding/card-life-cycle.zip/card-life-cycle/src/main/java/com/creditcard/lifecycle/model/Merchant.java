package com.creditcard.lifecycle.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** A merchant that accepts the card at a POS terminal, onboarded by an acquirer. */
@Entity
@Table(name = "merchants")
@Getter
@Setter
@NoArgsConstructor
public class Merchant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    /** Merchant Category Code, e.g. 5411 = grocery, 5812 = restaurants. */
    private String mcc;

    /** The acquiring bank that settles funds to this merchant. */
    private String acquirerName;

    private String terminalId;

    private String country = "IN";

    public Merchant(String name, String mcc, String acquirerName, String terminalId) {
        this.name = name;
        this.mcc = mcc;
        this.acquirerName = acquirerName;
        this.terminalId = terminalId;
    }
}
