package com.creditcard.lifecycle.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI cardLifecycleOpenApi() {
        return new OpenAPI().info(new Info()
                .title("Credit Card Lifecycle API")
                .version("1.0.0")
                .description("""
                        End-to-end credit card lifecycle:
                        onboard a customer -> issue & activate a card -> authorize at a POS
                        (Acquirer -> Network -> Issuer) -> capture & settle -> cut a statement ->
                        make monthly payments -> apply for loans / convert purchases to EMI and repay.
                        Follow the numbered tags (1..8) top to bottom for the happy-path journey."""));
    }
}
