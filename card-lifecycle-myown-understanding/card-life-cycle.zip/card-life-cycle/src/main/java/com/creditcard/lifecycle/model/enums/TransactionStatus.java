package com.creditcard.lifecycle.model.enums;

/** Clearing lifecycle of a card transaction. */
public enum TransactionStatus {
    /** Issuer approved and placed a hold on available credit. Funds not yet moved. */
    AUTHORIZED,
    /** Issuer declined the authorization. */
    DECLINED,
    /** Merchant captured the authorization (clearing). Balance posted. */
    CAPTURED,
    /** Interbank settlement completed. Terminal happy-path state. */
    SETTLED,
    /** Authorization released before capture (auth reversal). */
    REVERSED,
    /** Fully refunded back to the cardholder. */
    REFUNDED,
    /** A booked entry that needs no clearing (payment, fee, interest, EMI). */
    POSTED,
    /** A memo post: affects available balance immediately, awaiting hard-posting to the ledger. */
    MEMO
}
