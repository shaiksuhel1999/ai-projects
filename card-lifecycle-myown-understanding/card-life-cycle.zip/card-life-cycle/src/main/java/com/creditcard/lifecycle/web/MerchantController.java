package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.MerchantDtos.CreateMerchantRequest;
import com.creditcard.lifecycle.dto.MerchantDtos.MerchantResponse;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.repository.MerchantRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/merchants")
@Tag(name = "2. Merchants", description = "Merchants that accept the card at a POS terminal")
public class MerchantController {

    private final MerchantRepository merchantRepository;

    public MerchantController(MerchantRepository merchantRepository) {
        this.merchantRepository = merchantRepository;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Register a merchant / POS terminal")
    public ResponseEntity<MerchantResponse> create(@Valid @RequestBody CreateMerchantRequest req) {
        Merchant m = new Merchant(req.name(), req.mcc(), req.acquirerName(), req.terminalId());
        if (req.country() != null && !req.country().isBlank()) {
            m.setCountry(req.country());
        }
        merchantRepository.save(m);
        return ResponseEntity.status(HttpStatus.CREATED).body(MerchantResponse.from(m));
    }

    @GetMapping
    @Operation(summary = "List all merchants")
    public List<MerchantResponse> list() {
        return merchantRepository.findAll().stream().map(MerchantResponse::from).toList();
    }
}
