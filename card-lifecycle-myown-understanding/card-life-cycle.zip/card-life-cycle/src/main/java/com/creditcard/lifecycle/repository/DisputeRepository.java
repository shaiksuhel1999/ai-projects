package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Dispute;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DisputeRepository extends JpaRepository<Dispute, Long> {

    List<Dispute> findByAccountIdOrderByCreatedAtDesc(Long accountId);

    List<Dispute> findByTransactionId(Long transactionId);
}
