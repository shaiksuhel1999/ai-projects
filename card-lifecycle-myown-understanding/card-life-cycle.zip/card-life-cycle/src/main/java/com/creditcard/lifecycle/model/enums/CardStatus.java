package com.creditcard.lifecycle.model.enums;

/** Lifecycle states of a physical/virtual card instrument. */
public enum CardStatus {
    /** Card record created, plastic/virtual number generated, not yet usable. */
    ISSUED,
    /** Activated by the cardholder and ready to transact. */
    ACTIVE,
    /** Temporarily blocked (lost/stolen/fraud hold); can be re-activated. */
    BLOCKED,
    /** Past its expiry date. */
    EXPIRED,
    /** Permanently closed; terminal state. */
    CLOSED
}
