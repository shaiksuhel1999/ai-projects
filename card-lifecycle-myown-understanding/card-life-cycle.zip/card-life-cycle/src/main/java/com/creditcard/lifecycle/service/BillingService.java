package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.config.BankProperties;
import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Statement;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AccountStatus;
import com.creditcard.lifecycle.model.enums.StatementStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.CreditAccountRepository;
import com.creditcard.lifecycle.repository.StatementRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

/**
 * The billing engine. Cuts a statement for a cycle: first charges any interest
 * and late fee owed from the previous cycle, then summarizes every posting in
 * the window and computes the closing balance, minimum due and payment due date.
 */
@Service
@Transactional
public class BillingService {

    private final CreditAccountRepository accountRepository;
    private final StatementRepository statementRepository;
    private final TransactionRepository transactionRepository;
    private final BankProperties bank;
    private final LifecycleEvents events;
    private final ReferenceGenerator references;

    public BillingService(CreditAccountRepository accountRepository,
                          StatementRepository statementRepository,
                          TransactionRepository transactionRepository,
                          BankProperties bank,
                          LifecycleEvents events,
                          ReferenceGenerator references) {
        this.accountRepository = accountRepository;
        this.statementRepository = statementRepository;
        this.transactionRepository = transactionRepository;
        this.bank = bank;
        this.events = events;
        this.references = references;
    }

    /** Cut a new statement for the account, closing the current billing cycle. */
    public Statement generateStatement(Long accountId) {
        CreditAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account", accountId));

        Statement previous = statementRepository
                .findFirstByAccountIdOrderByStatementDateDesc(accountId).orElse(null);

        // 1) Carry-over charges from the prior cycle: late fee + revolving interest.
        if (previous != null) {
            applyDelinquencyAndInterest(account, previous);
        }

        // 2) Collect everything posted in this cycle window (exclusive start, inclusive end).
        LocalDateTime windowStart = account.getLastStatementAt() != null
                ? account.getLastStatementAt()
                : account.getCreatedAt().minusYears(1);
        LocalDateTime windowEnd = LocalDateTime.now();
        List<Transaction> cycle = transactionRepository
                .findByAccountIdAndCreatedAtAfterAndCreatedAtLessThanEqual(accountId, windowStart, windowEnd);

        LocalDate statementDate = LocalDate.now();
        Statement statement = new Statement();
        statement.setAccount(account);
        statement.setStatementDate(statementDate);
        statement.setDueDate(statementDate.plusDays(bank.getGracePeriodDays()));
        statement.setOpeningBalance(previous != null ? previous.getClosingBalance() : BigDecimal.ZERO.setScale(2));

        BigDecimal purchases = BigDecimal.ZERO;
        BigDecimal cashAdvances = BigDecimal.ZERO;
        BigDecimal fees = BigDecimal.ZERO;
        BigDecimal interest = BigDecimal.ZERO;
        BigDecimal emiCharges = BigDecimal.ZERO;
        BigDecimal creditsAndPayments = BigDecimal.ZERO;

        for (Transaction t : cycle) {
            // Only hard-posted movements belong on a statement: skip holds, declines,
            // reversals and memo posts that have not yet been hard-posted.
            if (t.getStatus() == TransactionStatus.MEMO || t.getStatus() == TransactionStatus.AUTHORIZED
                    || t.getStatus() == TransactionStatus.DECLINED || t.getStatus() == TransactionStatus.REVERSED) {
                continue;
            }
            switch (t.getType()) {
                case PURCHASE -> {
                    if (isPosted(t)) {
                        purchases = purchases.add(t.getCapturedAmount());
                    }
                }
                case CASH_ADVANCE -> cashAdvances = cashAdvances.add(t.getCapturedAmount());
                case FEE -> fees = fees.add(t.getAmount());
                case INTEREST -> interest = interest.add(t.getAmount());
                case EMI_INSTALLMENT -> emiCharges = emiCharges.add(t.getAmount());
                case ADJUSTMENT_DEBIT, CHARGEBACK -> fees = fees.add(t.getAmount());
                case PAYMENT, REFUND, ADJUSTMENT_CREDIT, PROVISIONAL_CREDIT, REWARD_REDEMPTION ->
                        creditsAndPayments = creditsAndPayments.add(t.getAmount());
            }
        }

        statement.setPurchases(Money.of(purchases));
        statement.setCashAdvances(Money.of(cashAdvances));
        statement.setFees(Money.of(fees));
        statement.setInterest(Money.of(interest));
        statement.setEmiCharges(Money.of(emiCharges));
        statement.setPaymentsAndCredits(Money.of(creditsAndPayments));

        BigDecimal closing = Money.of(account.getCurrentBalance());
        statement.setClosingBalance(closing);
        BigDecimal minimumDue = computeMinimumDue(closing);
        statement.setMinimumDue(minimumDue);
        statement.setStatus(StatementStatus.GENERATED);
        statementRepository.save(statement);

        // 3) Roll the account's billing snapshot forward into the new cycle.
        account.setCurrentStatementBalance(closing);
        account.setStatementRemaining(Money.max(BigDecimal.ZERO.setScale(2), closing));
        account.setMinimumDue(minimumDue);
        account.setPaymentDueDate(statement.getDueDate());
        account.setPaidThisCycle(BigDecimal.ZERO.setScale(2));
        account.setLastStatementDate(statementDate);
        account.setLastStatementAt(windowEnd);

        events.publish(EventType.STATEMENT_GENERATED,
                "Statement cut: closing " + closing + ", min due " + minimumDue + ", due " + statement.getDueDate(),
                account.getId(), null, null, closing);
        return statement;
    }

    /**
     * Charge a late fee if the previous minimum was missed, and interest on the
     * <b>average daily balance</b> when the previous statement was left revolving.
     *
     * <p>Grace period: if the previous statement was paid in full ({@code statementRemaining == 0})
     * no interest accrues. Otherwise interest = ADB &times; APR/100 &times; cycleDays/365, where the
     * ADB is reconstructed from the ledger history over the closing cycle.
     */
    private void applyDelinquencyAndInterest(CreditAccount account, Statement previous) {
        boolean minimumMissed = account.getMinimumDue().signum() > 0
                && account.getPaidThisCycle().compareTo(account.getMinimumDue()) < 0;

        // Compute the ADB from the cycle's ledger activity BEFORE posting fee/interest.
        LocalDateTime cycleStart = account.getLastStatementAt() != null
                ? account.getLastStatementAt()
                : account.getCreatedAt();
        BigDecimal adb = averageDailyBalance(account.getId(), cycleStart, LocalDateTime.now(),
                previous.getClosingBalance());

        if (minimumMissed) {
            postCharge(account, TransactionType.FEE, Money.of(bank.getLatePaymentFee()), "LATE_PAYMENT_FEE");
            account.setStatus(AccountStatus.DELINQUENT);
        }

        // Interest accrues only if the prior statement was left partly unpaid (no grace).
        if (Money.isPositive(account.getStatementRemaining()) && Money.isPositive(adb)) {
            BigDecimal dailyRate = account.getApr()
                    .divide(BigDecimal.valueOf(100), 12, Money.ROUNDING)
                    .divide(BigDecimal.valueOf(365), 12, Money.ROUNDING);
            BigDecimal interest = Money.of(adb.multiply(dailyRate).multiply(BigDecimal.valueOf(bank.getCycleLengthDays())));
            if (Money.isPositive(interest)) {
                postCharge(account, TransactionType.INTEREST, interest, "REVOLVING_INTEREST_ADB");
            }
        }
    }

    /**
     * Average daily balance over the closing cycle, reconstructed by replaying the
     * cycle's ledger postings from the opening balance and weighting each balance
     * level by the time it was held.
     */
    private BigDecimal averageDailyBalance(Long accountId, LocalDateTime cycleStart, LocalDateTime cycleEnd,
                                           BigDecimal openingBalance) {
        long totalSeconds = Duration.between(cycleStart, cycleEnd).getSeconds();
        List<Transaction> postings = transactionRepository
                .findByAccountIdAndCreatedAtAfterAndCreatedAtLessThanEqual(accountId, cycleStart, cycleEnd).stream()
                .filter(this::affectsLedger)
                .sorted(Comparator.comparing(Transaction::getCreatedAt))
                .toList();

        BigDecimal weighted = BigDecimal.ZERO;
        BigDecimal balance = openingBalance;
        LocalDateTime prev = cycleStart;
        for (Transaction t : postings) {
            long seconds = Math.max(0, Duration.between(prev, t.getCreatedAt()).getSeconds());
            weighted = weighted.add(balance.multiply(BigDecimal.valueOf(seconds)));
            balance = balance.add(ledgerDelta(t));
            prev = t.getCreatedAt();
        }
        long tail = Math.max(0, Duration.between(prev, cycleEnd).getSeconds());
        weighted = weighted.add(balance.multiply(BigDecimal.valueOf(tail)));

        // A cycle shorter than a day can't be meaningfully time-weighted; use the ending balance.
        if (totalSeconds < 86_400) {
            return balance;
        }
        return weighted.divide(BigDecimal.valueOf(totalSeconds), 10, Money.ROUNDING);
    }

    /** True for hard-posted movements that changed the ledger balance during the cycle. */
    private boolean affectsLedger(Transaction t) {
        return t.getStatus() == TransactionStatus.POSTED
                || t.getStatus() == TransactionStatus.CAPTURED
                || t.getStatus() == TransactionStatus.SETTLED;
    }

    /** Signed effect of a posting on the ledger balance (debit +, credit -). */
    private BigDecimal ledgerDelta(Transaction t) {
        BigDecimal magnitude = (t.getType() == TransactionType.PURCHASE || t.getType() == TransactionType.CASH_ADVANCE)
                ? t.getCapturedAmount()
                : t.getAmount();
        return t.getType().sign() < 0 ? magnitude.negate() : magnitude;
    }

    private void postCharge(CreditAccount account, TransactionType type, BigDecimal amount, String reason) {
        account.setCurrentBalance(Money.of(account.getCurrentBalance().add(amount)));
        Transaction txn = new Transaction();
        txn.setReference(references.next("TXN"));
        txn.setAccount(account);
        txn.setType(type);
        txn.setStatus(TransactionStatus.POSTED);
        txn.setAmount(amount);
        txn.setReason(reason);
        transactionRepository.save(txn);
    }

    private BigDecimal computeMinimumDue(BigDecimal closingBalance) {
        if (closingBalance.signum() <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        BigDecimal percentPart = closingBalance
                .multiply(bank.getMinPaymentPercent())
                .divide(BigDecimal.valueOf(100), Money.SCALE, Money.ROUNDING);
        BigDecimal min = Money.max(percentPart, Money.of(bank.getMinPaymentFloor()));
        return Money.of(Money.min(min, closingBalance));
    }

    private boolean isPosted(Transaction t) {
        return t.getStatus() == TransactionStatus.CAPTURED || t.getStatus() == TransactionStatus.SETTLED;
    }

    @Transactional(readOnly = true)
    public List<Statement> listStatements(Long accountId) {
        return statementRepository.findByAccountIdOrderByStatementDateDesc(accountId);
    }

    @Transactional(readOnly = true)
    public Statement latestStatement(Long accountId) {
        return statementRepository.findFirstByAccountIdOrderByStatementDateDesc(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Statement for account", accountId));
    }
}
