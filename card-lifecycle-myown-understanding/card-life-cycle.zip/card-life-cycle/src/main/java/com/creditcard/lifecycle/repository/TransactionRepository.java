package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Optional<Transaction> findByReference(String reference);

    List<Transaction> findByAccountIdOrderByCreatedAtDesc(Long accountId);

    List<Transaction> findByStatus(TransactionStatus status);

    /** Memo posts flagged for automatic hard-posting by the posting cycle. */
    List<Transaction> findByStatusAndAutoPost(TransactionStatus status, boolean autoPost);

    /** Postings that belong to a billing cycle: created after the last statement, up to the cut date. */
    List<Transaction> findByAccountIdAndCreatedAtAfterAndCreatedAtLessThanEqual(
            Long accountId, LocalDateTime after, LocalDateTime upToInclusive);

    /** Recent transactions on an account, used by the real-time velocity check. */
    List<Transaction> findByAccountIdAndCreatedAtAfter(Long accountId, LocalDateTime after);

    /** Stale authorizations (holds) older than a cutoff, for hold expiry. */
    List<Transaction> findByStatusAndCreatedAtBefore(TransactionStatus status, LocalDateTime cutoff);
}
