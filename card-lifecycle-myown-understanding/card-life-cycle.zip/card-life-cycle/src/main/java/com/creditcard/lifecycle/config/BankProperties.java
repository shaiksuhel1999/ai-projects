package com.creditcard.lifecycle.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Externalized business rules for the issuer / billing / lending / risk engines.
 * Bound from the {@code bank.*} keys in application.yml.
 */
@ConfigurationProperties(prefix = "bank")
public class BankProperties {

    private BigDecimal defaultApr = new BigDecimal("36.0");
    private BigDecimal cashAdvanceApr = new BigDecimal("42.0");
    private BigDecimal minPaymentPercent = new BigDecimal("5.0");
    private BigDecimal minPaymentFloor = new BigDecimal("200.00");
    private int gracePeriodDays = 20;
    private BigDecimal latePaymentFee = new BigDecimal("500.00");
    private int cycleLengthDays = 30;
    private Loan loan = new Loan();
    private Fraud fraud = new Fraud();
    private Settlement settlement = new Settlement();
    private Posting posting = new Posting();
    private Rewards rewards = new Rewards();
    private Autopay autopay = new Autopay();
    private Auth auth = new Auth();

    public static class Loan {
        private int minCreditScore = 650;
        private BigDecimal maxIncomeMultiple = new BigDecimal("5.0");
        private BigDecimal baseRate = new BigDecimal("14.0");

        public int getMinCreditScore() { return minCreditScore; }
        public void setMinCreditScore(int minCreditScore) { this.minCreditScore = minCreditScore; }
        public BigDecimal getMaxIncomeMultiple() { return maxIncomeMultiple; }
        public void setMaxIncomeMultiple(BigDecimal maxIncomeMultiple) { this.maxIncomeMultiple = maxIncomeMultiple; }
        public BigDecimal getBaseRate() { return baseRate; }
        public void setBaseRate(BigDecimal baseRate) { this.baseRate = baseRate; }
    }

    /** Real-time authorization risk controls evaluated by the issuer on every request. */
    public static class Fraud {
        /** Any single authorization above this is declined (response code 61). */
        private BigDecimal maxSingleAmount = new BigDecimal("100000.00");
        /** Rolling window used for the velocity check. */
        private int velocityWindowSeconds = 60;
        /** Max approved authorizations allowed inside the window (response code 65). */
        private int velocityMaxCount = 5;
        /** Merchant category codes that are blocked (response code 62). */
        private List<String> blockedMccs = new ArrayList<>();
        /** Country codes that are blocked (response code 62). */
        private List<String> blockedCountries = new ArrayList<>();

        public BigDecimal getMaxSingleAmount() { return maxSingleAmount; }
        public void setMaxSingleAmount(BigDecimal maxSingleAmount) { this.maxSingleAmount = maxSingleAmount; }
        public int getVelocityWindowSeconds() { return velocityWindowSeconds; }
        public void setVelocityWindowSeconds(int velocityWindowSeconds) { this.velocityWindowSeconds = velocityWindowSeconds; }
        public int getVelocityMaxCount() { return velocityMaxCount; }
        public void setVelocityMaxCount(int velocityMaxCount) { this.velocityMaxCount = velocityMaxCount; }
        public List<String> getBlockedMccs() { return blockedMccs; }
        public void setBlockedMccs(List<String> blockedMccs) { this.blockedMccs = blockedMccs; }
        public List<String> getBlockedCountries() { return blockedCountries; }
        public void setBlockedCountries(List<String> blockedCountries) { this.blockedCountries = blockedCountries; }
    }

    /** Controls the automatic (scheduled) settlement batch. */
    public static class Settlement {
        /** When true, a background job periodically settles captured transactions. */
        private boolean autoEnabled = true;
        /** Delay between settlement runs, in milliseconds. */
        private long intervalMs = 20000;

        public boolean isAutoEnabled() { return autoEnabled; }
        public void setAutoEnabled(boolean autoEnabled) { this.autoEnabled = autoEnabled; }
        public long getIntervalMs() { return intervalMs; }
        public void setIntervalMs(long intervalMs) { this.intervalMs = intervalMs; }
    }

    /** Controls the automatic (scheduled) posting cycle that hard-posts memo entries. */
    public static class Posting {
        private boolean autoEnabled = true;
        private long intervalMs = 30000;

        public boolean isAutoEnabled() { return autoEnabled; }
        public void setAutoEnabled(boolean autoEnabled) { this.autoEnabled = autoEnabled; }
        public long getIntervalMs() { return intervalMs; }
        public void setIntervalMs(long intervalMs) { this.intervalMs = intervalMs; }
    }

    /** Rewards / cashback earning and redemption. */
    public static class Rewards {
        /** Base points earned per unit of spend (0.01 = 1 point per 100 spent). */
        private BigDecimal basePointsPerUnit = new BigDecimal("0.01");
        /** Cash value of one point when redeemed (statement credit). */
        private BigDecimal pointsToCash = new BigDecimal("0.25");
        /** Per-MCC earn multipliers, e.g. groceries 2x, dining 3x. */
        private Map<String, BigDecimal> categoryMultipliers = new LinkedHashMap<>();

        public BigDecimal getBasePointsPerUnit() { return basePointsPerUnit; }
        public void setBasePointsPerUnit(BigDecimal basePointsPerUnit) { this.basePointsPerUnit = basePointsPerUnit; }
        public BigDecimal getPointsToCash() { return pointsToCash; }
        public void setPointsToCash(BigDecimal pointsToCash) { this.pointsToCash = pointsToCash; }
        public Map<String, BigDecimal> getCategoryMultipliers() { return categoryMultipliers; }
        public void setCategoryMultipliers(Map<String, BigDecimal> categoryMultipliers) { this.categoryMultipliers = categoryMultipliers; }
    }

    /** Controls the automatic (scheduled) autopay run. */
    public static class Autopay {
        private boolean autoEnabled = true;
        private long intervalMs = 60000;

        public boolean isAutoEnabled() { return autoEnabled; }
        public void setAutoEnabled(boolean autoEnabled) { this.autoEnabled = autoEnabled; }
        public long getIntervalMs() { return intervalMs; }
        public void setIntervalMs(long intervalMs) { this.intervalMs = intervalMs; }
    }

    /** Authorization-hold lifecycle: unused holds are released after this many days. */
    public static class Auth {
        private int holdExpiryDays = 7;
        private boolean expiryEnabled = true;
        private long checkIntervalMs = 45000;

        public int getHoldExpiryDays() { return holdExpiryDays; }
        public void setHoldExpiryDays(int holdExpiryDays) { this.holdExpiryDays = holdExpiryDays; }
        public boolean isExpiryEnabled() { return expiryEnabled; }
        public void setExpiryEnabled(boolean expiryEnabled) { this.expiryEnabled = expiryEnabled; }
        public long getCheckIntervalMs() { return checkIntervalMs; }
        public void setCheckIntervalMs(long checkIntervalMs) { this.checkIntervalMs = checkIntervalMs; }
    }

    public BigDecimal getDefaultApr() { return defaultApr; }
    public void setDefaultApr(BigDecimal defaultApr) { this.defaultApr = defaultApr; }
    public BigDecimal getCashAdvanceApr() { return cashAdvanceApr; }
    public void setCashAdvanceApr(BigDecimal cashAdvanceApr) { this.cashAdvanceApr = cashAdvanceApr; }
    public BigDecimal getMinPaymentPercent() { return minPaymentPercent; }
    public void setMinPaymentPercent(BigDecimal minPaymentPercent) { this.minPaymentPercent = minPaymentPercent; }
    public BigDecimal getMinPaymentFloor() { return minPaymentFloor; }
    public void setMinPaymentFloor(BigDecimal minPaymentFloor) { this.minPaymentFloor = minPaymentFloor; }
    public int getGracePeriodDays() { return gracePeriodDays; }
    public void setGracePeriodDays(int gracePeriodDays) { this.gracePeriodDays = gracePeriodDays; }
    public BigDecimal getLatePaymentFee() { return latePaymentFee; }
    public void setLatePaymentFee(BigDecimal latePaymentFee) { this.latePaymentFee = latePaymentFee; }
    public int getCycleLengthDays() { return cycleLengthDays; }
    public void setCycleLengthDays(int cycleLengthDays) { this.cycleLengthDays = cycleLengthDays; }
    public Loan getLoan() { return loan; }
    public void setLoan(Loan loan) { this.loan = loan; }
    public Fraud getFraud() { return fraud; }
    public void setFraud(Fraud fraud) { this.fraud = fraud; }
    public Settlement getSettlement() { return settlement; }
    public void setSettlement(Settlement settlement) { this.settlement = settlement; }
    public Posting getPosting() { return posting; }
    public void setPosting(Posting posting) { this.posting = posting; }
    public Rewards getRewards() { return rewards; }
    public void setRewards(Rewards rewards) { this.rewards = rewards; }
    public Autopay getAutopay() { return autopay; }
    public void setAutopay(Autopay autopay) { this.autopay = autopay; }
    public Auth getAuth() { return auth; }
    public void setAuth(Auth auth) { this.auth = auth; }
}
