package com.creditcard.lifecycle.config;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.LoanDtos.EmiConversionRequest;
import com.creditcard.lifecycle.dto.LoanDtos.LoanApplicationRequest;
import com.creditcard.lifecycle.dto.PaymentDtos.PaymentRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Dispute;
import com.creditcard.lifecycle.model.Installment;
import com.creditcard.lifecycle.model.Loan;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Statement;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.DisputeReasonCode;
import com.creditcard.lifecycle.model.enums.PaymentType;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.AutopayService;
import com.creditcard.lifecycle.service.BillingService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.DisputeService;
import com.creditcard.lifecycle.service.LoanService;
import com.creditcard.lifecycle.service.PaymentService;
import com.creditcard.lifecycle.service.PostingService;
import com.creditcard.lifecycle.service.RewardsService;
import com.creditcard.lifecycle.service.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;

/**
 * Runs the entire card lifecycle end-to-end at startup and narrates each step to
 * the console, so the whole journey is visible without touching the REST API.
 * Disable with {@code demo.run=false}.
 */
@Component
@Order(2)
@ConditionalOnProperty(prefix = "demo", name = "run", havingValue = "true", matchIfMissing = true)
public class DemoRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoRunner.class);

    private final TransactionTemplate tx;
    private final CustomerService customerService;
    private final CardService cardService;
    private final AcquirerService acquirerService;
    private final TransactionService transactionService;
    private final TransactionRepository transactionRepository;
    private final BillingService billingService;
    private final PaymentService paymentService;
    private final LoanService loanService;
    private final DisputeService disputeService;
    private final PostingService postingService;
    private final RewardsService rewardsService;
    private final AutopayService autopayService;
    private final MerchantRepository merchantRepository;

    public DemoRunner(PlatformTransactionManager txManager,
                      CustomerService customerService,
                      CardService cardService,
                      AcquirerService acquirerService,
                      TransactionService transactionService,
                      TransactionRepository transactionRepository,
                      BillingService billingService,
                      PaymentService paymentService,
                      LoanService loanService,
                      DisputeService disputeService,
                      PostingService postingService,
                      RewardsService rewardsService,
                      AutopayService autopayService,
                      MerchantRepository merchantRepository) {
        this.tx = new TransactionTemplate(txManager);
        this.customerService = customerService;
        this.cardService = cardService;
        this.acquirerService = acquirerService;
        this.transactionService = transactionService;
        this.transactionRepository = transactionRepository;
        this.billingService = billingService;
        this.paymentService = paymentService;
        this.loanService = loanService;
        this.disputeService = disputeService;
        this.postingService = postingService;
        this.rewardsService = rewardsService;
        this.autopayService = autopayService;
        this.merchantRepository = merchantRepository;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Order(2)
    public void runDemo() {
        // Everything below runs inside one transaction so the walk-through is atomic.
        tx.executeWithoutResult(status -> lifecycle());
    }

    private void lifecycle() {
        banner("CREDIT CARD LIFECYCLE - END TO END WALK-THROUGH");

        // 1. Onboard a customer -------------------------------------------------
        Customer customer = customerService.create(new CreateCustomerRequest(
                "Diya Patel", "diya.patel@example.com", "+91-9000000002",
                new BigDecimal("1800000"), 780));
        log.info("[1] Onboarded customer #{} {} (score {}, income {})",
                customer.getId(), customer.getFullName(), customer.getCreditScore(), customer.getAnnualIncome());

        // 2. Issue + activate a card -------------------------------------------
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("200000"), "MASTERCARD", 1));
        cardService.activate(card.getId());
        CreditAccount account = card.getAccount();
        log.info("[2] Issued & activated {} card #{} {}  | account #{} limit {} available {}",
                card.getBrand(), card.getId(), card.getMaskedPan(), account.getId(),
                account.getCreditLimit(), account.getAvailableCredit());

        Merchant merchant = merchantRepository.findAll().get(0);

        // 3. POS purchase A: authorize -> capture -> settle --------------------
        Transaction purchaseA = authorizeCaptureSettle(card.getToken(), merchant.getId(),
                new BigDecimal("5000"), "purchase A (groceries)");

        // 3b. Real-time fraud control: a huge auth is declined at the issuer -----
        AuthorizeResponse risky = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("150000"), merchant.getId(), "INR"));
        log.info("[3b] Risk check - authorize 150000: {} [{} {}] (exceeds per-txn ceiling)",
                risky.decision(), risky.responseCode(), risky.responseText());

        // 4. Cut statement 1 and pay only the minimum due ----------------------
        Statement st1 = billingService.generateStatement(account.getId());
        log.info("[4] Statement #{} cut: closing {} | minDue {} | dueDate {}",
                st1.getId(), st1.getClosingBalance(), st1.getMinimumDue(), st1.getDueDate());
        paymentService.pay(account.getId(), new PaymentRequest(PaymentType.MINIMUM_DUE, null, "UPI"));
        log.info("    Paid MINIMUM_DUE. Balance now {} | statementRemaining {}",
                reload(account).getCurrentBalance(), reload(account).getStatementRemaining());

        // 5. Cut statement 2 -> revolving interest appears ---------------------
        Statement st2 = billingService.generateStatement(account.getId());
        log.info("[5] Statement #{} cut: interest charged {} | closing {} | minDue {}",
                st2.getId(), st2.getInterest(), st2.getClosingBalance(), st2.getMinimumDue());

        // 6. Pay the total due -> statement fully paid -------------------------
        paymentService.pay(account.getId(), new PaymentRequest(PaymentType.TOTAL_DUE, null, "NETBANKING"));
        log.info("[6] Paid TOTAL_DUE. Balance now {} | available {}",
                reload(account).getCurrentBalance(), reload(account).getAvailableCredit());

        // 7. POS purchase B (large) then convert it to a 6-month EMI ------------
        Transaction purchaseB = authorizeCaptureSettle(card.getToken(), merchant.getId(),
                new BigDecimal("60000"), "purchase B (laptop)");
        Loan emi = loanService.convertToEmi(new EmiConversionRequest(purchaseB.getId(), 6));
        Installment firstEmi = emi.getInstallments().get(0);
        log.info("[7] Converted purchase #{} to EMI loan #{}: {}% p.a., EMI {} x{} | 1st due {} (P {} / I {})",
                purchaseB.getId(), emi.getId(), emi.getAnnualRate(), emi.getEmiAmount(), emi.getTenureMonths(),
                firstEmi.getDueDate(), firstEmi.getPrincipalComponent(), firstEmi.getInterestComponent());
        loanService.payInstallment(emi.getId());
        log.info("    Paid EMI instalment 1. Outstanding principal now {}",
                loanService.get(emi.getId()).getOutstandingPrincipal());

        // 8. Apply for a personal loan, underwrite, disburse -------------------
        Loan loan = loanService.applyPersonalLoan(new LoanApplicationRequest(
                account.getId(), new BigDecimal("300000"), 12, "Home renovation"));
        log.info("[8] Personal loan #{}: {} - {}", loan.getId(), loan.getStatus(), loan.getDecisionReason());
        if (loan.getStatus().name().equals("APPROVED")) {
            Loan disbursed = loanService.disburse(loan.getId());
            Installment first = disbursed.getInstallments().get(0);
            log.info("    Disbursed: EMI {} x{} months | 1st instalment due {} (P {} / I {})",
                    disbursed.getEmiAmount(), disbursed.getTenureMonths(), first.getDueDate(),
                    first.getPrincipalComponent(), first.getInterestComponent());
        }

        // 8b. Dispute & chargeback on a settled purchase ----------------------
        Transaction purchaseC = authorizeCaptureSettle(card.getToken(), merchant.getId(),
                new BigDecimal("2500"), "purchase C (shoes)");
        Dispute dispute = disputeService.open(purchaseC.getId(), DisputeReasonCode.GOODS_NOT_RECEIVED, "not delivered");
        disputeService.issueProvisionalCredit(dispute.getId());
        log.info("[8b] Dispute #{} opened + provisional credit (memo); posted {} | available {}",
                dispute.getId(), reload(account).getCurrentBalance(), reload(account).getAvailableCredit());
        disputeService.resolve(dispute.getId(), true, "cardholder favour");
        log.info("     Dispute WON -> credit hard-posted; posted {} | memo {} | available {}",
                reload(account).getCurrentBalance(), reload(account).getMemoBalance(),
                reload(account).getAvailableCredit());

        // 8c. Auxiliary adjustment (memo) then the posting cycle --------------
        postingService.adjust(account.getId(), true, new BigDecimal("1000"), "Goodwill credit", true);
        log.info("[8c] Memo goodwill credit 1000; memo {} | available {}",
                reload(account).getMemoBalance(), reload(account).getAvailableCredit());
        PostingService.PostingSummary ps = postingService.runPostingCycle();
        log.info("     Posting cycle hard-posted {} entr(y/ies); posted balance {}",
                ps.postedCount(), reload(account).getCurrentBalance());

        // 8d. Fraud tag: report fraud -> card auto-blocked + dispute opened ----
        Transaction purchaseD = authorizeCaptureSettle(card.getToken(), merchant.getId(),
                new BigDecimal("1200"), "purchase D (online)");
        Dispute fraudDispute = disputeService.reportFraud(purchaseD.getId(), "card-not-present");
        log.info("[8d] Fraud reported on {} -> card {}, dispute #{} [{}]",
                purchaseD.getReference(), cardService.get(card.getId()).getStatus(),
                fraudDispute.getId(), fraudDispute.getReasonCode());
        AuthorizeResponse afterBlock = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("500"), merchant.getId(), "INR"));
        log.info("     Post-block auth 500: {} [{} {}]",
                afterBlock.decision(), afterBlock.responseCode(), afterBlock.responseText());

        // 8e. Rewards: points accrued on purchases; redeem some for statement credit
        log.info("[8e] Reward points earned across purchases: {}", reload(account).getRewardPoints());
        if (reload(account).getRewardPoints() >= 100) {
            RewardsService.Redemption red = rewardsService.redeem(account.getId(), 100);
            log.info("     Redeemed {} pts for {} statement credit; {} pts remaining",
                    red.pointsRedeemed(), red.cashCredited(), red.remainingPoints());
        }

        // 8f. Autopay: enrol, cut a statement, force the due date, run the batch
        billingService.generateStatement(account.getId());
        autopayService.enroll(account.getId(), PaymentType.MINIMUM_DUE);
        reload(account).setPaymentDueDate(java.time.LocalDate.now());
        int autopaid = autopayService.runAutopay();
        log.info("[8f] Autopay MINIMUM_DUE enrolled; batch paid {} account(s); paidThisCycle {}",
                autopaid, reload(account).getPaidThisCycle());

        // 9. Final account snapshot -------------------------------------------
        CreditAccount finalAcct = reload(account);
        log.info("[9] FINAL account #{}: balance {} | hold {} | available {} | rewardPts {} | status {}",
                finalAcct.getId(), finalAcct.getCurrentBalance(), finalAcct.getHoldAmount(),
                finalAcct.getAvailableCredit(), finalAcct.getRewardPoints(), finalAcct.getStatus());
        banner("WALK-THROUGH COMPLETE - Swagger /swagger-ui.html | live stream GET /api/stream/events");
    }

    /** Authorize a purchase through the POS->Acquirer->Network->Issuer flow, then capture and settle it. */
    private Transaction authorizeCaptureSettle(String token, Long merchantId, BigDecimal amount, String label) {
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(token, amount, merchantId, "INR"));
        log.info("[3] Authorize {} for {}: {} [{} {}] auth={} stan={} | trace: {}",
                label, amount, auth.decision(), auth.responseCode(), auth.responseText(),
                auth.authCode(), auth.stan(), auth.flowTrace());
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        transactionService.capture(txn.getId(), null);
        TransactionService.SettlementSummary summary = transactionService.settleBatch();
        log.info("    Captured & settled: {} txn(s) for {}", summary.settledCount(), summary.settledAmount());
        return transactionRepository.findById(txn.getId()).orElseThrow();
    }

    private CreditAccount reload(CreditAccount account) {
        return cardService.getAccount(account.getId());
    }

    private void banner(String text) {
        log.info("");
        log.info("############################################################");
        log.info("# {}", text);
        log.info("############################################################");
    }
}
