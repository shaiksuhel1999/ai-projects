package com.creditcard.lifecycle.model;

import com.creditcard.lifecycle.model.enums.StatementStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A billing statement cut at the end of a cycle. Summarizes every posting since
 * the previous statement and tells the cardholder the minimum due and due date.
 */
@Entity
@Table(name = "statements")
@Getter
@Setter
@NoArgsConstructor
public class Statement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "account_id")
    private CreditAccount account;

    private LocalDate statementDate;

    private LocalDate dueDate;

    /** Balance carried over from the previous statement. */
    @Column(precision = 19, scale = 2)
    private BigDecimal openingBalance = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal purchases = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal cashAdvances = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal fees = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal interest = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal emiCharges = BigDecimal.ZERO;

    /** Payments and refunds credited during the cycle. */
    @Column(precision = 19, scale = 2)
    private BigDecimal paymentsAndCredits = BigDecimal.ZERO;

    /** Total owed as of the statement date. */
    @Column(precision = 19, scale = 2)
    private BigDecimal closingBalance = BigDecimal.ZERO;

    @Column(precision = 19, scale = 2)
    private BigDecimal minimumDue = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatementStatus status = StatementStatus.GENERATED;

    private LocalDateTime generatedAt = LocalDateTime.now();
}
