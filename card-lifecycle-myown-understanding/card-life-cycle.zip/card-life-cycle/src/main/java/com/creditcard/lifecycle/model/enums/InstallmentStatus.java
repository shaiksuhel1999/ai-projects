package com.creditcard.lifecycle.model.enums;

/** Status of a single row in a loan's amortization schedule. */
public enum InstallmentStatus {
    PENDING,
    /** Billed onto the card statement but not yet paid. */
    BILLED,
    PAID,
    OVERDUE
}
