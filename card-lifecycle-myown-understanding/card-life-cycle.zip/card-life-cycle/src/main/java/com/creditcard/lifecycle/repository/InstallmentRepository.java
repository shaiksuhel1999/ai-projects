package com.creditcard.lifecycle.repository;

import com.creditcard.lifecycle.model.Installment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InstallmentRepository extends JpaRepository<Installment, Long> {
    List<Installment> findByLoanIdOrderBySequenceAsc(Long loanId);
}
