package com.creditcard.lifecycle.dto;

import com.creditcard.lifecycle.model.Transaction;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public final class TransactionDtos {

    private TransactionDtos() {
    }

    /** What a POS terminal swipes and sends into the acquirer. */
    public record AuthorizeRequest(
            @NotBlank String cardToken,
            @NotNull @Positive BigDecimal amount,
            @NotNull Long merchantId,
            String currency) {
    }

    /** The response the POS terminal prints on the receipt (ISO 8583-style). */
    public record AuthorizeResponse(
            String decision,
            String responseCode,
            String responseText,
            String transactionReference,
            String authCode,
            String stan,
            String rrn,
            String mti,
            BigDecimal amount,
            BigDecimal availableCredit,
            String reason,
            String flowTrace) {
    }

    /** Merchant captures a previously authorized transaction (clearing). */
    public record CaptureRequest(
            @Positive BigDecimal amount) {
    }

    public record RefundRequest(
            @NotNull @Positive BigDecimal amount,
            String note) {
    }

    public record TransactionResponse(
            Long id,
            String reference,
            Long accountId,
            Long merchantId,
            String type,
            String status,
            BigDecimal amount,
            BigDecimal authorizedAmount,
            BigDecimal capturedAmount,
            BigDecimal refundedAmount,
            String currency,
            String authCode,
            String reason,
            boolean fraudReported,
            Long parentTransactionId,
            Long loanId,
            LocalDateTime createdAt,
            LocalDateTime capturedAt,
            LocalDateTime settledAt) {

        public static TransactionResponse from(Transaction t) {
            return new TransactionResponse(
                    t.getId(),
                    t.getReference(),
                    t.getAccount().getId(),
                    t.getMerchant() == null ? null : t.getMerchant().getId(),
                    t.getType().name(),
                    t.getStatus().name(),
                    t.getAmount(),
                    t.getAuthorizedAmount(),
                    t.getCapturedAmount(),
                    t.getRefundedAmount(),
                    t.getCurrency(),
                    t.getAuthCode(),
                    t.getReason(),
                    t.isFraudReported(),
                    t.getParentTransactionId(),
                    t.getLoanId(),
                    t.getCreatedAt(),
                    t.getCapturedAt(),
                    t.getSettledAt());
        }
    }

    /** Result of a settlement batch run. */
    public record SettlementResponse(
            int settledCount,
            BigDecimal settledAmount,
            String message) {
    }
}
