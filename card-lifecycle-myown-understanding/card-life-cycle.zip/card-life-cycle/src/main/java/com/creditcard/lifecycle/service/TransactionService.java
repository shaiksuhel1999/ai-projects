package com.creditcard.lifecycle.service;

import com.creditcard.lifecycle.event.EventType;
import com.creditcard.lifecycle.event.LifecycleEvents;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.exception.ResourceNotFoundException;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.model.enums.TransactionType;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.support.Money;
import com.creditcard.lifecycle.support.ReferenceGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Post-authorization clearing lifecycle: capture (merchant clearing), auth
 * reversal, interbank settlement, and refunds.
 */
@Service
@Transactional
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final LifecycleEvents events;
    private final RewardsService rewardsService;
    private final ReferenceGenerator references;

    public TransactionService(TransactionRepository transactionRepository,
                              LifecycleEvents events,
                              RewardsService rewardsService,
                              ReferenceGenerator references) {
        this.transactionRepository = transactionRepository;
        this.events = events;
        this.rewardsService = rewardsService;
        this.references = references;
    }

    /**
     * Merchant captures an authorized transaction (a.k.a. clearing). Releases the
     * hold and posts the captured amount to the balance. Supports partial capture.
     */
    public Transaction capture(Long transactionId, BigDecimal requestedAmount) {
        Transaction txn = get(transactionId);
        if (txn.getStatus() != TransactionStatus.AUTHORIZED) {
            throw new BusinessException("Only an AUTHORIZED transaction can be captured; status = " + txn.getStatus());
        }
        BigDecimal captureAmount = requestedAmount != null ? Money.of(requestedAmount) : txn.getAuthorizedAmount();
        if (!Money.isPositive(captureAmount)) {
            throw new BusinessException("Capture amount must be positive");
        }
        if (captureAmount.compareTo(txn.getAuthorizedAmount()) > 0) {
            throw new BusinessException("Capture amount cannot exceed the authorized amount "
                    + txn.getAuthorizedAmount());
        }

        CreditAccount account = txn.getAccount();
        // Release the full hold, then post what was actually captured.
        account.setHoldAmount(Money.of(account.getHoldAmount().subtract(txn.getAuthorizedAmount())));
        account.setCurrentBalance(Money.of(account.getCurrentBalance().add(captureAmount)));

        txn.setCapturedAmount(captureAmount);
        txn.setStatus(TransactionStatus.CAPTURED);
        txn.setCapturedAt(LocalDateTime.now());
        events.publish(EventType.CAPTURE, "Captured " + captureAmount,
                account.getId(), txn.getCard() == null ? null : txn.getCard().getId(),
                txn.getReference(), captureAmount);
        // Earn reward points now that the purchase has cleared.
        rewardsService.accrue(txn);
        return txn;
    }

    /** Cancel an authorization before capture, releasing the hold. */
    public Transaction reverse(Long transactionId) {
        Transaction txn = get(transactionId);
        if (txn.getStatus() != TransactionStatus.AUTHORIZED) {
            throw new BusinessException("Only an AUTHORIZED transaction can be reversed; status = " + txn.getStatus());
        }
        CreditAccount account = txn.getAccount();
        account.setHoldAmount(Money.of(account.getHoldAmount().subtract(txn.getAuthorizedAmount())));
        txn.setStatus(TransactionStatus.REVERSED);
        txn.setReason("AUTH_REVERSED");
        events.publish(EventType.REVERSAL, "Reversed authorization " + txn.getAuthorizedAmount(),
                account.getId(), txn.getCard() == null ? null : txn.getCard().getId(),
                txn.getReference(), txn.getAuthorizedAmount());
        return txn;
    }

    /**
     * Settle every captured transaction (interactive / API path — one transaction
     * for the whole batch). The scheduled job instead settles per-item for
     * resilience; both share {@link #doSettle}.
     */
    public SettlementSummary settleBatch() {
        List<Transaction> captured = transactionRepository.findByStatus(TransactionStatus.CAPTURED);
        int count = 0;
        BigDecimal total = BigDecimal.ZERO;
        for (Transaction txn : captured) {
            BigDecimal amount = doSettle(txn);
            if (amount != null) {
                count++;
                total = total.add(amount);
            }
        }
        if (count > 0) {
            events.publish(EventType.SETTLEMENT,
                    "Settlement batch: " + count + " txn(s) for " + Money.of(total),
                    null, null, null, Money.of(total));
        }
        return new SettlementSummary(count, Money.of(total));
    }

    /** Ids awaiting settlement, for the resilient per-item batch job. */
    @Transactional(readOnly = true)
    public List<Long> capturedTransactionIds() {
        return transactionRepository.findByStatus(TransactionStatus.CAPTURED)
                .stream().map(Transaction::getId).toList();
    }

    /** Settle one transaction (each call is its own tx when driven by the batch job). */
    public BigDecimal settleOne(Long id) {
        Transaction txn = transactionRepository.findById(id).orElse(null);
        return txn == null ? null : doSettle(txn);
    }

    private BigDecimal doSettle(Transaction txn) {
        if (txn.getStatus() != TransactionStatus.CAPTURED) {
            return null; // already settled by a concurrent run
        }
        txn.setStatus(TransactionStatus.SETTLED);
        txn.setSettledAt(LocalDateTime.now());
        return txn.getCapturedAmount();
    }

    /** Release authorization holds that were never captured before the cutoff (interactive path). */
    public int expireStaleHolds(LocalDateTime cutoff) {
        int expired = 0;
        for (Transaction txn : transactionRepository
                .findByStatusAndCreatedAtBefore(TransactionStatus.AUTHORIZED, cutoff)) {
            if (Boolean.TRUE.equals(doExpire(txn))) {
                expired++;
            }
        }
        return expired;
    }

    /** Ids of stale holds before the cutoff, for the resilient per-item batch job. */
    @Transactional(readOnly = true)
    public List<Long> staleHoldIds(LocalDateTime cutoff) {
        return transactionRepository.findByStatusAndCreatedAtBefore(TransactionStatus.AUTHORIZED, cutoff)
                .stream().map(Transaction::getId).toList();
    }

    /** Expire one stale hold (each call is its own tx when driven by the batch job). */
    public boolean expireHold(Long id) {
        Transaction txn = transactionRepository.findById(id).orElse(null);
        return txn != null && Boolean.TRUE.equals(doExpire(txn));
    }

    private Boolean doExpire(Transaction txn) {
        if (txn.getStatus() != TransactionStatus.AUTHORIZED) {
            return false;
        }
        CreditAccount account = txn.getAccount();
        account.setHoldAmount(Money.of(account.getHoldAmount().subtract(txn.getAuthorizedAmount())));
        txn.setStatus(TransactionStatus.REVERSED);
        txn.setReason("HOLD_EXPIRED");
        events.publish(EventType.REVERSAL, "Expired stale hold " + txn.getAuthorizedAmount(),
                account.getId(), txn.getCard() == null ? null : txn.getCard().getId(),
                txn.getReference(), txn.getAuthorizedAmount());
        return true;
    }

    /** Refund a captured/settled purchase back to the cardholder (full or partial). */
    public Transaction refund(Long transactionId, BigDecimal rawAmount, String note) {
        Transaction original = get(transactionId);
        if (original.getType() != TransactionType.PURCHASE) {
            throw new BusinessException("Only purchases can be refunded");
        }
        if (original.getStatus() != TransactionStatus.CAPTURED && original.getStatus() != TransactionStatus.SETTLED) {
            throw new BusinessException("Only a CAPTURED or SETTLED purchase can be refunded; status = "
                    + original.getStatus());
        }
        BigDecimal amount = Money.of(rawAmount);
        if (!Money.isPositive(amount)) {
            throw new BusinessException("Refund amount must be positive");
        }
        // Guard against over-refunding across multiple partial refunds.
        BigDecimal alreadyRefunded = Money.of(original.getRefundedAmount());
        BigDecimal remaining = Money.of(original.getCapturedAmount().subtract(alreadyRefunded));
        if (amount.compareTo(remaining) > 0) {
            throw new BusinessException("Refund amount " + amount
                    + " exceeds the refundable remaining " + remaining
                    + " (captured " + original.getCapturedAmount() + ", already refunded " + alreadyRefunded + ")");
        }

        CreditAccount account = original.getAccount();
        account.setCurrentBalance(Money.of(account.getCurrentBalance().subtract(amount)));
        original.setRefundedAmount(Money.of(alreadyRefunded.add(amount)));

        Transaction refund = new Transaction();
        refund.setReference(newReference());
        refund.setAccount(account);
        refund.setCard(original.getCard());
        refund.setMerchant(original.getMerchant());
        refund.setType(TransactionType.REFUND);
        refund.setStatus(TransactionStatus.SETTLED);
        refund.setAmount(amount);
        refund.setCapturedAmount(amount);
        refund.setCurrency(original.getCurrency());
        refund.setParentTransactionId(original.getId());
        refund.setReason(note == null ? "REFUND" : note);
        refund.setSettledAt(LocalDateTime.now());
        transactionRepository.save(refund);

        if (original.getRefundedAmount().compareTo(original.getCapturedAmount()) >= 0) {
            original.setStatus(TransactionStatus.REFUNDED);
        }
        // Claw back reward points proportional to the refunded amount.
        rewardsService.reverseAccrual(original, amount);

        events.publish(EventType.REFUND, "Refunded " + amount,
                account.getId(), original.getCard() == null ? null : original.getCard().getId(),
                refund.getReference(), amount);
        return refund;
    }

    @Transactional(readOnly = true)
    public Transaction get(Long id) {
        return transactionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", id));
    }

    @Transactional(readOnly = true)
    public List<Transaction> listByAccount(Long accountId) {
        return transactionRepository.findByAccountIdOrderByCreatedAtDesc(accountId);
    }

    /** Result of a settlement batch run. */
    public record SettlementSummary(int settledCount, BigDecimal settledAmount) {
    }

    private String newReference() {
        return references.next("TXN");
    }
}
