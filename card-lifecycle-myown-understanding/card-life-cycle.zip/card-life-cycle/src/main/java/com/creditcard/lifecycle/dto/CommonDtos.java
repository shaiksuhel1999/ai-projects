package com.creditcard.lifecycle.dto;

/** Small shared response shapes. */
public final class CommonDtos {

    private CommonDtos() {
    }

    /** Generic acknowledgement message. */
    public record MessageResponse(String message) {
    }
}
