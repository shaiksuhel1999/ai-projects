package com.creditcard.lifecycle.model.enums;

/** The issuer's verdict on an authorization request. */
public enum AuthDecision {
    APPROVED,
    DECLINED
}
