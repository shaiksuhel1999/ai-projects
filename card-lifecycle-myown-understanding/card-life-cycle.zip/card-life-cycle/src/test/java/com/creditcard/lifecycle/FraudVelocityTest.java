package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Verifies the real-time velocity control: after N approved authorizations in the
 * window, the next one is declined with ISO response code 65 (exceeds velocity).
 */
@SpringBootTest
@TestPropertySource(properties = {
        "bank.fraud.velocity-max-count=2",
        "bank.fraud.velocity-window-seconds=3600"
})
@Transactional
class FraudVelocityTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void velocityDeclinesAfterThreshold() {
        Customer customer = customerService.create(new CreateCustomerRequest(
                "Velo City", "velo." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("500000"), "VISA", 1));
        cardService.activate(card.getId());
        Merchant merchant = merchantRepository.save(new Merchant("Velo Store", "5411", "Acq", "T-V"));

        assertEquals("00", authorize(card.getToken(), merchant.getId()).responseCode(), "1st approved");
        assertEquals("00", authorize(card.getToken(), merchant.getId()).responseCode(), "2nd approved");

        AuthorizeResponse third = authorize(card.getToken(), merchant.getId());
        assertEquals("DECLINED", third.decision());
        assertEquals("65", third.responseCode(), "3rd should breach the velocity limit");
    }

    private AuthorizeResponse authorize(String token, Long merchantId) {
        return acquirerService.authorize(new AuthorizeRequest(token, new BigDecimal("100"), merchantId, "INR"));
    }
}
