package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.LoanDtos.LoanApplicationRequest;
import com.creditcard.lifecycle.dto.PaymentDtos.PaymentRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Installment;
import com.creditcard.lifecycle.model.Loan;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Statement;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.AuthDecision;
import com.creditcard.lifecycle.model.enums.CardStatus;
import com.creditcard.lifecycle.model.enums.LoanStatus;
import com.creditcard.lifecycle.model.enums.PaymentType;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.BillingService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.LoanService;
import com.creditcard.lifecycle.service.PaymentService;
import com.creditcard.lifecycle.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@TestPropertySource(properties = "demo.run=false")
@Transactional
class LifecycleIntegrationTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired TransactionService transactionService;
    @Autowired TransactionRepository transactionRepository;
    @Autowired BillingService billingService;
    @Autowired PaymentService paymentService;
    @Autowired LoanService loanService;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void fullCardJourney() {
        Customer customer = customerService.create(new CreateCustomerRequest(
                "Test User", "test.user@example.com", "+91-99999", new BigDecimal("1800000"), 780));

        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("100000"), "VISA", 1));
        Long accountId = card.getAccount().getId();

        // A purchase before activation must be declined.
        Merchant merchant = merchantRepository.save(new Merchant("Test Shop", "5999", "Test Acq", "T-1"));
        AuthorizeResponse beforeActivation = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("1000"), merchant.getId(), "INR"));
        assertEquals(AuthDecision.DECLINED.name(), beforeActivation.decision());

        cardService.activate(card.getId());
        assertEquals(CardStatus.ACTIVE, cardService.get(card.getId()).getStatus());

        // Authorize -> hold placed, available credit reduced.
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("1000"), merchant.getId(), "INR"));
        assertEquals(AuthDecision.APPROVED.name(), auth.decision());
        CreditAccount afterAuth = cardService.getAccount(accountId);
        assertEquals(0, afterAuth.getHoldAmount().compareTo(new BigDecimal("1000.00")));
        assertEquals(0, afterAuth.getAvailableCredit().compareTo(new BigDecimal("99000.00")));

        // Capture -> balance posted, hold released.
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        transactionService.capture(txn.getId(), null);
        CreditAccount afterCapture = cardService.getAccount(accountId);
        assertEquals(0, afterCapture.getHoldAmount().compareTo(new BigDecimal("0.00")));
        assertEquals(0, afterCapture.getCurrentBalance().compareTo(new BigDecimal("1000.00")));

        // Settle.
        transactionService.settleBatch();
        assertEquals(TransactionStatus.SETTLED, transactionService.get(txn.getId()).getStatus());

        // Statement -> minimum due is the 200 floor (5% of 1000 = 50 < 200).
        Statement statement = billingService.generateStatement(accountId);
        assertEquals(0, statement.getClosingBalance().compareTo(new BigDecimal("1000.00")));
        assertEquals(0, statement.getMinimumDue().compareTo(new BigDecimal("200.00")));

        // Pay the minimum -> balance and statement-remaining drop by 200.
        paymentService.pay(accountId, new PaymentRequest(PaymentType.MINIMUM_DUE, null, "UPI"));
        CreditAccount afterPay = cardService.getAccount(accountId);
        assertEquals(0, afterPay.getCurrentBalance().compareTo(new BigDecimal("800.00")));
        assertEquals(0, afterPay.getStatementRemaining().compareTo(new BigDecimal("800.00")));

        // Personal loan: approved, disbursed, amortized to zero.
        Loan loan = loanService.applyPersonalLoan(new LoanApplicationRequest(
                accountId, new BigDecimal("120000"), 12, "Test loan"));
        assertEquals(LoanStatus.APPROVED, loan.getStatus());
        Loan disbursed = loanService.disburse(loan.getId());
        List<Installment> schedule = disbursed.getInstallments();
        assertEquals(12, schedule.size());
        assertEquals(0, schedule.get(11).getBalanceAfter().compareTo(new BigDecimal("0.00")),
                "final instalment must clear the principal to zero");

        // Sum of principal components equals the principal.
        BigDecimal principalSum = schedule.stream()
                .map(Installment::getPrincipalComponent)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        assertTrue(principalSum.subtract(new BigDecimal("120000")).abs().compareTo(new BigDecimal("0.05")) < 0,
                "principal components should sum to the loan principal but summed to " + principalSum);
    }
}
