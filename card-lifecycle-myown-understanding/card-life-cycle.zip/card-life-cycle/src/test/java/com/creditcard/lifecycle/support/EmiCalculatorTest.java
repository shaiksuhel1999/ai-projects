package com.creditcard.lifecycle.support;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EmiCalculatorTest {

    @Test
    void computesKnownEmi() {
        // 1,00,000 @ 12% p.a. for 12 months -> EMI ~ 8884.88
        BigDecimal emi = EmiCalculator.emi(new BigDecimal("100000"), new BigDecimal("12"), 12);
        assertTrue(emi.subtract(new BigDecimal("8884.88")).abs().compareTo(new BigDecimal("0.05")) < 0,
                "EMI should be ~8884.88 but was " + emi);
    }

    @Test
    void zeroInterestSplitsEvenly() {
        BigDecimal emi = EmiCalculator.emi(new BigDecimal("12000"), BigDecimal.ZERO, 12);
        assertEquals(0, emi.compareTo(new BigDecimal("1000.00")), "12000 over 12 months at 0% is 1000/month");
    }
}
