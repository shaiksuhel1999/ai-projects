package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.PaymentType;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.AutopayService;
import com.creditcard.lifecycle.service.BillingService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.RewardsService;
import com.creditcard.lifecycle.service.RewardsService.Redemption;
import com.creditcard.lifecycle.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Rewards accrual/redemption and autopay execution. */
@SpringBootTest
@Transactional
class RewardsAutopayTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired TransactionService transactionService;
    @Autowired TransactionRepository transactionRepository;
    @Autowired BillingService billingService;
    @Autowired RewardsService rewardsService;
    @Autowired AutopayService autopayService;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void earnPointsRedeemThenAutopayPaysMinimum() {
        var customer = customerService.create(new CreateCustomerRequest(
                "Reward User", "reward." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("200000"), "VISA", 1));
        cardService.activate(card.getId());
        CreditAccount account = card.getAccount();

        // Grocery merchant (MCC 5411) earns 2x: 10000 * 0.01 * 2 = 200 points.
        Merchant grocery = merchantRepository.save(new Merchant("Grocer", "5411", "Acq", "T-R"));
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("10000"), grocery.getId(), "INR"));
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        transactionService.capture(txn.getId(), null);
        transactionService.settleBatch();

        assertEquals(200, account.getRewardPoints(), "2x points on a 10000 grocery spend");

        // Redeem 100 points -> 100 * 0.25 = 25.00 statement credit.
        Redemption r = rewardsService.redeem(account.getId(), 100);
        assertEquals(0, r.cashCredited().compareTo(new BigDecimal("25.00")));
        assertEquals(100, r.remainingPoints());
        assertEquals(0, account.getCurrentBalance().compareTo(new BigDecimal("9975.00")),
                "redemption credited 25 off the 10000 balance");

        // Statement + autopay: enroll for the minimum, force the due date, run the batch.
        billingService.generateStatement(account.getId());
        BigDecimal minimumDue = account.getMinimumDue();
        assertTrue(minimumDue.compareTo(BigDecimal.ZERO) > 0);

        autopayService.enroll(account.getId(), PaymentType.MINIMUM_DUE);
        account.setPaymentDueDate(LocalDate.now()); // due today
        int paid = autopayService.runAutopay();

        assertEquals(1, paid, "one account autopaid");
        assertEquals(0, account.getPaidThisCycle().compareTo(minimumDue), "autopay paid exactly the minimum due");
    }
}
