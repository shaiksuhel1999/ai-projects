package com.creditcard.lifecycle.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Exercises the full REST stack over HTTP (via MockMvc): controllers, JSON
 * (de)serialization, bean validation, and the global exception handler.
 * Runs without binding a real socket, so it works anywhere.
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = "demo.run=false")
@WithMockUser(roles = "ADMIN")
class CardLifecycleApiTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;

    @Test
    void fullHttpJourney() throws Exception {
        String uniqueEmail = "api.user." + System.nanoTime() + "@example.com";

        // 1) Onboard a customer -> 201 Created
        long customerId = postJson("/api/customers", """
                {"fullName":"Api User","email":"%s","phone":"+91-1","annualIncome":1800000,"creditScore":780}
                """.formatted(uniqueEmail), status().isCreated()).get("id").asLong();

        // 2) Register a merchant -> 201 Created
        long merchantId = postJson("/api/merchants", """
                {"name":"HTTP Mart","mcc":"5411","acquirerName":"HDFC Acquiring","terminalId":"T-HTTP"}
                """, status().isCreated()).get("id").asLong();

        // 3) Issue a card -> 201, starts ISSUED
        JsonNode card = postJson("/api/cards", """
                {"customerId":%d,"creditLimit":100000,"brand":"VISA","statementDay":1}
                """.formatted(customerId), status().isCreated());
        long cardId = card.get("cardId").asLong();
        long accountId = card.get("accountId").asLong();
        String token = card.get("token").asText();
        assertEquals("ISSUED", card.get("status").asText());

        // 4) Authorizing before activation is DECLINED (HTTP 200, business decision in body)
        mvc.perform(post("/api/pos/authorize").contentType(MediaType.APPLICATION_JSON).content("""
                        {"cardToken":"%s","amount":1000,"merchantId":%d,"currency":"INR"}
                        """.formatted(token, merchantId)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.decision").value("DECLINED"))
                .andExpect(jsonPath("$.responseCode").value("57"))
                .andExpect(jsonPath("$.reason").value("TRANSACTION_NOT_PERMITTED"));

        // 5) Activate -> ACTIVE
        mvc.perform(post("/api/cards/" + cardId + "/activate"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ACTIVE"));

        // 6) Authorize -> APPROVED, with the full acquirer->network->issuer trace
        JsonNode auth = postJson("/api/pos/authorize", """
                {"cardToken":"%s","amount":1000,"merchantId":%d,"currency":"INR"}
                """.formatted(token, merchantId), status().isOk());
        assertEquals("APPROVED", auth.get("decision").asText());
        assertEquals("00", auth.get("responseCode").asText());
        assertTrue(auth.get("authCode").asText().length() == 6);
        assertTrue(auth.get("stan").asText().length() == 6);
        assertTrue(auth.get("flowTrace").asText().contains("Network[VISA] -> Issuer => APPROVED"));
        String reference = auth.get("transactionReference").asText();

        // 7) Locate the transaction id (POS holds the reference) and capture it
        long txnId = findTxnIdByReference(accountId, reference);
        mvc.perform(post("/api/transactions/" + txnId + "/capture"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CAPTURED"))
                .andExpect(jsonPath("$.capturedAmount").value(1000.00));

        // 8) Settle the batch
        mvc.perform(post("/api/transactions/settle"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.settledCount").value(Matchers.greaterThanOrEqualTo(1)));

        // 9) Account snapshot: balance 1000, hold 0, available 99000
        mvc.perform(get("/api/cards/accounts/" + accountId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.currentBalance").value(1000.00))
                .andExpect(jsonPath("$.holdAmount").value(0.00))
                .andExpect(jsonPath("$.availableCredit").value(99000.00));

        // 10) Cut a statement: minimum due is the 200 floor (5% of 1000 = 50 < 200)
        mvc.perform(post("/api/accounts/" + accountId + "/statements/generate"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.closingBalance").value(1000.00))
                .andExpect(jsonPath("$.minimumDue").value(200.00));

        // 11) Pay the minimum due -> balance 800
        mvc.perform(post("/api/accounts/" + accountId + "/payments").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"type\":\"MINIMUM_DUE\",\"method\":\"UPI\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.amountPaid").value(200.00))
                .andExpect(jsonPath("$.newBalance").value(800.00));

        // 12) Apply for a personal loan -> APPROVED, then disburse -> 12-instalment schedule
        long loanId = postJson("/api/loans/apply", """
                {"accountId":%d,"principal":120000,"tenureMonths":12,"purpose":"HTTP test"}
                """.formatted(accountId), status().isCreated()).get("loanId").asLong();

        mvc.perform(post("/api/loans/" + loanId + "/disburse"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DISBURSED"))
                .andExpect(jsonPath("$.schedule.length()").value(12))
                .andExpect(jsonPath("$.schedule[11].balanceAfter").value(0.00));

        // 13) The real-time event feed captured the journey (events fire AFTER_COMMIT)
        mvc.perform(get("/api/events/recent"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.type=='AUTH_APPROVED')]").exists())
                .andExpect(jsonPath("$[?(@.type=='SETTLEMENT')]").exists())
                .andExpect(jsonPath("$[?(@.type=='LOAN_DISBURSED')]").exists());
    }

    @Test
    void validationErrorReturns400WithFieldErrors() throws Exception {
        mvc.perform(post("/api/customers").contentType(MediaType.APPLICATION_JSON).content(
                        "{\"fullName\":\"\",\"email\":\"not-an-email\",\"annualIncome\":-5,\"creditScore\":100}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.fieldErrors").exists());
    }

    @Test
    void unknownCardReturns404() throws Exception {
        mvc.perform(get("/api/cards/999999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.message").value(Matchers.containsString("Card not found")));
    }

    @Test
    void insufficientFundsIsDeclined() throws Exception {
        String email = "poor.user." + System.nanoTime() + "@example.com";
        long customerId = postJson("/api/customers", """
                {"fullName":"Poor User","email":"%s","annualIncome":500000,"creditScore":720}
                """.formatted(email), status().isCreated()).get("id").asLong();
        long merchantId = postJson("/api/merchants", """
                {"name":"Big Store","acquirerName":"Axis","terminalId":"T-BIG"}
                """, status().isCreated()).get("id").asLong();
        JsonNode card = postJson("/api/cards", """
                {"customerId":%d,"creditLimit":5000,"brand":"RUPAY"}
                """.formatted(customerId), status().isCreated());
        long cardId = card.get("cardId").asLong();
        String token = card.get("token").asText();
        mvc.perform(post("/api/cards/" + cardId + "/activate")).andExpect(status().isOk());

        mvc.perform(post("/api/pos/authorize").contentType(MediaType.APPLICATION_JSON).content("""
                        {"cardToken":"%s","amount":9999,"merchantId":%d,"currency":"INR"}
                        """.formatted(token, merchantId)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.decision").value("DECLINED"))
                .andExpect(jsonPath("$.responseCode").value("51"))
                .andExpect(jsonPath("$.reason").value("INSUFFICIENT_FUNDS"));
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private JsonNode postJson(String url, String body, ResultMatcher expectedStatus) throws Exception {
        MvcResult res = mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(expectedStatus).andReturn();
        return om.readTree(res.getResponse().getContentAsString());
    }

    private long findTxnIdByReference(long accountId, String reference) throws Exception {
        MvcResult res = mvc.perform(get("/api/transactions/accounts/" + accountId))
                .andExpect(status().isOk()).andReturn();
        JsonNode arr = om.readTree(res.getResponse().getContentAsString());
        for (JsonNode n : arr) {
            if (reference.equals(n.get("reference").asText())) {
                return n.get("id").asLong();
            }
        }
        throw new AssertionError("No transaction found with reference " + reference);
    }
}
