package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

/** Verifies that uncaptured authorization holds are released (reversed) after they expire. */
@SpringBootTest
@Transactional
class HoldExpiryTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired TransactionService transactionService;
    @Autowired TransactionRepository transactionRepository;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void staleHoldsAreReleased() {
        var customer = customerService.create(new CreateCustomerRequest(
                "Hold User", "hold." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("100000"), "VISA", 1));
        cardService.activate(card.getId());
        CreditAccount account = card.getAccount();
        Merchant merchant = merchantRepository.save(new Merchant("Store", "5999", "Acq", "T-H"));

        // Authorize but never capture -> a standing hold.
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("5000"), merchant.getId(), "INR"));
        assertEquals("APPROVED", auth.decision());
        assertEquals(0, account.getHoldAmount().compareTo(new BigDecimal("5000.00")));
        assertEquals(0, account.getAvailableCredit().compareTo(new BigDecimal("95000.00")));

        // Expire everything authorized before now+5s -> our hold qualifies.
        int expired = transactionService.expireStaleHolds(LocalDateTime.now().plusSeconds(5));

        assertEquals(1, expired);
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        assertEquals(TransactionStatus.REVERSED, txn.getStatus());
        assertEquals("HOLD_EXPIRED", txn.getReason());
        assertEquals(0, account.getHoldAmount().compareTo(new BigDecimal("0.00")));
        assertEquals(0, account.getAvailableCredit().compareTo(new BigDecimal("100000.00")));
    }
}
