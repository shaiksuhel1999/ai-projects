package com.creditcard.lifecycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@TestPropertySource(properties = "demo.run=false")
class CreditCardLifecycleApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring context (JPA, web, services) wires up cleanly.
    }
}
