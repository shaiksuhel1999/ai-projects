package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Dispute;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.CardStatus;
import com.creditcard.lifecycle.model.enums.DisputeReasonCode;
import com.creditcard.lifecycle.model.enums.DisputeStatus;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.DisputeService;
import com.creditcard.lifecycle.service.PostingService;
import com.creditcard.lifecycle.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Disputes & chargebacks, the memo-post / hard-post ledger, auxiliary adjustments
 * and fraud tagging &mdash; verifying the balance effects end to end.
 */
@SpringBootTest
@Transactional
class DisputeChargebackTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired TransactionService transactionService;
    @Autowired TransactionRepository transactionRepository;
    @Autowired PostingService postingService;
    @Autowired DisputeService disputeService;
    @Autowired MerchantRepository merchantRepository;

    private static final AtomicInteger SEQ = new AtomicInteger();

    @Test
    void disputeWonHardPostsTheProvisionalCredit() {
        Ctx c = newActiveCard();
        Transaction purchase = purchase(c, "20000");
        CreditAccount acct = c.card.getAccount();
        assertBd("20000.00", acct.getCurrentBalance());
        assertBd("80000.00", acct.getAvailableCredit());

        Dispute dispute = disputeService.open(purchase.getId(), DisputeReasonCode.GOODS_NOT_RECEIVED, "not delivered");
        assertEquals(DisputeStatus.OPEN, dispute.getStatus());

        // Provisional credit is a MEMO post: frees available credit, ledger unchanged.
        disputeService.issueProvisionalCredit(dispute.getId());
        assertBd("20000.00", acct.getCurrentBalance());
        assertBd("-20000.00", acct.getMemoBalance());
        assertBd("100000.00", acct.getAvailableCredit());

        // Won: the provisional credit is hard-posted -> ledger cleared, memo cleared.
        disputeService.resolve(dispute.getId(), true, "cardholder favour");
        assertEquals(DisputeStatus.WON, disputeService.get(dispute.getId()).getStatus());
        assertBd("0.00", acct.getCurrentBalance());
        assertBd("0.00", acct.getMemoBalance());
        assertBd("100000.00", acct.getAvailableCredit());
    }

    @Test
    void disputeLostReversesTheProvisionalCredit() {
        Ctx c = newActiveCard();
        Transaction purchase = purchase(c, "15000");
        CreditAccount acct = c.card.getAccount();

        Dispute dispute = disputeService.open(purchase.getId(), DisputeReasonCode.INCORRECT_AMOUNT, null);
        disputeService.issueProvisionalCredit(dispute.getId());
        assertBd("100000.00", acct.getAvailableCredit());

        disputeService.represent(dispute.getId(), "signed receipt provided");
        disputeService.resolve(dispute.getId(), false, "merchant favour");

        assertEquals(DisputeStatus.LOST, disputeService.get(dispute.getId()).getStatus());
        // Provisional credit reversed: cardholder still owes the original amount.
        assertBd("15000.00", acct.getCurrentBalance());
        assertBd("0.00", acct.getMemoBalance());
        assertBd("85000.00", acct.getAvailableCredit());
    }

    @Test
    void memoAdjustmentAffectsAvailableThenPostingCycleHardPosts() {
        Ctx c = newActiveCard();
        CreditAccount acct = c.card.getAccount();

        // Goodwill credit as a MEMO adjustment: available rises now, ledger unchanged.
        Transaction memo = postingService.adjust(acct.getId(), true, new BigDecimal("5000"), "Goodwill", true);
        assertEquals(TransactionStatus.MEMO, memo.getStatus());
        assertBd("0.00", acct.getCurrentBalance());
        assertBd("-5000.00", acct.getMemoBalance());
        assertBd("105000.00", acct.getAvailableCredit());

        // Posting cycle hard-posts it: memo cleared, ledger reflects the credit balance.
        postingService.runPostingCycle();
        assertEquals(TransactionStatus.POSTED, transactionRepository.findById(memo.getId()).orElseThrow().getStatus());
        assertBd("-5000.00", acct.getCurrentBalance());
        assertBd("0.00", acct.getMemoBalance());
        assertBd("105000.00", acct.getAvailableCredit());
    }

    @Test
    void reportFraudTagsBlocksAndOpensDispute() {
        Ctx c = newActiveCard();
        Transaction purchase = purchase(c, "3000");

        Dispute dispute = disputeService.reportFraud(purchase.getId(), "card-not-present fraud");

        assertTrue(transactionRepository.findById(purchase.getId()).orElseThrow().isFraudReported());
        assertEquals(CardStatus.BLOCKED, cardService.get(c.card.getId()).getStatus());
        assertEquals(DisputeReasonCode.FRAUD, dispute.getReasonCode());

        // A blocked card is now declined with ISO code 43 (stolen/blocked).
        AuthorizeResponse decl = acquirerService.authorize(
                new AuthorizeRequest(c.card.getToken(), new BigDecimal("100"), c.merchantId, "INR"));
        assertEquals("DECLINED", decl.decision());
        assertEquals("43", decl.responseCode());
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private record Ctx(Card card, Long merchantId) {
    }

    private Ctx newActiveCard() {
        int n = SEQ.incrementAndGet();
        var customer = customerService.create(new CreateCustomerRequest(
                "Dispute User " + n, "dispute." + n + "." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("100000"), "VISA", 1));
        cardService.activate(card.getId());
        Merchant merchant = merchantRepository.save(new Merchant("Store " + n, "5411", "Acq", "T-" + n));
        return new Ctx(card, merchant.getId());
    }

    private Transaction purchase(Ctx c, String amount) {
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(c.card.getToken(), new BigDecimal(amount), c.merchantId, "INR"));
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        transactionService.capture(txn.getId(), null);
        transactionService.settleBatch();
        return transactionRepository.findById(txn.getId()).orElseThrow();
    }

    private void assertBd(String expected, BigDecimal actual) {
        assertEquals(0, new BigDecimal(expected).compareTo(actual),
                "expected " + expected + " but was " + actual);
    }
}
