package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** A double-submitted authorization carrying the same Idempotency-Key executes once. */
@SpringBootTest
@AutoConfigureMockMvc
@WithMockUser(roles = "ADMIN")
class IdempotencyApiTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;
    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void sameKeyReplaysTheOriginalResponse() throws Exception {
        Customer customer = customerService.create(new CreateCustomerRequest(
                "Idem User", "idem." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("100000"), "VISA", 1));
        cardService.activate(card.getId());
        Merchant merchant = merchantRepository.save(new Merchant("Idem Store", "5999", "Acq", "T-ID"));

        String key = "idem-" + System.nanoTime();
        String body = """
                {"cardToken":"%s","amount":1000,"merchantId":%d,"currency":"INR"}
                """.formatted(card.getToken(), merchant.getId());

        MvcResult first = mvc.perform(post("/api/pos/authorize")
                        .header("Idempotency-Key", key)
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.decision").value("APPROVED"))
                .andReturn();
        String ref1 = om.readTree(first.getResponse().getContentAsString()).get("transactionReference").asText();

        // Retry with the same key -> replayed, no second authorization.
        MvcResult second = mvc.perform(post("/api/pos/authorize")
                        .header("Idempotency-Key", key)
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(header().string("Idempotency-Replay", "true"))
                .andReturn();
        String ref2 = om.readTree(second.getResponse().getContentAsString()).get("transactionReference").asText();

        // Same reference => the operation ran once (a re-run would mint a new reference).
        assertEquals(ref1, ref2);
    }
}
