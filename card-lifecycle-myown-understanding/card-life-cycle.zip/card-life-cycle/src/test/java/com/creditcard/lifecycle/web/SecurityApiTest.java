package com.creditcard.lifecycle.web;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.model.AppUser;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.Customer;
import com.creditcard.lifecycle.model.enums.Role;
import com.creditcard.lifecycle.repository.AppUserRepository;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Authentication (401) and role / ownership authorization (403 vs 200). */
@SpringBootTest
@AutoConfigureMockMvc
class SecurityApiTest {

    @Autowired MockMvc mvc;
    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AppUserRepository appUsers;
    @Autowired PasswordEncoder encoder;

    @Test
    void enforcesAuthenticationAndOwnership() throws Exception {
        long n = System.nanoTime();
        Customer alice = customerService.create(new CreateCustomerRequest(
                "Alice", "alice." + n + "@example.com", "+91-1", new BigDecimal("1500000"), 770));
        Card aliceCard = cardService.issueCard(new IssueCardRequest(alice.getId(), new BigDecimal("100000"), "VISA", 1));
        long aliceAccount = aliceCard.getAccount().getId();

        Customer bob = customerService.create(new CreateCustomerRequest(
                "Bob", "bob." + n + "@example.com", "+91-2", new BigDecimal("1500000"), 770));
        Card bobCard = cardService.issueCard(new IssueCardRequest(bob.getId(), new BigDecimal("100000"), "VISA", 1));
        long bobAccount = bobCard.getAccount().getId();

        appUsers.save(new AppUser("alice" + n, encoder.encode("pw"), Role.CUSTOMER, alice.getId()));

        // Actuator health is open (k8s probes hit it unauthenticated).
        mvc.perform(get("/actuator/health")).andExpect(status().isOk());

        // No credentials -> 401.
        mvc.perform(get("/api/cards/accounts/" + aliceAccount))
                .andExpect(status().isUnauthorized());

        // Alice can see her own account.
        mvc.perform(get("/api/cards/accounts/" + aliceAccount).with(httpBasic("alice" + n, "pw")))
                .andExpect(status().isOk());

        // Alice cannot see Bob's account -> 403.
        mvc.perform(get("/api/cards/accounts/" + bobAccount).with(httpBasic("alice" + n, "pw")))
                .andExpect(status().isForbidden());

        // Ops-only endpoint is forbidden to a customer...
        mvc.perform(post("/api/transactions/settle").with(httpBasic("alice" + n, "pw")))
                .andExpect(status().isForbidden());

        // ...but allowed for the seeded admin.
        mvc.perform(post("/api/transactions/settle").with(httpBasic("admin", "admin123")))
                .andExpect(status().isOk());
    }
}
