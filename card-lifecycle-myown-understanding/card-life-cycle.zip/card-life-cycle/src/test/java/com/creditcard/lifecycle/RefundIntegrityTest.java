package com.creditcard.lifecycle;

import com.creditcard.lifecycle.dto.CardDtos.IssueCardRequest;
import com.creditcard.lifecycle.dto.CustomerDtos.CreateCustomerRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeRequest;
import com.creditcard.lifecycle.dto.TransactionDtos.AuthorizeResponse;
import com.creditcard.lifecycle.exception.BusinessException;
import com.creditcard.lifecycle.model.Card;
import com.creditcard.lifecycle.model.CreditAccount;
import com.creditcard.lifecycle.model.Merchant;
import com.creditcard.lifecycle.model.Transaction;
import com.creditcard.lifecycle.model.enums.TransactionStatus;
import com.creditcard.lifecycle.repository.MerchantRepository;
import com.creditcard.lifecycle.repository.TransactionRepository;
import com.creditcard.lifecycle.service.AcquirerService;
import com.creditcard.lifecycle.service.CardService;
import com.creditcard.lifecycle.service.CustomerService;
import com.creditcard.lifecycle.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/** Guards against over-refunding across partial refunds, and reward-point clawback. */
@SpringBootTest
@Transactional
class RefundIntegrityTest {

    @Autowired CustomerService customerService;
    @Autowired CardService cardService;
    @Autowired AcquirerService acquirerService;
    @Autowired TransactionService transactionService;
    @Autowired TransactionRepository transactionRepository;
    @Autowired MerchantRepository merchantRepository;

    @Test
    void partialRefundsCannotExceedCapturedAndClawBackPoints() {
        var customer = customerService.create(new CreateCustomerRequest(
                "Refund User", "refund." + System.nanoTime() + "@example.com",
                "+91-1", new BigDecimal("2000000"), 800));
        Card card = cardService.issueCard(new IssueCardRequest(customer.getId(),
                new BigDecimal("200000"), "VISA", 1));
        cardService.activate(card.getId());
        CreditAccount account = card.getAccount();
        Merchant grocery = merchantRepository.save(new Merchant("Grocer", "5411", "Acq", "T-RF"));

        // Purchase 10000 at 2x -> 200 points, balance 10000.
        AuthorizeResponse auth = acquirerService.authorize(
                new AuthorizeRequest(card.getToken(), new BigDecimal("10000"), grocery.getId(), "INR"));
        Transaction txn = transactionRepository.findByReference(auth.transactionReference()).orElseThrow();
        transactionService.capture(txn.getId(), null);
        transactionService.settleBatch();
        assertEquals(200, account.getRewardPoints());

        // First partial refund 6000: balance 4000, points clawed 120 -> 80.
        transactionService.refund(txn.getId(), new BigDecimal("6000"), "partial 1");
        assertEquals(0, account.getCurrentBalance().compareTo(new BigDecimal("4000.00")));
        assertEquals(80, account.getRewardPoints());

        // Second refund of 6000 must be rejected — only 4000 remains refundable.
        assertThrows(BusinessException.class,
                () -> transactionService.refund(txn.getId(), new BigDecimal("6000"), "over-refund"));

        // Refund the remaining 4000: fully refunded, balance 0, points clawed to 0.
        transactionService.refund(txn.getId(), new BigDecimal("4000"), "partial 2");
        assertEquals(0, account.getCurrentBalance().compareTo(new BigDecimal("0.00")));
        assertEquals(0, account.getRewardPoints());
        assertEquals(TransactionStatus.REFUNDED,
                transactionRepository.findById(txn.getId()).orElseThrow().getStatus());
    }
}
